/*
 * Copyright (C) 2007 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1.  Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 * 2.  Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 * 3.  Neither the name of Apple Computer, Inc. ("Apple") nor the names of
 *     its contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE AND ITS CONTRIBUTORS "AS IS" AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL APPLE OR ITS CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "JSSQLResultSetRowList.h"

#include "ExceptionCode.h"
#include "SQLValue.h"
#include "SQLResultSetRowList.h"

using namespace KJS;

namespace WebCore {

JSValue* JSSQLResultSetRowList::item(ExecState* exec, const List& args)
{
    bool indexOk;
    int index = args[0]->toInt32(exec, indexOk);
    if (!indexOk) {
        setDOMException(exec, TYPE_MISMATCH_ERR);
        return jsUndefined();
    }
    if (index < 0 || (unsigned)index >= m_impl->length()) {
        setDOMException(exec, INDEX_SIZE_ERR);
        return jsUndefined();
    }

    JSObject* object = new JSObject(exec->lexicalInterpreter()->builtinObjectPrototype());

    unsigned numColumns = m_impl->columnNames().size();
    unsigned valuesIndex = index * numColumns;
    for (unsigned i = 0; i < numColumns; i++) {
        const SQLValue& value = m_impl->values()[valuesIndex + i];
        JSValue* jsValue = 0;

        switch (value.type()) {
            case SQLValue::StringValue:
              jsValue = jsString(value.string());
              break;
          case SQLValue::NullValue:
              jsValue = jsNull();
              break;
          case SQLValue::NumberValue:
              jsValue = jsNumber(value.number());
              break;
          default:
              ASSERT_NOT_REACHED();
        }

        object->put(exec, m_impl->columnNames()[i], jsValue, DontDelete | ReadOnly);
    }

    return object;
}

}
