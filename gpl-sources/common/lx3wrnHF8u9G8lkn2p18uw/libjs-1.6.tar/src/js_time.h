/*****************************************************************************
 *
 * Copyright 2008 Sony Corporation
 *
 * The information contained here-in is the property of Sony corporation and
 * is not to be disclosed or used without the prior written permission of
 * Sony corporation. This copyright extends to all media in which this
 * information may be preserved including magnetic storage, computer
 * print-out or visual display.
 *
 * Contains proprietary information, copyright and database rights Sony.
 * Decompilation prohibited save as permitted by law. No using, disclosing,
 * reproducing, accessing or modifying without Sony prior written consent.
 *
 *****************************************************************************
 *
 *   File Name   : src/shared/js/src/js_time.h
 *   Created     : 2009/11/02 By NAGUMO Keisuke
 *   Modified    : $DateTime: 2009/11/18 16:31:09 $ By $Author: x-junichik $
 *   Description : to hook gettimeofday()
 *
 ****************************************************************************/
#ifndef JS_TIME_H
#define JS_TIME_H

#include <sys/time.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef int (*gettimeofday_function_t)(struct timeval *tv, struct timezone *tz);
gettimeofday_function_t JS_ReplaceGetTimeOfDay(gettimeofday_function_t functonPointer);

#ifdef __cplusplus
}
#endif

#endif /* JS_TIME_H */
