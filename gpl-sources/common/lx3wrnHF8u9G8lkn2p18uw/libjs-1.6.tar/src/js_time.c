/*****************************************************************************
 *
 * Copyright 2008 Sony Corporation
 *
 * The information contained here-in is the property of Sony corporation and
 * is not to be disclosed or used without the prior written permission of
 * Sony corporation. This copyright extends to all media in which this
 * information may be preserved including magnetic storage, computer
 * print-out or visual display.
 *
 * Contains proprietary information, copyright and database rights Sony.
 * Decompilation prohibited save as permitted by law. No using, disclosing,
 * reproducing, accessing or modifying without Sony prior written consent.
 *
 *****************************************************************************
 *
 *   File Name   : src/shared/js/src/js_time.c
 *   Created     : 2009/11/02 By NAGUMO Keisuke
 *   Modified    : $DateTime: 2009/11/18 16:31:09 $ By $Author: x-junichik $
 *   Description : to hook gettimeofday()
 *
 ****************************************************************************/

#include <stdlib.h>
#include "js_time.h"

static gettimeofday_function_t gettimeofday_libjs_hook = gettimeofday;

int gettimeofday_libjs(struct timeval *tv, struct timezone *tz) {
    return gettimeofday_libjs_hook(tv, tz);
}

gettimeofday_function_t JS_ReplaceGetTimeOfDay(gettimeofday_function_t functonPointer) {
    gettimeofday_function_t old = gettimeofday_libjs_hook;
    if (functonPointer == NULL) {
        functonPointer = gettimeofday;
    }
    gettimeofday_libjs_hook = functonPointer;
    return old;
}
