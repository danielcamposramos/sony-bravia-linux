#include <kjs/JSLock.h>
