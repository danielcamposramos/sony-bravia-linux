/* 
 * Copyright 2002-2005 Sony Corporation.
 *
 */

/*
 * Copyright 1999-2001 Red Hat, Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
*/

#ifndef __SSLIBC__
#include <alloca.h>
#endif /* __SSLIBC__*/
#include <ctype.h>
#include <fcntl.h>
#include <popt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "pump.h"

/* DEBUG */
#if defined(DEBUG)
#define DPRINT(...)  \
	do{ \
		fprintf(stderr, "[%s:%d]", __FILE__, __LINE__); \
		fprintf(stderr, __VA_ARGS__); \
	}while(0)
#else /*!DEBUG*/
#define DPRINT(...)
#endif /*!DEBUG*/

static void parseError(int line, char * message)
{
	DPRINT("error parsing config file at line %d: %s\n", line, message);
}

static int readStanza(char ** cfg, struct pumpOverrideInfo * overrideList, 
	              struct pumpOverrideInfo * override, int * lineNum) {
    struct pumpOverrideInfo * nextO = override + 1;
    char * start, * end, * next, * rest, * chptr;
    int line;
    int argc;
    const char ** argv;
    int num;

    if (!lineNum) {
	line = 1;
	lineNum = &line;
    }

    next = *cfg;
    while (next && *next) {
	start = next;

#ifdef __SNSC_PATCH__
	while (isspace((unsigned char)*start) && *start != '\n') start++;
#else
	while (isspace(*start) && *start != '\n') start++;
#endif
	if (*start == '\n') {
	    next = start + 1;
	    (*lineNum)++;
	    continue;
	} else if (*start == '#') {
	    next = strchr(start, '\n') + 1;
	    (*lineNum)++;
	    continue;
	}

	end = strchr(start, '\n');
	*end = '\0';
	next = end + 1;

	chptr = start;
#ifdef __SNSC_PATCH__
	while (!isspace((unsigned char)*chptr) && *chptr) chptr++;
#else
	while (!isspace(*chptr) && *chptr) chptr++;
#endif
	rest = chptr;
#ifdef __SNSC_PATCH__
	while (*rest && isspace((unsigned char)*rest)) rest++;
#else
	while (*rest && isspace(*rest)) rest++;
#endif
	*chptr = '\0';

	if (!strcmp(start, "device")) {
	    if (overrideList != override) {
		parseError(*lineNum, "device directive may not occur inside "
			   "of device specification");
		return 1;
	    }

	    if (!*rest || *rest == '{') {
		parseError(*lineNum, "device directive must be followed by a "
			   "device name");
		return 1;
	    }

	    end = rest + 1;
#ifdef __SNSC_PATCH__
	    while (!isspace((unsigned char)*end) && *end != '{' && *end) end++;
#else
	    while (!isspace(*end) && *end != '{' && *end) end++;
#endif
	    chptr = end;
#ifdef __SNSC_PATCH__
	    while (isspace((unsigned char)*end) && *end) end++;
#else
	    while (isspace(*end) && *end) end++;
#endif

	    if (*end != '{') {
		parseError(*lineNum, "device directive must end with a {");
		return 1;
	    }

	    end++;
	    *chptr = '\0';

#ifdef __SNSC_PATCH__
	    while (*end && isspace((unsigned char)*end)) end++;
#else
	    while (*end && isspace(*end)) end++;
#endif
	    if (*end) {
		parseError(*lineNum, "unexpected information after {");
		return 1;
 	    }
	
	    *nextO = *override;
	    strcpy(nextO->intf.device, rest);
	    nextO->script = override->script ? strdup(override->script) : NULL;

	    (*lineNum)++;
	    if (readStanza(&next, overrideList, nextO, lineNum)) return 1;
	    (*lineNum)--;	/* it'll get incremented again at the end
				   of this while loop */
	    nextO++;
	} else if (!strcmp(start, "}")) {
	    if (overrideList == override) {
		parseError(*lineNum,"} may only occur inside of a "
			   "device directive");
		return 1;
	    } else if (*rest) {
		parseError(*lineNum, "unexpected information after }");
	    }

	    *cfg = next;
	    (*lineNum)++;

	    return 0;
	}
#ifdef __AUTOIP__
        else if (!strcmp(start, "autoip_lease_sec")) {
	    poptParseArgvString(rest, &argc, &argv);

	    if (argc != 1) {
		parseError(*lineNum, "autoip_lease_sec directive expects a "
			   "single argument");
		return 1;
	    }

	    num = strtol(argv[0], &chptr, 0);
	    if (*chptr) {
		parseError(*lineNum, "autoip_lease_sec requires a numeric argument");
		return 1;
	    }

#ifdef __SNSC_PATCH__
	    if (num <= 0){
		parseError(*lineNum, "timeout requires a positive value");
		return 1;
	    }
#endif /* __SNSC_PATCH__ */
	    override->autoip_lease_sec = num;
	}
#endif /* __AUTOIP__ */
#ifdef __TUNEUP__
        else if (!strcmp(start, "tscale")) {
	    poptParseArgvString(rest, &argc, &argv);

	    if (argc != 1) {
		parseError(*lineNum, "tscale directive expects a "
			   "single argument");
		return 1;
	    }

	    num = strtol(argv[0], &chptr, 0);
	    if (*chptr) {
		parseError(*lineNum, "tscale requires a numeric argument");
		return 1;
	    }

	    if (num > 10){
		parseError(*lineNum, "tscale requires <= 10");
		return 1;
	    }
	    if (num <= 0){
		parseError(*lineNum, "tscale requires a positive value");
		return 1;
	    }
	    override->tscale = num;
	}
        else if (!strcmp(start, "delayed_start")) {
	    poptParseArgvString(rest, &argc, &argv);

	    if (argc != 1) {
		parseError(*lineNum, "delayed_start directive expects a "
			   "single argument");
		return 1;
	    }

	    num = strtol(argv[0], &chptr, 0);
	    if (*chptr) {
		parseError(*lineNum, "delayed_start requires a numeric argument");
		return 1;
	    }

	    if (num <= 0){
		parseError(*lineNum, "delayed_start requires a positive value");
		return 1;
	    }
	    override->delayed_start = num;
 	}
#endif /* __TUNEUP__ */
        else if (!strcmp(start, "timeout")) {
	    poptParseArgvString(rest, &argc, &argv);

	    if (argc != 1) {
		parseError(*lineNum, "timeout directive expects a "
			   "single argument");
		return 1;
	    }

	    num = strtol(argv[0], &chptr, 0);
	    if (*chptr) {
		parseError(*lineNum, "timeout requires a numeric argument");
		return 1;
	    }
#ifdef __SNSC_PATCH__
	    if (num <= 0){
		parseError(*lineNum, "timeout requires a positive value");
		return 1;
	    }
#endif /* __SNSC_PATCH__ */

	    override->timeout = num;
	} else if (!strcmp(start, "retries")) {
	    poptParseArgvString(rest, &argc, &argv);

	    if (argc != 1) {
		parseError(*lineNum, "retries directive expects a "
			   "single argument");
		return 1;
	    }

	    num = strtol(argv[0], &chptr, 0);
	    if (*chptr) {
		parseError(*lineNum, "retries requires a numeric argument");
		return 1;
	    }

	    override->numRetries = num;
	} else if (!strcmp(start, "domainsearch")) {
	    if (overrideList != override) {
		parseError(*lineNum, "domainsearch directive may not occur "
			   "inside of device specification");
		return 1;
	    }

	    poptParseArgvString(rest, &argc, &argv);

	    if (argc != 1) {
		parseError(*lineNum, "domainsearch directive expects a "
			   "single argument");
		return 1;
	    }

	    /*
		We don't free this as other configurations may have inherited 
		it. This could be the wrong decision, but leak would be tiny
		so why worry?
	    */
	    override->searchPath = strdup(argv[0]);
	    free(argv);
	} 
#ifdef __AUTOIP__
	else if (!strcmp(start, "clientid")) {
	    poptParseArgvString(rest, &argc, &argv);

	    if (argc != 1) {
		parseError(*lineNum, "clientid directive expects a "
			   "single argument");
		return 1;
	    }

	    /*
		We don't free this as other configurations may have inherited 
		it. This could be the wrong decision, but leak would be tiny
		so why worry?
	    */
	    override->clientId = strdup(argv[0]);
	    free(argv);
#ifdef __SNSC_PATCH__
	    /* vendor parameter len is 1 byte field */
	    if (strlen(override->clientId) > 255) { 
		parseError(*lineNum, "clientid size too large");
		return 1;
	    }
#endif /* __SNSC_PATCH__ */
	} else if (!strcmp(start, "scopeid")) {
	    poptParseArgvString(rest, &argc, &argv);

	    if (argc != 1) {
		parseError(*lineNum, "scopeid directive expects a "
			   "single argument");
		return 1;
	    }

	    /*
		We don't free this as other configurations may have inherited 
		it. This could be the wrong decision, but leak would be tiny
		so why worry?
	    */
	    override->scopeId = strdup(argv[0]);
	    free(argv);
#ifdef __SNSC_PATCH__
	    /* vendor parameter len is 1 byte field */
	    if (strlen(override->scopeId) > 255) { 
		parseError(*lineNum, "scopeid size too large");
		return 1;
	    }
#endif /* __SNSC_PATCH__ */
	} else if (!strcmp(start, "linkcheck")) {
	    if (*rest) {
		parseError(*lineNum, "unexpected argument to linkcheck directive");
		return 1;
	    }
	    override->flags |= OVERRIDE_FLAG_LINKCHECK;
	} else if (!strcmp(start, "autoip")) {
	    if (*rest) {
		parseError(*lineNum, "unexpected argument to autoip directive");
		return 1;
	    }
	    override->flags |= OVERRIDE_FLAG_AUTOIP;
	} 
#endif /* __AUTOIP__ */
	else if (!strcmp(start, "nodns")) {
	    if (*rest) {
		parseError(*lineNum, "unexpected argument to nodns directive");
		return 1;
	    }
	    override->flags |= OVERRIDE_FLAG_NODNS;
	} else if (!strcmp(start, "nobootp")) {
	    if (*rest) {
		parseError(*lineNum, "unexpected argument to nobootp directive");
		return 1;
	    }
	    override->flags |= OVERRIDE_FLAG_NOBOOTP;
	} else if (!strcmp(start, "nogateway")) {
	    if (*rest) {
		parseError(*lineNum, "unexpected argument to nogateway directive");
		return 1;
	    }
	    override->flags |= OVERRIDE_FLAG_NOGATEWAY;
	} else if (!strcmp(start, "nonisdomain")) {
	    if (*rest) {
		parseError(*lineNum, "unexpected argument to nonisdomain directive");
		return 1;
	    }
	    override->flags |= OVERRIDE_FLAG_NONISDOMAIN;
	} else if (!strcmp(start, "script")) {
	    if (overrideList != override) {
		parseError(*lineNum, "script directive may not occur "
			   "inside of device specification");
		return 1;
	    }

	    poptParseArgvString(rest, &argc, &argv);

	    if (argc != 1) {
		parseError(*lineNum, "script directive expects a "
			   "single argument");
		return 1;
	    }
	    override->script = strdup(argv[0]);
	    free(argv);
        } else {
	    char * error;

	    error = malloc(strlen(start) + 50);
#ifdef __SNSC_PATCH__
            if (!error) { return 1; }
#endif
	    sprintf(error, "unrecognized directive %s", start);
	    parseError(*lineNum, error);
	    free(error);

	    return 1;
	}

	(*lineNum)++;
    }

    *cfg = next;
   
    return 0; 
}

int readPumpConfig(char * configFile, struct pumpOverrideInfo ** overrides) {
    int fd;
    char * buf, * chptr;
    struct stat sb;
    int count;
    void * orig = *overrides;

    if ((fd = open(configFile, O_RDONLY)) < 0) {
	*overrides = calloc(sizeof(**overrides), 2);
#ifdef __SNSC_PATCH__
        if (!*overrides) { return 1; }
        pumpInitOverride(*overrides);
#else /* __SNSC_PATCH__ */
	pumpInitOverride(*overrides);
	close(fd);
#endif /* __SNSC_PATCH__ */
	return 0;
    }

    fstat(fd, &sb);
    buf = alloca(sb.st_size + 2);
#ifdef __SNSC_PATCH__
    if (!buf || read(fd, buf, sb.st_size) != sb.st_size) {
#else /* __SNSC_PATCH__ */
    if (read(fd, buf, sb.st_size) != sb.st_size) {
#endif /* __SNSC_PATCH__ */
	close(fd);
	return 1;
    }
    close(fd);
    buf[sb.st_size] = '\n';
    buf[sb.st_size + 1] = '\0';

    /* this will give us an upper limit anyway */
    count = 1;
    chptr = buf;
    while ((chptr = strchr(chptr, '{'))) {
	chptr++;
	count++;
    }

    *overrides = calloc(sizeof(**overrides), count + 1);
#ifdef __SNSC_PATCH__
    if (!*overrides) { return 1; }
#endif /* __SNSC_PATCH__ */
    pumpInitOverride(*overrides);

    count = readStanza(&buf, *overrides, *overrides, NULL);
    if (count) {
	free(*overrides);
	*overrides = orig;
    }

    return count; 
}
