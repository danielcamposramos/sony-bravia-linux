/* 
 * Copyright 2002-2008 Sony Corporation.
 *
 */

/*
 * Copyright 1999-2001 Red Hat, Inc.
 * 
 * All Rights Reserved.
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * OPEN GROUP BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
 * AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 * 
 * Except as contained in this notice, the name of Red Hat shall not be
 * used in advertising or otherwise to promote the sale, use or other dealings
 * in this Software without prior written authorization from Red Hat.
 *
 */

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <net/ethernet.h>
#include <net/if.h>

#ifdef __SSLIBC__
#include <linux/if_ether.h>
#define IFHWADDRLEN     6
struct  ether_arp {
        struct  arphdr ea_hdr;          /* fixed-size header */
        u_int8_t arp_sha[ETH_ALEN];     /* sender hardware address */
        u_int8_t arp_spa[4];            /* sender protocol address */
        u_int8_t arp_tha[ETH_ALEN];     /* target hardware address */
        u_int8_t arp_tpa[4];            /* target protocol address */
};
#define arp_hrd ea_hdr.ar_hrd
#define arp_pro ea_hdr.ar_pro
#define arp_hln ea_hdr.ar_hln
#define arp_pln ea_hdr.ar_pln
#define arp_op  ea_hdr.ar_op
#endif /*__SSLIBC__*/

#if defined(__AUTOIP__) || defined(__TUNEUP__) || defined(__SNSC_PATCH__)
#include <linux/types.h>
#include <linux/sockios.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <net/if_arp.h>
#include <sys/socket.h>
#include <sys/param.h>
#ifndef __SSLIBC__
#include <netinet/if_ether.h>
#include <sys/sysctl.h>
#endif /*!__SSLIBC__*/

#else /* defined(__AUTOIP__) || defined(__TUNEUP__) */
#include <net/if_packet.h>
#endif /* defined(__AUTOIP__) || defined(__TUNEUP__) */

#include <net/route.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <popt.h>
#include <resolv.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <syslog.h>
#include <unistd.h>
#include <time.h>

#include "pump.h"

typedef int bp_int32;
typedef short bp_int16;

#define _(a) (a)

#define BOOTP_OPTION_NETMASK		1
#define BOOTP_OPTION_GATEWAY		3
#define BOOTP_OPTION_DNS		6
#define BOOTP_OPTION_HOSTNAME		12
#define BOOTP_OPTION_BOOTFILE		13
#define BOOTP_OPTION_DOMAIN		15
#define BOOTP_OPTION_BROADCAST		28
#define BOOTP_OPTION_NISDOMAIN		40

#define DHCP_OPTION_LOGSRVS		7
#define DHCP_OPTION_LPRSRVS		9
#define DHCP_OPTION_NTPSRVS		42
#define DHCP_OPTION_XFNTSRVS		48
#define DHCP_OPTION_XDMSRVS		49
#define DHCP_OPTION_REQADDR		50
#define DHCP_OPTION_LEASE		51
#define DHCP_OPTION_OVERLOAD		52
#define DHCP_OPTION_TYPE		53
#define DHCP_OPTION_SERVER		54
#define DHCP_OPTION_OPTIONREQ		55
#define DHCP_OPTION_MAXSIZE		57
#define DHCP_OPTION_T1			58
#define DHCP_OPTION_CLIENT_IDENTIFIER	61

#ifdef __AUTOIP__
#define DHCP_OPTION_SCOPE_IDENTIFIER    47
#endif

#define BOOTP_CLIENT_PORT	68
#define BOOTP_SERVER_PORT	67

#define BOOTP_OPCODE_REQUEST	1
#define BOOTP_OPCODE_REPLY	2

#define NORESPONSE		-10
#define DHCP_TYPE_DISCOVER	1
#define DHCP_TYPE_OFFER		2
#define DHCP_TYPE_REQUEST	3
#define DHCP_TYPE_DECLINE	4
#define DHCP_TYPE_ACK		5
#define DHCP_TYPE_NAK		6
#define DHCP_TYPE_RELEASE	7
#define DHCP_TYPE_INFORM	8

#ifndef __AUTOIP__
#define DEFAULT_NUM_RETRIES	5
#define DEFAULT_TIMEOUT 	30
#endif

#define BOOTP_VENDOR_LENGTH	64
#define DHCP_VENDOR_LENGTH	312

#define TRANSMISSION_TIME	1

struct bootpRequest {
    char opcode;
    char hw;
    char hwlength;
    char hopcount;
    bp_int32 xid;
    bp_int16 secs;
    bp_int16 flags;
    bp_int32 ciaddr, yiaddr, server_ip, bootp_gw_ip;
    char hwaddr[16];
    char servername[64];
    char bootfile[128];
    char vendor[DHCP_VENDOR_LENGTH];
} ;

struct psuedohUdpHeader {
    bp_int32 source, dest;
    char zero;
    char protocol;
    bp_int16 len;
};

struct arppkt{
	struct ether_arp arpbody;
};

#ifndef __SNSC_PATCH__
static void parseReply(struct bootpRequest * breq, struct pumpNetIntf * intf);
#else /* __SNSC_PATCH__ */
static int parseReply(struct bootpRequest * breq, struct pumpNetIntf * intf);
#endif /* __SNSC_PATCH__ */
static char * prepareRequest(struct bootpRequest * breq,
			     int sock, char * device, time_t startTime);
static void parseLease(struct bootpRequest * bresp, struct pumpNetIntf * intf);
static void initVendorCodes(struct bootpRequest * breq);
static char * handleTransaction(int s, struct pumpOverrideInfo * override, 
				struct bootpRequest * breq,
			        struct bootpRequest * bresp, 
			        struct sockaddr_in * serverAddr,
				struct sockaddr_in * respondant,
				int useBootpPacket, 
				time_t startTime, int dhcpResponseType);
static int dhcpMessageType(struct bootpRequest * response);
static int oldKernel(void);
static char * getInterfaceInfo(struct pumpNetIntf * intf, int s);
static char * perrorstr(char * msg);
static void addClientIdentifier(int flags, struct bootpRequest * req);
static void buildRequest(struct bootpRequest * req, int flags, int type,
		         char * reqHostname, int lease);
static void updateSecCount(struct bootpRequest * breq, time_t startTime);

static const char vendCookie[] = { 99, 130, 83, 99, 255 };

#ifdef __SNSC_PATCH__
/* handle raw packet */
static int make_ip_header4dhcp(int sock, char *interface, char *p, 
                               void *msg, u_int32_t msg_len, int flag);
static void recalculateUdphdr(char *buf, u_int32_t len);
static u_int16_t checksum(const u_int16_t *data, int len, long init);
#endif /* __SNSC_PATCH__ */

#ifdef __TUNEUP__
time_t pumpUptimeTuned(void);
#endif /* __TUNEUP__ */

#ifdef __AUTOIP__
static char* configClientId = NULL;
static char* configScopeId = NULL;
#endif /* __AUTOIP__ */

/* DEBUG */
#if defined(DEBUG)
#define DPRINT(...)  \
	do{ \
		fprintf(stderr, "[%s:%d]", __FILE__, __LINE__); \
		fprintf(stderr, __VA_ARGS__); \
	}while(0)
#else /*!DEBUG*/
#define DPRINT(...)
#endif /*!DEBUG*/

static int oldKernel(void) {
    struct utsname ubuf;
    int major1, major2;

    uname(&ubuf);
    if (!strcasecmp(ubuf.sysname, "linux")) {
	if (sscanf(ubuf.release, "%d.%d", &major1, &major2) != 2 ||
		(major1 < 2) || (major1 == 2 && major2 == 0)) {
	    return 1;
	}
    }

    return 0;
}

static char * getInterfaceInfo(struct pumpNetIntf * intf, int s) {
    struct ifreq req;
    struct sockaddr_in * addrp;

    memset(&req,0,sizeof(req));
    strcpy(req.ifr_name, intf->device);
    if (ioctl(s, SIOCGIFBRDADDR, &req))
	return perrorstr("SIOCGIFBRDADDR");

    addrp = (struct sockaddr_in *) &req.ifr_addr;
    intf->broadcast = addrp->sin_addr;
    intf->set = PUMP_INTFINFO_HAS_BROADCAST;

    return NULL;
}


static char * perrorstr(char * msg) {
    static char * err = NULL;
    static int errsize = 0;
    static int newsize;

    newsize = strlen(msg) + strlen(strerror(errno)) + 3;
    if (!errsize) {
	errsize = newsize;
	err = malloc(errsize);
    } else if (errsize < newsize) {
	free(err);
	errsize = newsize;
	err = malloc(errsize);
    } 
 
    if (err)
        sprintf(err, "%s: %s", msg, strerror(errno));
    else
	err = "out of memory!";

    return err;
}

#ifdef __AUTOIP__
static int
getIfInfo(char *devname, struct ifreq *ifreq, int flavor)
{
	int iofd;
	int retv;

	memset(ifreq, 0, sizeof(*ifreq));
	strncpy(ifreq->ifr_name, devname, IFNAMSIZ - 1);

	if((iofd = socket(AF_INET, SOCK_DGRAM, 0)) == -1){
		return -1;
	}
	retv = ioctl(iofd, flavor, ifreq);
	close(iofd);
	return retv;
}
#endif /*__AUTOIP__*/

#if defined(__SNSC_PATCH__) && defined(WLAN)
static int
CheckInterfaceIsWlan(char *device)
{
     int ret;
     FILE *fp;
     char *pbuf, *p, *pe;

     if(!(fp = fopen(PUMP_WLAN_DEV_FILE, "r"))) {
	  ret = -errno;
	  DPRINT("pump: fopen %s fail(%d)\n", PUMP_WLAN_DEV_FILE, ret);
	  return ret;
     }

     pbuf = (char*)calloc(PUMP_WLAN_RBUF_SIZE, sizeof(char));
     if(pbuf == NULL) {
	  ret = -errno;
	  fclose(fp);
	  DPRINT("pump: calloc fail(%d)\n", ret);
	  return ret;
     }

     fgets(pbuf, PUMP_WLAN_RBUF_SIZE, fp); /* Skip top line    */
     fgets(pbuf, PUMP_WLAN_RBUF_SIZE, fp); /* Skip second line */

     ret = 0;
     while(fgets(pbuf, PUMP_WLAN_RBUF_SIZE, fp)) {
	  p = pbuf;
#ifdef __SNSC_PATCH__
	  while(*p && (iscntrl((unsigned char)*p) || *p == ' ')) p++;
#else
	  while(*p && (iscntrl(*p) || *p == ' ')) p++;
#endif
	  if(*p){
	       if((pe = strchr(p, ':')) != NULL) {
		    *pe = 0;
		    if(strcmp(p, device) == 0) {
			 ret = 1;
			 break;
		    }
	       }
	  }
     }
     free(pbuf);
     fclose(fp);
     return ret;
}
#endif

char * pumpDisableInterface(char * device) {
    struct ifreq req;
    int s;

#if defined(__SNSC_PATCH__) && defined(WLAN)
    if( CheckInterfaceIsWlan(device) == 1 ){
      DPRINT("pump: skip disabling interface\n");
      return NULL;
    }
#endif

#ifdef DISABLE_IF_DOWN_EXCEPT_NO_LINK
    if(pumpAutoipMiiTool(device) != 0){
	/* Link OK or error */
	return NULL;
    }
#endif /* DISABLE_IF_DOWN_EXCEPT_NO_LINK */

    s = socket(AF_INET, SOCK_DGRAM, 0);
#ifdef __SNSC_PATCH__
    if (s < 0) { return perrorstr("socket:AF_INET"); }
#endif /* __SNSC_PATCH__ */
	
    memset(&req,0,sizeof(req));

    strcpy(req.ifr_name, device);
    if (ioctl(s, SIOCGIFFLAGS, &req)) {
	close(s);
	return perrorstr("SIOCGIFFLAGS");
    }

    req.ifr_flags &= ~(IFF_UP | IFF_RUNNING);
    if (ioctl(s, SIOCSIFFLAGS, &req)) {
	close(s);
	return perrorstr("SIOCSIFFLAGS");
    }

    close(s);

    return NULL;
}

char * pumpSetupInterface(struct pumpNetIntf * intf) {
    char * rc;
    struct sockaddr_in * addrp;
    struct ifreq req;
    struct rtentry route;
    int s;

    if ((rc = pumpDisableInterface(intf->device))) return rc;

    s = socket(AF_INET, SOCK_DGRAM, 0);
#ifdef __SNSC_PATCH__
    if (s < 0) { return perrorstr("socket:AF_INET"); }
#endif /* __SNSC_PATCH__ */
	
    memset(&req,0,sizeof(req));
    memset(&route,0,sizeof(route));
    /* we have to have basic information to get this far */
    addrp = (struct sockaddr_in *) &req.ifr_addr;
    addrp->sin_family = AF_INET;
    strcpy(req.ifr_name, intf->device);
   
    addrp->sin_addr = intf->ip;
    if (ioctl(s, SIOCSIFADDR, &req))
#ifdef __SNSC_PATCH__
    {
            close(s);
            return perrorstr("SIOCSIFADDR");
    }
#else /* __SNSC_PATCH__ */
	return perrorstr("SIOCSIFADDR");
#endif /* __SNSC_PATCH__ */

    addrp->sin_addr = intf->netmask;
    if (ioctl(s, SIOCSIFNETMASK, &req))
#ifdef __SNSC_PATCH__
    {
            close(s);
            return perrorstr("SIOCSIFNETMASK");
    }
#else /* __SNSC_PATCH__ */
        return perrorstr("SIOCSIFNETMASK");
#endif /* __SNSC_PATCH__ */

    addrp->sin_addr = intf->broadcast;
    if (ioctl(s, SIOCSIFBRDADDR, &req))
#ifdef __SNSC_PATCH__
    {
            close(s);
            return perrorstr("SIOCSIFBRDADDR");
    }
#else /* __SNSC_PATCH__ */
	return perrorstr("SIOCSIFBRDADDR");
#endif /* __SNSC_PATCH__ */

    /* Bring up the device, and specifically allow broadcasts through it.
       Don't mess with flags we don't understand though. */
    if (ioctl(s, SIOCGIFFLAGS, &req))
#ifdef __SNSC_PATCH__
    {
            close(s);
            return perrorstr("SIOCGIFFLAGS");
    }
#else /* __SNSC_PATCH__ */
	return perrorstr("SIOCGIFFLAGS");
#endif /* __SNSC_PATCH__ */

    req.ifr_flags |= IFF_UP | IFF_RUNNING | IFF_BROADCAST;

    if (ioctl(s, SIOCSIFFLAGS, &req))
#ifdef __SNSC_PATCH__
    {
            close(s);
            return perrorstr("SIOCSIFFLAGS");
    }
#else /* __SNSC_PATCH__ */
	return perrorstr("SIOCSIFFLAGS");
#endif /* __SNSC_PATCH__ */

    if (!strcmp(intf->device, "lo") || oldKernel()) {
	/* add a route for this network */
	route.rt_dev = intf->device;
	route.rt_flags = RTF_UP;
	route.rt_metric = 0;

	addrp->sin_family = AF_INET;
	addrp->sin_port = 0;
	addrp->sin_addr = intf->network;
	memcpy(&route.rt_dst, addrp, sizeof(*addrp));
	addrp->sin_addr = intf->netmask;
	memcpy(&route.rt_genmask, addrp, sizeof(*addrp));

	if (ioctl(s, SIOCADDRT, &route)) {
	    /* the route cannot already exist, as we've taken the device down */
#ifdef __SNSC_PATCH__
            close(s);
#endif /* __SNSC_PATCH__ */
	    return perrorstr("SIOCADDRT 1");
	}
    }
#ifdef __SNSC_PATCH__
    close(s);
#endif /* __SNSC_PATCH__ */
    return NULL;
}

int pumpSetupDefaultGateway(struct in_addr * gw) {
    struct sockaddr_in addr;
    struct rtentry route;
    int s;

    s = socket(AF_INET, SOCK_DGRAM, 0);
#ifdef __SNSC_PATCH__
    if (s < 0) { 
#ifndef __DISABLE_LOG_ERR__
            syslog(LOG_ERR, "socket:AF_INET"); 
#endif  /* !__DISABLE_LOG_ERR__ */
            return -1;
    }
#endif /* __SNSC_PATCH__ */
	
    memset(&addr,0,sizeof(addr));
    memset(&route,0,sizeof(route));
    addr.sin_family = AF_INET;
    addr.sin_port = 0;
    addr.sin_addr.s_addr = INADDR_ANY;
    memcpy(&route.rt_dst, &addr, sizeof(addr));
    memcpy(&route.rt_genmask, &addr, sizeof(addr));
    addr.sin_addr = *gw;
    memcpy(&route.rt_gateway, &addr, sizeof(addr));
    
    route.rt_flags = RTF_UP | RTF_GATEWAY;
    route.rt_metric = 0;
    route.rt_dev = NULL;

    if (ioctl(s, SIOCADDRT, &route)) {
#ifdef __SNSC_PATCH__
            close(s);
#endif /* __SNSC_PATCH__ */
#ifndef __DISABLE_LOG_ERR__
	syslog(LOG_ERR, "failed to set default route: %s", strerror(errno));
#endif  /* !__DISABLE_LOG_ERR__ */
	return -1;
    }
#ifdef __SNSC_PATCH__
    close(s);
#endif /* __SNSC_PATCH__ */
    return 0;
}

char * pumpPrepareInterface(struct pumpNetIntf * intf, int s) {
    struct sockaddr_in * addrp;
    struct ifreq req;
    struct rtentry route;

    memset(&req,0,sizeof(req));

    addrp = (struct sockaddr_in *) &req.ifr_addr;

    strcpy(req.ifr_name, intf->device);
    addrp->sin_family = AF_INET;
    addrp->sin_port = 0;
    memset(&addrp->sin_addr, 0, sizeof(addrp->sin_addr));

    addrp->sin_family = AF_INET;
    addrp->sin_addr.s_addr = htonl(0);

    if (ioctl(s, SIOCSIFADDR, &req))
	return perrorstr("SIOCSIFADDR");

    if (oldKernel()) {
	if (ioctl(s, SIOCSIFNETMASK, &req))
	    return perrorstr("SIOCSIFNETMASK");

	/* the broadcast address is 255.255.255.255 */
	memset(&addrp->sin_addr, 255, sizeof(addrp->sin_addr));
	if (ioctl(s, SIOCSIFBRDADDR, &req))
	    return perrorstr("SIOCSIFBRDADDR");
    }

    if (ioctl(s, SIOCGIFFLAGS, &req))
	return perrorstr("SIOCGIFFLAGS");
    req.ifr_flags |= IFF_UP | IFF_BROADCAST | IFF_RUNNING;
    if (ioctl(s, SIOCSIFFLAGS, &req))
	return perrorstr("SIOCSIFFLAGS");

    memset(&route, 0, sizeof(route));
    memcpy(&route.rt_gateway, addrp, sizeof(*addrp));

    addrp->sin_family = AF_INET;
    addrp->sin_port = 0;
    addrp->sin_addr.s_addr = INADDR_ANY;
    memcpy(&route.rt_dst, addrp, sizeof(*addrp));
    memcpy(&route.rt_genmask, addrp, sizeof(*addrp));

    route.rt_dev = intf->device;
    route.rt_flags = RTF_UP;
    route.rt_metric = 0;

    if (ioctl(s, SIOCADDRT, &route)) {
	if (errno != EEXIST) {
	    close(s);
	    return perrorstr("SIOCADDRT 3");
	}
    }

    return NULL;
}

static int dhcpMessageType(struct bootpRequest * response) {
    unsigned char * chptr;
    unsigned char option, length;
   
    chptr = (unsigned char*)response->vendor;

    chptr += 4;
    while (*chptr != 0xFF) {
	option = *chptr++;
	if (!option) continue;
	length = *chptr++;
	if (option == DHCP_OPTION_TYPE)
	    return *chptr;

	chptr += length;
#ifdef __SNSC_PATCH__
	if ( ((char *)chptr - response->vendor) >= DHCP_VENDOR_LENGTH) return -1;
#else /* __SNSC_PATCH__ */
	if ( ((void *)chptr - (void *)response->vendor) >= DHCP_VENDOR_LENGTH) return -1;
#endif /* __SNSC_PATCH__ */
    }

    return -1;
}

static void setMissingIpInfo(struct pumpNetIntf * intf) {
#ifdef __SNSC_PATCH__
    u_int32_t ipNum = *((u_int32_t *) &intf->ip);
    u_int32_t nmNum = *((u_int32_t *) &intf->netmask);
    u_int32_t ipRealNum = ntohl(ipNum);
#else /* __SNSC_PATCH__ */
    bp_int32 ipNum = *((bp_int32 *) &intf->ip);
    bp_int32 nmNum = *((bp_int32 *) &intf->netmask);
    bp_int32 ipRealNum = ntohl(ipNum);
#endif /* __SNSC_PATCH__ */

    if (!(intf->set & PUMP_INTFINFO_HAS_NETMASK)) {
	if (((ipRealNum & 0xFF000000) >> 24) <= 127)
	    nmNum = 0xFF000000;
	else if (((ipRealNum & 0xFF000000) >> 24) <= 191)
	    nmNum = 0xFFFF0000;
	else 
	    nmNum = 0xFFFFFF00;
#ifdef __SNSC_PATCH__
        *((u_int32_t *) &intf->netmask) = nmNum = htonl(nmNum);
#else /* __SNSC_PATCH__ */
	*((bp_int32 *) &intf->netmask) = nmNum = htonl(nmNum);
#endif /* __SNSC_PATCH__ */
#ifndef __DISABLE_LOG_DEBUG__
	syslog (LOG_DEBUG, "intf: netmask: %s", inet_ntoa (intf->netmask));
#endif	/* !__DISABLE_LOG_DEBUG__ */
    }

    if (!(intf->set & PUMP_INTFINFO_HAS_BROADCAST)) {
#ifdef __SNSC_PATCH__
	*((u_int32_t *) &intf->broadcast) = (ipNum & nmNum) | ~(nmNum);
#else /* __SNSC_PATCH__ */
	*((bp_int32 *) &intf->broadcast) = (ipNum & nmNum) | ~(nmNum);
#endif /* __SNSC_PATCH__ */
#ifndef __DISABLE_LOG_DEBUG__
	syslog (LOG_DEBUG, "intf: broadcast: %s", inet_ntoa (intf->broadcast));
#endif	/* !__DISABLE_LOG_DEBUG__ */
    }

    if (!(intf->set & PUMP_INTFINFO_HAS_NETWORK)) {
#ifdef __SNSC_PATCH__
	*((u_int32_t *) &intf->network) = ipNum & nmNum;
#else /* __SNSC_PATCH__ */
	*((bp_int32 *) &intf->network) = ipNum & nmNum;
#endif /* __SNSC_PATCH__ */
#ifndef __DISABLE_LOG_DEBUG__
	syslog (LOG_DEBUG, "intf: network: %s", inet_ntoa (intf->network));
#endif	/* !__DISABLE_LOG_DEBUG__ */
    }

    intf->set |= PUMP_INTFINFO_HAS_BROADCAST | PUMP_INTFINFO_HAS_NETWORK | 
		 PUMP_INTFINFO_HAS_NETMASK;
}

#ifndef __SNSC_PATCH__
static void parseReply(struct bootpRequest * breq, struct pumpNetIntf * intf) {
#else /* __SNSC_PATCH__ */
static int parseReply(struct bootpRequest * breq, struct pumpNetIntf * intf) {
#endif /* __SNSC_PATCH__ */
    unsigned int i;
    unsigned char * chptr;
    unsigned char option, length;

#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "intf: device: %s", intf->device);
#ifdef __SNSC_PATCH__
    syslog (LOG_DEBUG, "intf: set: 0x%x", intf->set);
#else /* __SNSC_PATCH__ */
    syslog (LOG_DEBUG, "intf: set: %i", intf->set);
#endif /* __SNSC_PATCH__ */
    syslog (LOG_DEBUG, "intf: bootServer: %s", inet_ntoa (intf->bootServer));
    syslog (LOG_DEBUG, "intf: reqLease: %i", intf->reqLease);
#endif	/* !__DISABLE_LOG_DEBUG__ */

    i = ~(PUMP_INTFINFO_HAS_IP | PUMP_INTFINFO_HAS_NETMASK | PUMP_INTFINFO_HAS_NETWORK |
	  PUMP_INTFINFO_HAS_BROADCAST);
    intf->set &= i;

#ifdef __SNSC_PATCH__
    if(memchr(breq->bootfile, '\0', sizeof(breq->bootfile)) == NULL)
        return EINVAL;
#endif /* __SNSC_PATCH__ */
    if (strlen(breq->bootfile)) {
	intf->bootFile = strdup(breq->bootfile);
	intf->set |= PUMP_INTFINFO_HAS_BOOTFILE;
#ifndef __DISABLE_LOG_DEBUG__
	syslog (LOG_DEBUG, "intf: bootFile: %s", intf->bootFile);
#endif	/* !__DISABLE_LOG_DEBUG__ */
    } else {
	intf->set &= ~PUMP_INTFINFO_HAS_BOOTFILE;
    }

    memcpy(&intf->ip, &breq->yiaddr, 4);
    intf->set |= PUMP_INTFINFO_HAS_IP;
#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "intf: ip: %s", inet_ntoa (intf->ip));
#endif	/* !__DISABLE_LOG_DEBUG__ */

    memcpy(&intf->nextServer, &breq->server_ip, 4);
    intf->set |= PUMP_INTFINFO_HAS_NEXTSERVER;
#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "intf: next server: %s", inet_ntoa (intf->nextServer));
#endif	/* !__DISABLE_LOG_DEBUG__ */

    chptr = (unsigned char*)breq->vendor;
    chptr += 4;
#ifdef __SNSC_PATCH__
    while (*chptr != 0xFF && (char *) chptr < breq->vendor + DHCP_VENDOR_LENGTH) {
#else /* __SNSC_PATCH__ */
    while (*chptr != 0xFF && (void *) chptr < (void *) breq->vendor + DHCP_VENDOR_LENGTH) {
#endif /* __SNSC_PATCH__ */
	option = *chptr++;
	if (!option) continue;
	length = *chptr++;

	switch (option) {
	    case BOOTP_OPTION_DNS:
		intf->numDns = 0;
		for (i = 0; i < length; i += 4) {
		    if (intf->numDns < MAX_DNS_SERVERS) {
			memcpy(&intf->dnsServers[intf->numDns++], chptr + i, 4);
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "intf: dnsServers[%i]: %s", 
			       i/4, inet_ntoa (intf->dnsServers[i/4]));
#endif	/* !__DISABLE_LOG_DEBUG__ */
		    }
		}
		intf->set |= PUMP_NETINFO_HAS_DNS;
#ifndef __DISABLE_LOG_DEBUG__
		syslog (LOG_DEBUG, "intf: numDns: %i", intf->numDns);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		break;

	    case BOOTP_OPTION_NETMASK:
		memcpy(&intf->netmask, chptr, 4);
		intf->set |= PUMP_INTFINFO_HAS_NETMASK;
#ifndef __DISABLE_LOG_DEBUG__
		syslog (LOG_DEBUG, "intf: netmask: %s", inet_ntoa (intf->netmask));
#endif	/* !__DISABLE_LOG_DEBUG__ */
		break;

	    case BOOTP_OPTION_NISDOMAIN:
		if ((intf->nisDomain = malloc(length + 1))) {
		    memcpy(intf->nisDomain, chptr, length);
		    intf->nisDomain[length] = '\0';
		    intf->set |= PUMP_NETINFO_HAS_NISDOMAIN;
#ifndef __DISABLE_LOG_DEBUG__
		    syslog (LOG_DEBUG, "intf: nisDomain: %s", intf->nisDomain);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		}
		break;

	    case BOOTP_OPTION_DOMAIN:
		if ((intf->domain = malloc(length + 1))) {
		    memcpy(intf->domain, chptr, length);
		    intf->domain[length] = '\0';
		    intf->set |= PUMP_NETINFO_HAS_DOMAIN;
#ifndef __DISABLE_LOG_DEBUG__
		    syslog (LOG_DEBUG, "intf: domain: %s", intf->domain);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		}
		break;

	    case BOOTP_OPTION_BROADCAST:
		memcpy(&intf->broadcast, chptr, 4);
		intf->set |= PUMP_INTFINFO_HAS_BROADCAST;
#ifndef __DISABLE_LOG_DEBUG__
		syslog (LOG_DEBUG, "intf: broadcast: %s", inet_ntoa (intf->broadcast));
#endif	/* !__DISABLE_LOG_DEBUG__ */
		break;

	    case BOOTP_OPTION_GATEWAY:
		memcpy(&intf->gateway, chptr, 4);
		intf->set |= PUMP_NETINFO_HAS_GATEWAY;
#ifndef __DISABLE_LOG_DEBUG__
		syslog (LOG_DEBUG, "intf: gateway: %s", inet_ntoa (intf->gateway));
#endif	/* !__DISABLE_LOG_DEBUG__ */
		break;

	    case BOOTP_OPTION_HOSTNAME:
		if ((intf->hostname = malloc(length + 1))) {
		    memcpy(intf->hostname, chptr, length);
		    intf->hostname[length] = '\0';
		    intf->set |= PUMP_NETINFO_HAS_HOSTNAME;
#ifndef __DISABLE_LOG_DEBUG__
		    syslog (LOG_DEBUG, "intf: hostname: %s", intf->hostname);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		}
		break;

	    case BOOTP_OPTION_BOOTFILE:
		/* we ignore this right now */
		break;

	    case DHCP_OPTION_LOGSRVS:
		intf->numLog = 0;
		for (i = 0; i < length; i += 4) {
		    if (intf->numLog < MAX_LOG_SERVERS) {
			memcpy(&intf->logServers[intf->numLog++], chptr + i, 4);
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "intf: logServers[%i]: %s", 
			       i/4, inet_ntoa (intf->logServers[i/4]));
#endif	/* !__DISABLE_LOG_DEBUG__ */
		    }
		}
		intf->set |= PUMP_NETINFO_HAS_LOGSRVS;
#ifndef __DISABLE_LOG_DEBUG__
		syslog (LOG_DEBUG, "intf: numLog: %i", intf->numLog);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		break;

	    case DHCP_OPTION_LPRSRVS:
		intf->numLpr = 0;
		for (i = 0; i < length; i += 4) {
		    if (intf->numLpr < MAX_LPR_SERVERS) {
			memcpy(&intf->lprServers[intf->numLpr++], chptr + i, 4);
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "intf: lprServers[%i]: %s", 
			       i/4, inet_ntoa (intf->lprServers[i/4]));
#endif	/* !__DISABLE_LOG_DEBUG__ */
		    }
		}
		intf->set |= PUMP_NETINFO_HAS_LPRSRVS;
#ifndef __DISABLE_LOG_DEBUG__
		syslog (LOG_DEBUG, "intf: numLpr: %i", intf->numLpr);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		break;

	    case DHCP_OPTION_NTPSRVS:
		intf->numNtp = 0;
		for (i = 0; i < length; i += 4) {
		    if (intf->numNtp < MAX_NTP_SERVERS) {
			memcpy(&intf->ntpServers[intf->numNtp++], chptr + i, 4);
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "intf: ntpServers[%i]: %s", 
			       i/4, inet_ntoa (intf->ntpServers[i/4]));
#endif	/* !__DISABLE_LOG_DEBUG__ */
		    }
		}
		intf->set |= PUMP_NETINFO_HAS_NTPSRVS;
#ifndef __DISABLE_LOG_DEBUG__
		syslog (LOG_DEBUG, "intf: numNtp: %i", intf->numNtp);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		break;

	    case DHCP_OPTION_XFNTSRVS:
		intf->numXfs = 0;
		for (i = 0; i < length; i += 4) {
		    if (intf->numXfs < MAX_XFS_SERVERS) {
			memcpy(&intf->xfntServers[intf->numXfs++], chptr + i, 4);
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "intf: xfntServers[%i]: %s", 
			       i/4, inet_ntoa (intf->xfntServers[i/4]));
#endif	/* !__DISABLE_LOG_DEBUG__ */
		    }
		}
		intf->set |= PUMP_NETINFO_HAS_XFNTSRVS;
#ifndef __DISABLE_LOG_DEBUG__
		syslog (LOG_DEBUG, "intf: numXfs: %i", intf->numXfs);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		break;

	    case DHCP_OPTION_XDMSRVS:
		intf->numXdm = 0;
		for (i = 0; i < length; i += 4) {
		    if (intf->numXdm < MAX_XDM_SERVERS) {
			memcpy(&intf->xdmServers[intf->numXdm++], chptr + i, 4);
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "intf: xdmServers[%i]: %s", 
			       i/4, inet_ntoa (intf->xdmServers[i/4]));
#endif	/* !__DISABLE_LOG_DEBUG__ */
		    }
		}
		intf->set |= PUMP_NETINFO_HAS_XDMSRVS;
#ifndef __DISABLE_LOG_DEBUG__
		syslog (LOG_DEBUG, "intf: numXdm: %i", intf->numXdm);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		break;

	    case DHCP_OPTION_OVERLOAD:
		/* FIXME: we should pay attention to this */
		break;
	}

	chptr += length;
    }

    setMissingIpInfo(intf);
#ifdef __SNSC_PATCH__
    return 0;
#endif /* __SNSC_PATCH__ */
}

static void initVendorCodes(struct bootpRequest * breq) {
    memcpy(breq->vendor, vendCookie, sizeof(vendCookie));
}

static char * prepareRequest(struct bootpRequest * breq,
			     int sock, char * device, time_t startTime) {
    struct ifreq req;
    int i;

    memset(breq, 0, sizeof(*breq));
    memset(&req, 0, sizeof(req));

    breq->opcode = BOOTP_OPCODE_REQUEST;

    strcpy(req.ifr_name, device);
    if (ioctl(sock, SIOCGIFHWADDR, &req))
	return perrorstr("SIOCSIFHWADDR");

    breq->hw = req.ifr_hwaddr.sa_family;
    breq->hwlength = IFHWADDRLEN;	
    memcpy(breq->hwaddr, req.ifr_hwaddr.sa_data, IFHWADDRLEN);

    /* we should use something random here, but I don't want to start using
       stuff from the math library */
    breq->xid = pumpUptime();
    for (i = 0; i < IFHWADDRLEN; i++)
	breq->xid ^= breq->hwaddr[i] << (8 * (i % 4));

    breq->hopcount = 0;
    breq->secs = 0;

    initVendorCodes(breq);

    return NULL;
}

static void updateSecCount(struct bootpRequest * breq, time_t startTime) {
    breq->secs = pumpUptime() - startTime;
}

static unsigned int verifyChecksum(void * buf, int length, void * buf2,
				   int length2) {
    unsigned int csum;
    unsigned short * sp;

    csum = 0;
    for (sp = (unsigned short *) buf; length > 0; (length -= 2), sp++)
	csum += *sp;

    /* this matches rfc 1071, but not Steven's */
    if (length)
	csum += *((unsigned char *) sp);

    for (sp = (unsigned short *) buf2; length2 > 0; (length2 -= 2), sp++)
	csum += *sp;

    /* this matches rfc 1071, but not Steven's */
    if (length)
	csum += *((unsigned char *) sp);

    while (csum >> 16)
	csum = (csum & 0xffff) + (csum >> 16);

    if (csum!=0x0000 && csum != 0xffff) return 0; else return 1;
}

void debugbootpRequest(char *name, struct bootpRequest *breq)  {
    char vendor[28], vendor2[28];
    int i;
    struct in_addr address;
    unsigned char *vndptr;
    unsigned char option, length;
    
    memset(&address,0,sizeof(address));
	
#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "%s: opcode: %i", name, breq->opcode);
    syslog (LOG_DEBUG, "%s: hw: %i", name, breq->hw);
    syslog (LOG_DEBUG, "%s: hwlength: %i", name, breq->hwlength);
    syslog (LOG_DEBUG, "%s: hopcount: %i", name, breq->hopcount);
    syslog (LOG_DEBUG, "%s: xid: 0x%08x", name, breq->xid);
    syslog (LOG_DEBUG, "%s: secs: %i", name, breq->secs);
    syslog (LOG_DEBUG, "%s: flags: 0x%04x", name, breq->flags);
#endif	/* !__DISABLE_LOG_DEBUG__ */
    
    address.s_addr = breq->ciaddr;
#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "%s: ciaddr: %s", name, inet_ntoa (address));
#endif	/* !__DISABLE_LOG_DEBUG__ */
    
    address.s_addr = breq->yiaddr;
#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "%s: yiaddr: %s", name, inet_ntoa (address));
#endif	/* !__DISABLE_LOG_DEBUG__ */
    
    address.s_addr = breq->server_ip;
#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "%s: server_ip: %s", name, inet_ntoa (address));
#endif	/* !__DISABLE_LOG_DEBUG__ */
    
    address.s_addr = breq->bootp_gw_ip;
#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "%s: bootp_gw_ip: %s", name, inet_ntoa (address));
#endif	/* !__DISABLE_LOG_DEBUG__ */
    
#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "%s: hwaddr: %s", name, breq->hwaddr);
    syslog (LOG_DEBUG, "%s: servername: %s", name, breq->servername);
    syslog (LOG_DEBUG, "%s: bootfile: %s", name, breq->bootfile);
#endif	/* !__DISABLE_LOG_DEBUG__ */
    
    vndptr = (unsigned char*)breq->vendor;
#ifdef __SNSC_PATCH__
    sprintf (vendor, "0x%02x 0x%02x 0x%02x 0x%02x", vndptr[0], vndptr[1], vndptr[2], vndptr[3]);
    vndptr += 4;
#else /* __SNSC_PATCH__ */
    sprintf (vendor, "0x%02x 0x%02x 0x%02x 0x%02x", *vndptr++, *vndptr++, *vndptr++, *vndptr++);
#endif /* __SNSC_PATCH__ */
#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "%s: vendor: %s", name, vendor);
#endif	/* !__DISABLE_LOG_DEBUG__ */
    
    
#ifdef __SNSC_PATCH__
    for (; (char *) vndptr < breq->vendor + DHCP_VENDOR_LENGTH;)
#else /* __SNSC_PATCH__ */
    for (; (void *) vndptr < (void *) breq->vendor + DHCP_VENDOR_LENGTH;)
#endif /* __SNSC_PATCH__ */
      {
	option = *vndptr++;
	if (option == 0xFF)
	  {
	    sprintf (vendor, "0x%02x", option);
	    vndptr = (unsigned char*)(breq->vendor + DHCP_VENDOR_LENGTH);
	  }
	else if (option == 0x00)
	  {
	    for (i = 1; *vndptr == 0x00; i++, vndptr++);
	    sprintf (vendor, "0x%02x x %i", option, i);
	  }
	else
	  {
	    length = *vndptr++;
	    sprintf (vendor, "%3u %3u", option, length);
	    for (i = 0; i < length; i++)
	      {
		if (strlen (vendor) > 22)
		  {
#ifndef __DISABLE_LOG_DEBUG__
		    syslog (LOG_DEBUG, "%s: vendor: %s", name, vendor);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		    strcpy (vendor, "++++++");
		  }
		snprintf (vendor2, 27, "%s 0x%02x", vendor, *vndptr++);
		strcpy (vendor, vendor2);
		
	      }
	  }
	
#ifndef __DISABLE_LOG_DEBUG__
	syslog (LOG_DEBUG, "%s: vendor: %s", name, vendor);
#endif	/* !__DISABLE_LOG_DEBUG__ */
      }

    return;

}

static char * handleTransaction(int s, struct pumpOverrideInfo * override, 
				struct bootpRequest * breq,
			        struct bootpRequest * bresp, 
			        struct sockaddr_in * serverAddr,
				struct sockaddr_in * respondant,
				int useBootpPacket, 
				time_t startTime, int dhcpResponseType) {
    struct timeval tv;
    fd_set readfs;
    int i, j;
    struct sockaddr_pkt tmpAddress;
    int gotit = 0;
    int tries;
#ifdef __TUNEUP__
    long int nextTimeout = 2;
#else
    int nextTimeout = 2;
#endif /* __TUNEUP__ */
#ifdef __SNSC_PATCH__
    time_t timeoutTime = 0;
#else /* __SNSC_PATCH__ */
    time_t timeoutTime;
#endif /* __SNSC_PATCH__ */
    int sin;
    int resend = 1;
#ifdef __SNSC_PATCH__
    unsigned int ethPacketBuf[ETH_FRAME_LEN/sizeof(unsigned int)+1];
    char *ethPacket = (char *)&ethPacketBuf[0];
#else
    char ethPacket[ETH_FRAME_LEN];
#endif
    struct iphdr * ipHdr = NULL;
    struct udphdr * udpHdr = NULL;
    struct psuedohUdpHeader pHdr;
#ifdef __TUNEUP__
    time_t (*pumpUptime)(void) = pumpUptimeTuned;
    time_t delayed_start, now, end_time;
    int tscale;
#else
    time_t start = pumpUptime();
#endif /* __TUNEUP__ */

    memset(&pHdr,0,sizeof(pHdr));
    debugbootpRequest("breq", breq);

    if (!override) {
	override = alloca(sizeof(*override));
#ifdef __SNSC_PATCH__
        if (!override) { return strerror(errno); }
#endif /* __SNSC_PATCH__ */
	pumpInitOverride(override);
    }

    tries = override->numRetries + 1;
#ifdef __TUNEUP__
    delayed_start = override->delayed_start;
    tscale = override->tscale;
    end_time = override->timeout + pumpUptime();
#endif /* __TUNEUP__ */

    sin = socket(AF_PACKET, SOCK_DGRAM, ntohs(ETH_P_IP));
    if (sin < 0) {
	return strerror(errno);
    }

    while (!gotit && tries) {
	i = sizeof(*breq);
	if (useBootpPacket)
	    i -= (DHCP_VENDOR_LENGTH - BOOTP_VENDOR_LENGTH);

	if (resend) {
	    if (startTime != -1)
		updateSecCount(breq, startTime);

#ifndef __TUNEUP__
	    if (sendto(s, breq, i, 0, (struct sockaddr *) serverAddr, 
                       sizeof(*serverAddr)) != i) {
		close(sin);
		return perrorstr("sendto");
	    }

	    tries--;

	    nextTimeout *= 2;

	    switch (pumpUptime() & 4) {
		case 0:	if (nextTimeout >= 2) nextTimeout--; break;
		case 1:	nextTimeout++; break;
            }

	    timeoutTime = pumpUptime() + nextTimeout;

	    i = override->timeout + start;
	    if (timeoutTime > i) timeoutTime = i;

#else /*  __TUNEUP__ */
	    tries--;

            now = pumpUptime();
            if (delayed_start && tries == override->numRetries){
                timeoutTime = now + delayed_start;
            }
            else{
                    nextTimeout *= 2;

                    switch (now & 4) {
                    case 0:	if (nextTimeout >= 2) nextTimeout--; break;
                    case 1:	nextTimeout++; break;
                    }

                    timeoutTime = now + nextTimeout / tscale;
                    if (timeoutTime > end_time) timeoutTime = end_time;
            }

	    if (sendto(s, breq, i, 0, (struct sockaddr *) serverAddr, 
                       sizeof(*serverAddr)) != i) {
		close(sin);
		return perrorstr("sendto");
	    }
#endif /* __TUNEUP__ */

	    resend = 0;
	}

	if (dhcpResponseType == NORESPONSE) {
	    close(sin);
	    return NULL;
	}

#ifdef __TUNEUP__
        tv.tv_usec = (nextTimeout % tscale) * (1000000/tscale);
 	tv.tv_sec = timeoutTime - (now = pumpUptime());
	if(end_time <= now){
	    DPRINT("(1-1)Whole DHCP-Process expiration\n");
	    tries = 0;
	    continue;
	}else if(tv.tv_sec < 0 ){
	    DPRINT("(1-2)Each DHCP-packet-receiving timeout\n");
	    resend = 1;
	    continue;
	}
#else/* __TUNEUP__ */
	tv.tv_usec = 0;
 	tv.tv_sec = timeoutTime - pumpUptime();
	if (timeoutTime < pumpUptime()) {
	    tries = 0;
	    continue;
	}
#endif /* __TUNEUP__ */

	FD_ZERO(&readfs);
	FD_SET(sin, &readfs);
	DPRINT("select\n");
	switch ((select(sin + 1, &readfs, NULL, NULL, &tv))) {
	  case 0:
	    resend = 1;
	    break;

	  case 1:
	    i = sizeof(tmpAddress);
#ifdef TEST_TIMEOUT
	    usleep(5000);
#endif /* TEST_TIMEOUT */
#ifdef __SNSC_PATCH__
	    if ((j = recvfrom(sin, ethPacket, ETH_FRAME_LEN, 0, 
#else
	    if ((j = recvfrom(sin, ethPacket, sizeof(ethPacket), 0, 
#endif
                     (struct sockaddr *) &tmpAddress, (socklen_t*)&i)) < 0)
#ifdef __SNSC_PATCH__
            {
                    close(sin);
                    return perrorstr("recvfrom");
            }
#else
		return perrorstr("recvfrom");
#endif
	    /* We need to do some basic sanity checking of the header */
	    if (j < (sizeof(*ipHdr) + sizeof(*udpHdr))) continue;

	    ipHdr = (void *) ethPacket;

#ifdef __TUNEUP__
	    if (ipHdr->protocol != IPPROTO_UDP) continue;
#endif /* __TUNEUP__ */
	    if (!verifyChecksum(NULL, 0, ipHdr, sizeof(*ipHdr)))
		continue;

	    /* XXX the broadcast must always be from 0.0.0.0, so we'll
	       set that now. */
	    ipHdr->saddr = 0;
	    
	    if (ntohs(ipHdr->tot_len) > j)
		continue;
	    j = ntohs(ipHdr->tot_len);

#ifndef __TUNEUP__
            if (ipHdr->protocol != IPPROTO_UDP) continue;
#endif /* __TUNEUP__ */
	    udpHdr = (void *) (ethPacket + sizeof(*ipHdr));
	    pHdr.source = ipHdr->saddr;
	    pHdr.dest = ipHdr->daddr;
	    pHdr.zero = 0;
	    pHdr.protocol = ipHdr->protocol;
	    pHdr.len = udpHdr->len;

/*
	    egcs bugs make this problematic

	    if (udpHdr->check && !verifyChecksum(&pHdr, sizeof(pHdr), 
 				udpHdr, j - sizeof(*ipHdr)))
	    continue;
*/

	    if (ntohs(udpHdr->source) != BOOTP_SERVER_PORT)
		continue;
	    if (ntohs(udpHdr->dest) != BOOTP_CLIENT_PORT) 
		continue;
	    /* Go on with this packet; it looks sane */

	  /* Originally copied sizeof (*bresp) - this is a security
	     problem due to a potential underflow of the source
	     buffer.  Also, it trusted that the packet was properly
	     0xFF terminated, which is not true in the case of the
	     DHCP server on Cisco 800 series ISDN router. */

	  memset (bresp, 0xFF, sizeof (*bresp));
#ifndef __SNSC_PATCH__
	  memcpy (bresp, (char *) udpHdr + sizeof (*udpHdr), j - sizeof (*ipHdr) - sizeof (*udpHdr));
#else /* __SNSC_PATCH__ */
            j -= sizeof (*ipHdr) + sizeof (*udpHdr);
            if (j <= 0) {
                    continue;
            }
            /* 
                If bootp response is larger than bootRequest structure, 
                shrink copy size to the structure size minus 1.
                'Minus 1' means, the last one byte should have a value 0xFF
                described above.
            */
            if (j > sizeof(*bresp) - 1){
#ifndef __DISABLE_LOG_INFO__
                    syslog(LOG_INFO, "Received buffer overrun packet against bootp !!");
#endif  /* !__DISABLE_LOG_INFO__ */
                    j = sizeof(*bresp) - 1;
            }
            memcpy (bresp, (char *) udpHdr + sizeof (*udpHdr), j);
#endif /* __SNSC_PATCH__ */
	    /* sanity checks */
	    if (bresp->xid != breq->xid) {
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: xid: 0x%08x <--> 0x%08x",
			breq->xid, bresp->xid);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
	    }
	    if (bresp->opcode != BOOTP_OPCODE_REPLY) {
#ifndef __SNSC_PATCH__
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: opcode: %i <--> %i",
			BOOTP_OPCODE_REPLY, bresp->opcode);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
#else /* __SNSC_PATCH__ */
                /*
                 * When pump request DHCP_TYPE_ACK to PCI BRL-04AR
                 * PCI BRL-04AR replays opecode:0 instead of 0x02
                 */
#ifndef __DISABLE_LOG_INFO__
		syslog(LOG_INFO, "Invalid opcode from server: %i <--> %i:ignored",
			BOOTP_OPCODE_REPLY, bresp->opcode);
#endif  /* !__DISABLE_LOG_INFO__ */
#endif /* __SNSC_PATCH__ */
	    }
	    if (bresp->hwlength != breq->hwlength) {
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: hwlength: %i <--> %i",
			breq->hwlength, bresp->hwlength);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
	    }
	    if (memcmp(bresp->hwaddr, breq->hwaddr, bresp->hwlength)) {
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: hwaddr: %s <--> %s",
			breq->hwaddr, bresp->hwaddr);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
	    }
	    i = dhcpMessageType(bresp);
	    if (!(i == -1 && useBootpPacket) && (i != dhcpResponseType)) {
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: msgtyp: %i", i);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
	    }
	    if (memcmp(bresp->vendor, vendCookie, 4)) {
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: vendor: 0x%02x 0x%02x 0x%02x 0x%02x"
				  " <--> 0x%02x 0x%02x 0x%02x 0x%02x",
		       vendCookie[0], vendCookie[1], vendCookie[2], 
		       vendCookie[3], bresp->vendor[0], bresp->vendor[1],
		       bresp->vendor[2], bresp->vendor[3]);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
	    }
	    /* if (respondant) *respondant = tmpAddress; */
	    gotit = 1;

	    break;

	  default:
	    close(sin);
	    return perrorstr("select");
	}
    }

    if (!gotit) {
	close(sin);
	return _("No DHCP reply received");
    }

    close(sin);

    debugbootpRequest("bresp", bresp);

    return NULL;
}

static char * handleTransaction_raw(int s, struct pumpOverrideInfo * override, 
                                    char *buf, 
                                    int len,
                                    struct bootpRequest * bresp, 
                                    struct sockaddr_ll * serverAddr,
                                    struct sockaddr_in * respondant,
                                    int useBootpPacket, 
                                    time_t startTime, int dhcpResponseType) {
    struct timeval tv;
    fd_set readfs;
    int i, j;
    struct sockaddr_pkt tmpAddress;
    int gotit = 0;
    int tries;
    long int nextTimeout = 2;
#ifdef __SNSC_PATCH__
    time_t timeoutTime = 0;
#else /* __SNSC_PATCH__ */
    time_t timeoutTime;
#endif /* __SNSC_PATCH__ */
    int sin;
    int resend = 1;
#ifdef __SNSC_PATCH__
    unsigned int ethPacketBuf[ETH_FRAME_LEN/sizeof(unsigned int)+1];
    char *ethPacket = (char *)&ethPacketBuf[0];
#else
    char ethPacket[ETH_FRAME_LEN];
#endif
    struct iphdr * ipHdr = NULL;
    struct udphdr * udpHdr = NULL;
    struct psuedohUdpHeader pHdr;
#ifdef __TUNEUP__
    time_t (*pumpUptime)(void) = pumpUptimeTuned;
    time_t delayed_start, now, end_time;
    int tscale;
#else /* __TUNEUP__ */
    time_t start = pumpUptime();
#endif /* __TUNEUP__ */

    struct bootpRequest * breq = (struct bootpRequest*)
            (buf+14+sizeof(struct iphdr)+sizeof(struct udphdr));

    memset(&pHdr,0,sizeof(pHdr));
    debugbootpRequest("breq_raw", breq);

    if (!override) {
	override = alloca(sizeof(*override));
        if (!override) { return strerror(errno); }
	pumpInitOverride(override);
    }

    tries = override->numRetries + 1;
#ifdef __TUNEUP__
    delayed_start = override->delayed_start;
    tscale = override->tscale;
    end_time = override->timeout + pumpUptime();
#endif /* __TUNEUP__ */

    sin = socket(AF_PACKET, SOCK_DGRAM, ntohs(ETH_P_IP));
    if (sin < 0) {
	return strerror(errno);
    }

    while (!gotit && tries) {
            i = len;

	if (useBootpPacket)
            i -= (DHCP_VENDOR_LENGTH - BOOTP_VENDOR_LENGTH);

	if (resend) {
	    if (startTime != -1)
            {
                    updateSecCount(breq, startTime);
                    /* instead of make_ip_header() */
                    recalculateUdphdr(buf, i);
            }

#ifndef __TUNEUP__
	    if (sendto(s, buf, i, 0, (struct sockaddr *) serverAddr, 
                       sizeof(struct sockaddr_ll)) != i) {
		close(sin);
		return perrorstr("sendto");
	    }

	    tries--;

	    nextTimeout *= 2;

	    switch (pumpUptime() & 4) {
		case 0:	if (nextTimeout >= 2) nextTimeout--; break;
		case 1:	nextTimeout++; break;
            }

	    timeoutTime = pumpUptime() + nextTimeout;

	    i = override->timeout + start;
	    if (timeoutTime > i) timeoutTime = i;

#else /*  __TUNEUP__ */
	    tries--;

            now = pumpUptime();
            if (delayed_start && tries == override->numRetries){
                timeoutTime = now + delayed_start;
            }
            else{
                    nextTimeout *= 2;

                    switch (now & 4) {
                    case 0:	if (nextTimeout >= 2) nextTimeout--; break;
                    case 1:	nextTimeout++; break;
                    }

                    timeoutTime = now + nextTimeout / tscale;
                    if (timeoutTime > end_time) timeoutTime = end_time;
            }
	    if (sendto(s, buf, i, 0, (struct sockaddr *) serverAddr, 
                       sizeof(struct sockaddr_ll)) != i) {
		close(sin);
		return perrorstr("sendto");
	    }
#endif /* __TUNEUP__ */

	    resend = 0;
	}

	if (dhcpResponseType == NORESPONSE) {
	    close(sin);
	    return NULL;
	}

#ifdef __TUNEUP__
        tv.tv_usec = (nextTimeout % tscale) * (1000000/tscale);
 	tv.tv_sec = timeoutTime - (now = pumpUptime());
	if(end_time <= now){
	    DPRINT("(2-1)Whole DHCP-Process expiration\n");
	    tries = 0;
	    continue;
	}else if(tv.tv_sec < 0 ){
	    DPRINT("(2-2)Each DHCP-packet-receiving timeout\n");
	    resend = 1;
	    continue;
	}
#else/* __TUNEUP__ */
	tv.tv_usec = 0;
 	tv.tv_sec = timeoutTime - pumpUptime();
	if (timeoutTime < pumpUptime()) {
	    tries = 0;
	    continue;
	}
#endif /* __TUNEUP__ */

	FD_ZERO(&readfs);
	FD_SET(sin, &readfs);
	DPRINT("select\n");
	switch ((select(sin + 1, &readfs, NULL, NULL, &tv))) {
	  case 0:
	    resend = 1;
	    break;

	  case 1:
	    i = sizeof(tmpAddress);
#ifdef TEST_TIMEOUT
	    usleep(5000);
#endif /* TEST_TIMEOUT */
#ifdef __SNSC_PATCH__
	    if ((j = recvfrom(sin, ethPacket, ETH_FRAME_LEN, 0, 
#else
	    if ((j = recvfrom(sin, ethPacket, sizeof(ethPacket), 0, 
#endif
                              (struct sockaddr *)&tmpAddress, (socklen_t*)&i)) < 0){
                close(sin);
		return perrorstr("recvfrom");
            }

	    /* We need to do some basic sanity checking of the header */
	    if (j < (sizeof(*ipHdr) + sizeof(*udpHdr))) continue;

	    ipHdr = (void *) ethPacket;

	    if (ipHdr->protocol != IPPROTO_UDP) continue;

	    if (!verifyChecksum(NULL, 0, ipHdr, sizeof(*ipHdr)))
		continue;

	    /* XXX the broadcast must always be from 0.0.0.0, so we'll
	       set that now. */
	    ipHdr->saddr = 0;
	    
	    if (ntohs(ipHdr->tot_len) > j)
		continue;
	    j = ntohs(ipHdr->tot_len);

	    udpHdr = (void *) (ethPacket + sizeof(*ipHdr));
	    pHdr.source = ipHdr->saddr;
	    pHdr.dest = ipHdr->daddr;
	    pHdr.zero = 0;
	    pHdr.protocol = ipHdr->protocol;
	    pHdr.len = udpHdr->len;

/*
	    egcs bugs make this problematic

	    if (udpHdr->check && !verifyChecksum(&pHdr, sizeof(pHdr), 
 				udpHdr, j - sizeof(*ipHdr)))
	    continue;
*/


	    if (ntohs(udpHdr->source) != BOOTP_SERVER_PORT)
		continue;

	    if (ntohs(udpHdr->dest) != BOOTP_CLIENT_PORT) 
		continue;

	    /* Go on with this packet; it looks sane */

	  /* Originally copied sizeof (*bresp) - this is a security
	     problem due to a potential underflow of the source
	     buffer.  Also, it trusted that the packet was properly
	     0xFF terminated, which is not true in the case of the
	     DHCP server on Cisco 800 series ISDN router. */

	  memset (bresp, 0xFF, sizeof (*bresp));
            j -= sizeof (*ipHdr) + sizeof (*udpHdr);
            if (j <= 0) {
                    continue;
            }
            /* 
                If bootp response is larger than bootRequest structure, 
                shrink copy size to the structure size minus 1.
                'Minus 1' means, the last one byte should have a value 0xFF
                described above.
            */
            if (j > sizeof(*bresp) - 1){
#ifndef __DISABLE_LOG_INFO__
                    syslog(LOG_INFO, "Received buffer overrun packet against bootp !!");
#endif  /* !__DISABLE_LOG_INFO__ */
                    j = sizeof(*bresp) - 1;
            }
            memcpy (bresp, (char *) udpHdr + sizeof (*udpHdr), j);

	    /* sanity checks */
	    if (bresp->xid != breq->xid) {
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: xid: 0x%08x <--> 0x%08x",
			breq->xid, bresp->xid);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
	    }
	    if (bresp->opcode != BOOTP_OPCODE_REPLY) {
                /*
                 * When pump request DHCP_TYPE_ACK to PCI BRL-04AR
                 * PCI BRL-04AR replays opecode:0 instead of 0x02
                 */
#ifndef __DISABLE_LOG_INFO__
		syslog(LOG_INFO, "Invalid opcode from server: %i <--> %i:ignored",
			BOOTP_OPCODE_REPLY, bresp->opcode);
#endif  /* !__DISABLE_LOG_INFO__ */
	    }
	    if (bresp->hwlength != breq->hwlength) {
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: hwlength: %i <--> %i",
			breq->hwlength, bresp->hwlength);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
	    }
	    if (memcmp(bresp->hwaddr, breq->hwaddr, bresp->hwlength)) {
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: hwaddr: %s <--> %s",
			breq->hwaddr, bresp->hwaddr);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
	    }
	    i = dhcpMessageType(bresp);
	    if (!(i == -1) && (i != dhcpResponseType)) {
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: msgtyp: %i", i);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
	    }
	    if (memcmp(bresp->vendor, vendCookie, 4)) {
#ifndef __DISABLE_LOG_DEBUG__
		syslog(LOG_DEBUG, "reject: vendor: 0x%02x 0x%02x 0x%02x 0x%02x"
				  " <--> 0x%02x 0x%02x 0x%02x 0x%02x",
		       vendCookie[0], vendCookie[1], vendCookie[2], 
		       vendCookie[3], bresp->vendor[0], bresp->vendor[1],
		       bresp->vendor[2], bresp->vendor[3]);
#endif	/* !__DISABLE_LOG_DEBUG__ */
		continue;
	    }
	    /* if (respondant) *respondant = tmpAddress; */
	    gotit = 1;

	    break;

	  default:
	    close(sin);
	    return perrorstr("select");
	}
    }

    if (!gotit) {
	close(sin);
	return _("No DHCP reply received");
    }

    close(sin);

    debugbootpRequest("bresp", bresp);

    return NULL;
}
#ifdef __AUTOIP__
static char*
handleTransaction_raw_autoip_with_check_arp_internal(int s, struct 
				    pumpOverrideInfo * override, 
                                    char *buf, 
                                    int len,
                                    struct bootpRequest * bresp, 
                                    struct sockaddr_ll * serverAddr,
                                    struct sockaddr_in * respondant,
                                    int useBootpPacket, 
                                    time_t startTime, int dhcpResponseType,
                                    int* conflictFlag,
				    int autoipsock,
                                    char *device,
                                    struct pumpNetIntf *intf)
{
    struct timeval tv;
    fd_set readfs;
    int i, j;
    struct sockaddr_pkt tmpAddress;
    int gotit = 0;
    int tries;
    long int nextTimeout = 2;
#ifdef __SNSC_PATCH__
    time_t timeoutTime = 0;
#else /* __SNSC_PATCH__ */
    time_t timeoutTime;
#endif /* __SNSC_PATCH__ */
    int sin;
    int resend = 1;
#ifdef __SNSC_PATCH__
    unsigned int ethPacketBuf[ETH_FRAME_LEN/sizeof(unsigned int)+1];
    char *ethPacket = (char *)&ethPacketBuf[0];
#else
    char ethPacket[ETH_FRAME_LEN];
#endif
    struct iphdr * ipHdr = NULL;
    struct udphdr * udpHdr = NULL;
    struct psuedohUdpHeader pHdr;
#ifdef __TUNEUP__
    time_t (*pumpUptime)(void) = pumpUptimeTuned;
    time_t delayed_start, now, end_time;
    int tscale;
#else /* __TUNEUP__ */
    time_t start = pumpUptime();
#endif /* __TUNEUP__ */

    struct bootpRequest * breq = (struct bootpRequest*)
            (buf+14+sizeof(struct iphdr)+sizeof(struct udphdr));

    memset(&pHdr,0,sizeof(pHdr));
    debugbootpRequest("breq_raw", breq);

    if (!override) {
	override = alloca(sizeof(*override));
        if (!override) { return strerror(errno); }
	pumpInitOverride(override);
    }

    tries = override->numRetries + 1;
#ifdef __TUNEUP__
    delayed_start = override->delayed_start;
    tscale = override->tscale;
    end_time = override->timeout + pumpUptime();
#endif /* __TUNEUP__ */

    sin = socket(AF_PACKET, SOCK_DGRAM, ntohs(ETH_P_IP));
    if (sin < 0) {
	return strerror(errno);
    }

    while (!gotit && tries) {
            i = len;

	if (useBootpPacket)
            i -= (DHCP_VENDOR_LENGTH - BOOTP_VENDOR_LENGTH);

	if (resend) {
	    if (startTime != -1)
            {
                    updateSecCount(breq, startTime);
                    /* instead of make_ip_header() */
                    recalculateUdphdr(buf, i);
            }

#ifndef __TUNEUP__
	    if (sendto(s, buf, i, 0, (struct sockaddr *) serverAddr, 
                       sizeof(struct sockaddr_ll)) != i) {
		close(sin);
		return perrorstr("sendto");
	    }

	    tries--;

	    nextTimeout *= 2;

	    switch (pumpUptime() & 4) {
		case 0:	if (nextTimeout >= 2) nextTimeout--; break;
		case 1:	nextTimeout++; break;
            }

	    timeoutTime = pumpUptime() + nextTimeout;

	    i = override->timeout + start;
	    if (timeoutTime > i) timeoutTime = i;

#else /*  __TUNEUP__ */
	    tries--;

            now = pumpUptime();
            if (delayed_start && tries == override->numRetries){
                timeoutTime = now + delayed_start;
            }
            else{
                    nextTimeout *= 2;

                    switch (now & 4) {
                    case 0:	if (nextTimeout >= 2) nextTimeout--; break;
                    case 1:	nextTimeout++; break;
                    }

                    timeoutTime = now + nextTimeout / tscale;
                    if (timeoutTime > end_time) timeoutTime = end_time;
            }
	    if (sendto(s, buf, i, 0, (struct sockaddr *) serverAddr, 
                       sizeof(struct sockaddr_ll)) != i) {
		close(sin);
		return perrorstr("sendto");
	    }
#endif /* __TUNEUP__ */

	    resend = 0;
	}

	if (dhcpResponseType == NORESPONSE) {
	    close(sin);
	    *conflictFlag = 0;
	    return NULL;
	}

#ifdef __TUNEUP__
        tv.tv_usec = (nextTimeout % tscale) * (1000000/tscale);
 	tv.tv_sec = timeoutTime - (now = pumpUptime());
	if(end_time <= now){
	    DPRINT("(3-1)Whole DHCP-Process expiration\n");
	    tries = 0;
	    continue;
	}else if(tv.tv_sec < 0 ){
	    DPRINT("(3-2)Each DHCP-packet-receiving timeout\n");
	    resend = 1;
	    continue;
	}
#else/* __TUNEUP__ */
	tv.tv_usec = 0;
 	tv.tv_sec = timeoutTime - pumpUptime();
	if (timeoutTime < pumpUptime()) {
	    tries = 0;
	    continue;
	}
#endif /* __TUNEUP__ */
	FD_ZERO(&readfs);
	FD_SET(sin, &readfs);
        FD_SET(autoipsock, &readfs);

	DPRINT("select\n");
	switch ((select(autoipsock > sin ? (autoipsock+1) : (sin+1), 
			&readfs, NULL, NULL, &tv))) {
	  case 0:
	    resend = 1;
	    break;

	  case 1:
	  case 2:
	    if(FD_ISSET(sin, &readfs)){
		    DPRINT("*NOTICE:Listening socket\n");

		    i = sizeof(tmpAddress);
#ifdef TEST_TIMEOUT
		    usleep(5000);
#endif /* TEST_TIMEOUT */
#ifdef __SNSC_PATCH__
		    if ((j = recvfrom(sin, ethPacket, ETH_FRAME_LEN, 0, 
#else
		    if ((j = recvfrom(sin, ethPacket, sizeof(ethPacket), 0, 
#endif
	                              (struct sockaddr *)&tmpAddress, (socklen_t*)&i)) < 0){
	                close(sin);
			return perrorstr("recvfrom");
	            }

		    /* We need to do some basic sanity checking of the header */
		    if (j < (sizeof(*ipHdr) + sizeof(*udpHdr))) goto NEXT;

		    ipHdr = (void *) ethPacket;

		    if (ipHdr->protocol != IPPROTO_UDP) goto NEXT;

		    if (!verifyChecksum(NULL, 0, ipHdr, sizeof(*ipHdr)))
			goto NEXT;

		    /* XXX the broadcast must always be from 0.0.0.0, so we'll
		       set that now. */
		    ipHdr->saddr = 0;
		    
		    if (ntohs(ipHdr->tot_len) > j)
			goto NEXT;
		    j = ntohs(ipHdr->tot_len);

		    udpHdr = (void *) (ethPacket + sizeof(*ipHdr));
		    pHdr.source = ipHdr->saddr;
		    pHdr.dest = ipHdr->daddr;
		    pHdr.zero = 0;
		    pHdr.protocol = ipHdr->protocol;
		    pHdr.len = udpHdr->len;

	/*
		    egcs bugs make this problematic

		    if (udpHdr->check && !verifyChecksum(&pHdr, sizeof(pHdr), 
	 				udpHdr, j - sizeof(*ipHdr)))
		    continue;
	*/


		    if (ntohs(udpHdr->source) != BOOTP_SERVER_PORT)
			goto NEXT;

		    if (ntohs(udpHdr->dest) != BOOTP_CLIENT_PORT) 
			goto NEXT;

		    /* Go on with this packet; it looks sane */

		  /* Originally copied sizeof (*bresp) - this is a security
		     problem due to a potential underflow of the source
		     buffer.  Also, it trusted that the packet was properly
		     0xFF terminated, which is not true in the case of the
		     DHCP server on Cisco 800 series ISDN router. */

		  memset (bresp, 0xFF, sizeof (*bresp));
	            j -= sizeof (*ipHdr) + sizeof (*udpHdr);
	            if (j <= 0) {
	                    goto NEXT;
	            }
	            /* 
	                If bootp response is larger than bootRequest structure, 
	                shrink copy size to the structure size minus 1.
	                'Minus 1' means, the last one byte should have a value 0xFF
	                described above.
	            */
	            if (j > sizeof(*bresp) - 1){
#ifndef __DISABLE_LOG_INFO__
	                    syslog(LOG_INFO, "Received buffer overrun packet against bootp !!");
#endif  /* !__DISABLE_LOG_INFO__ */
	                    j = sizeof(*bresp) - 1;
	            }
	            memcpy (bresp, (char *) udpHdr + sizeof (*udpHdr), j);

		    /* sanity checks */
		    if (bresp->xid != breq->xid) {
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "reject: xid: 0x%08x <--> 0x%08x",
				breq->xid, bresp->xid);
#endif	/* !__DISABLE_LOG_DEBUG__ */
			goto NEXT;
		    }
		    if (bresp->opcode != BOOTP_OPCODE_REPLY) {
	                /*
	                 * When pump request DHCP_TYPE_ACK to PCI BRL-04AR
	                 * PCI BRL-04AR replays opecode:0 instead of 0x02
	                 */
#ifndef __DISABLE_LOG_INFO__
			syslog(LOG_INFO, "Invalid opcode from server: %i <--> %i:ignored",
				BOOTP_OPCODE_REPLY, bresp->opcode);
#endif  /* !__DISABLE_LOG_INFO__ */
		    }
		    if (bresp->hwlength != breq->hwlength) {
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "reject: hwlength: %i <--> %i",
				breq->hwlength, bresp->hwlength);
#endif	/* !__DISABLE_LOG_DEBUG__ */
			goto NEXT;
		    }
		    if (memcmp(bresp->hwaddr, breq->hwaddr, bresp->hwlength)) {
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "reject: hwaddr: %s <--> %s",
				breq->hwaddr, bresp->hwaddr);
#endif	/* !__DISABLE_LOG_DEBUG__ */
			goto NEXT;
		    }
		    i = dhcpMessageType(bresp);
		    if (!(i == -1) && (i != dhcpResponseType)) {
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "reject: msgtyp: %i", i);
#endif	/* !__DISABLE_LOG_DEBUG__ */
			goto NEXT;
		    }
		    if (memcmp(bresp->vendor, vendCookie, 4)) {
#ifndef __DISABLE_LOG_DEBUG__
			syslog(LOG_DEBUG, "reject: vendor: 0x%02x 0x%02x 0x%02x 0x%02x"
					  " <--> 0x%02x 0x%02x 0x%02x 0x%02x",
			       vendCookie[0], vendCookie[1], vendCookie[2], 
			       vendCookie[3], bresp->vendor[0], bresp->vendor[1],
			       bresp->vendor[2], bresp->vendor[3]);
#endif	/* !__DISABLE_LOG_DEBUG__ */
			goto NEXT;
		    }
		    /* if (respondant) *respondant = tmpAddress; */
		    gotit = 1;
	    }
NEXT:
	    if(gotit == 0 && FD_ISSET(autoipsock, &readfs)){
	       int* p = (int*)&(intf->ip);
	       if(receive_and_judge_packet(device, autoipsock, *p) == 1){
                 DPRINT("*NOTICE:Received ARP Conflict packet\n");
                 *conflictFlag = 1;
	       }
	    }
	    break;

	  default:
	    close(sin);
	    return perrorstr("select");
	}
    }

    if (!gotit) {
	close(sin);
	return _("No DHCP reply received");
    }

    close(sin);

    debugbootpRequest("bresp", bresp);

    *conflictFlag = 0;	/* Clear the conflict flag because DHCP is OK */
    return NULL;	/* DHCP SUCCESS*/
}

static char*
handleTransaction_raw_autoip_with_check_arp(int s, struct pumpOverrideInfo * override, 
                                    char *buf, 
                                    int len,
                                    struct bootpRequest * bresp, 
                                    struct sockaddr_ll * serverAddr,
                                    struct sockaddr_in * respondant,
                                    int useBootpPacket, 
                                    time_t startTime, int dhcpResponseType,
                                    char *device, struct pumpNetIntf *intf)
{
	char *retv;
	int autoipsock = -1;
	int conflictFlag = 0;
	
	if((autoipsock = createAutoipSocket(device)) == -1){
		DPRINT("FATAL ERROR\n");
		return perrorstr("createAutoipSocket");
	}

	retv =  handleTransaction_raw_autoip_with_check_arp_internal(s, override, 
                                    buf, 
                                    len,
                                    bresp, 
                                    serverAddr,
                                    respondant,
                                    useBootpPacket, 
                                    startTime, dhcpResponseType,
                                    &conflictFlag, /* added */
                                    autoipsock,    /* added */
                                    device, intf);

	clear_raw(autoipsock);
	close(autoipsock);

	if(conflictFlag == 1){
		DPRINT("Trying another new AutoIP\n");
		pumpAutoipRun(device, 0, 0, NULL, intf, override, 0);
		pumpSetupInterface(intf);
	}

	DPRINT("handleTransaction_raw_autoip_with_check_arp end:%s\n",retv);
	return retv;
}
#endif /*__AUTOIP__*/

static void addVendorCode(struct bootpRequest * breq, unsigned char option,
			  unsigned char length, void * data) {
    unsigned char * chptr;
    int theOption, theLength;
#ifdef __SNSC_PATCH__
    unsigned char *top;
#endif /* __SNSC_PATCH__ */

    chptr = (unsigned char*)breq->vendor;
    chptr += 4;
#ifdef __SNSC_PATCH__
    top = (unsigned char*)breq->vendor;
    while (chptr - top < DHCP_VENDOR_LENGTH - length -3
           && *chptr != 0xFF && *chptr != option) {
	theOption = *chptr++;
	if (!theOption) continue;
	theLength = *chptr++;
	chptr += theLength;
    }
    if (chptr - top < DHCP_VENDOR_LENGTH - length - 3) {
	    *chptr++ = option;
	    *chptr++ = length;
	    memcpy(chptr, data, length);
	    chptr[length] = 0xff;
    } else {
#ifndef __DISABLE_LOG_DEBUG__
	syslog (LOG_DEBUG, "addVendorCode: no space exist: option %i length %i",
	    option, length);
#endif	/* !__DISABLE_LOG_DEBUG__ */
    }
#else /* __SNSC_PATCH__ */
    while (*chptr != 0xFF && *chptr != option) {
	theOption = *chptr++;
	if (!theOption) continue;
	theLength = *chptr++;
	chptr += theLength;
    }

    *chptr++ = option;
    *chptr++ = length;
    memcpy(chptr, data, length);
    chptr[length] = 0xff;
#endif /* __SNSC_PATCH__ */

}

static int getVendorCode(struct bootpRequest * bresp, unsigned char option,
			  void * data, size_t maxsize) {
    unsigned char * chptr;
    unsigned int length, theOption;

    chptr = (unsigned char*)bresp->vendor;
    chptr += 4;
    while (*chptr != 0xFF && *chptr != option) {
	theOption = *chptr++;
	if (!theOption) continue;
	length = *chptr++;
	chptr += length;
#ifdef __SNSC_PATCH__
	if ( ((char *)chptr - bresp->vendor) >= DHCP_VENDOR_LENGTH) return 1;
#else /* __SNSC_PATCH__ */
	if ( ((void *)chptr - (void *)bresp->vendor) >= DHCP_VENDOR_LENGTH) return 1;
#endif /* __SNSC_PATCH__ */
    }

    if (*chptr++ == 0xff) return 1;

    length = *chptr++;
    if(length > maxsize)
        length = maxsize;
    memcpy(data, chptr, length);

    return 0;
}

static int createSocket(const char * device) {
    struct sockaddr_in clientAddr;
    int s;
    int true = 1;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0)
	return -1;

    if (setsockopt(s, SOL_SOCKET, SO_BROADCAST, &true, sizeof(true))) {
	close(s);
	return -1;
    }

    if (setsockopt(s, SOL_SOCKET, SO_BINDTODEVICE, device, strlen(device)+1)) {
#ifndef __DISABLE_LOG_ERR__
	syslog(LOG_ERR, "SO_BINDTODEVICE %s (%d) failed: %s", device, strlen(device), strerror(errno));
#endif  /* !__DISABLE_LOG_ERR__ */
    }

    memset(&clientAddr.sin_addr, 0, sizeof(&clientAddr.sin_addr));
    clientAddr.sin_family = AF_INET;
    clientAddr.sin_port = htons(BOOTP_CLIENT_PORT);	/* bootp client */

    if (bind(s, (struct sockaddr *) &clientAddr, sizeof(clientAddr))) {
	close(s); 
	return -1;
    }

    return s;
}

int pumpDhcpRelease(struct pumpNetIntf * intf) {
    struct bootpRequest breq, bresp;
    unsigned char messageType;
    struct sockaddr_in serverAddr;
    char * chptr;
    int s;
    char hostname[1024];

    if (!(intf->set & PUMP_INTFINFO_HAS_LEASE)) {
	pumpDisableInterface(intf->device);
#ifndef __DISABLE_LOG_INFO__
	syslog(LOG_INFO, "disabling interface %s", intf->device);
#endif  /* !__DISABLE_LOG_INFO__ */
	return 0;
    }

    if ((s = createSocket(intf->device)) < 0) return 1;

    if ((chptr = prepareRequest(&breq, s, intf->device, pumpUptime()))) {
	close(s);
	while (1) {
	    pumpDisableInterface(intf->device);
	    return 0;
	}
    }

    messageType = DHCP_TYPE_RELEASE;
    addVendorCode(&breq, DHCP_OPTION_TYPE, 1, &messageType);
    memcpy(&breq.ciaddr, &intf->ip, sizeof(breq.ciaddr));

    /* Dynamic DHCP implementations need the hostname here. */
    if (intf->set & PUMP_NETINFO_HAS_HOSTNAME) {
	addVendorCode(&breq, BOOTP_OPTION_HOSTNAME,
		      strlen(intf->hostname) + 1, intf->hostname);
    } else {
	gethostname(hostname, sizeof(hostname));
	if (strcmp(hostname, "localhost") && 
	    strcmp(hostname, "localhost.localdomain")) {
	    addVendorCode(&breq, BOOTP_OPTION_HOSTNAME, 
			  strlen(hostname) + 1, hostname);
	}
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(BOOTP_SERVER_PORT);	/* bootp server */
    serverAddr.sin_addr = intf->bootServer;

    handleTransaction(s, NULL, &breq, &bresp, &serverAddr, NULL, 0, 
		      -1, NORESPONSE);

    /* wait to complete transmitting DHCP_RELEASE packet */
    sleep(TRANSMISSION_TIME);

    pumpDisableInterface(intf->device);
    close(s);

    if (intf->set & PUMP_NETINFO_HAS_HOSTNAME)
	free(intf->hostname);
    if (intf->set & PUMP_NETINFO_HAS_DOMAIN)
	free(intf->domain);
#ifdef __SNSC_PATCH__
    if (intf->set & PUMP_NETINFO_HAS_NISDOMAIN)
	free(intf->nisDomain);
#endif /* __SNSC_PATCH__ */
#ifndef __DISABLE_LOG_INFO__
    syslog(LOG_INFO, "disabling interface %s", intf->device);
#endif  /* !__DISABLE_LOG_INFO__ */
    return 0;
}

#ifdef __OPT_HOSTNAME__
/*
 * option_hostname is a host name from command option
 * option_hostname is not thread safe. if you use libpump.a, 
 *     don't set __OPT_HOSTNAME__ as make option 
 */
static const char *option_hostname = NULL;
/*
 * must be called by pump runDaemon(), 
 * This function is not thread safe.
 */
void pumpGetOptionHostname(const char *hostname) {
        if (!hostname || hostname[0] == '\0') {
                option_hostname = NULL;
        }
        else {
                option_hostname = hostname;
        }
}
#endif /* __OPT_HOSTNAME__ */

static int pumpGethostname(char *name, size_t len) {
#ifdef __OPT_HOSTNAME__
        if (option_hostname) {
                strncpy(name, option_hostname, len);
                return 0;
        }
#endif /* __OPT_HOSTNAME__ */
        return gethostname(name, len);
}
    
/* This is somewhat broken. We try only to renew the lease. If we fail,
   we don't try to completely rebind. This doesn't follow the DHCP spec,
   but for the install it should be a reasonable compromise. */
int pumpDhcpRenew(struct pumpNetIntf * intf) {
    struct bootpRequest breq, bresp;
    unsigned char messageType;
    struct sockaddr_in serverAddr;
    char * chptr;
    int s;
    int i;
    char hostname[1024];
    time_t startTime = pumpUptime();

    s = createSocket(intf->device);
#ifdef __SNSC_PATCH__
    if (s < 0) {
	return 1;
    }
#endif /* __SNSC_PATCH__*/

    if ((chptr = prepareRequest(&breq, s, intf->device, pumpUptime()))) {
	close(s);
	while (1);	/* problem */
    }

    messageType = DHCP_TYPE_REQUEST;
    addVendorCode(&breq, DHCP_OPTION_TYPE, 1, &messageType);
    memcpy(&breq.ciaddr, &intf->ip, sizeof(breq.ciaddr));

    addClientIdentifier(intf->flags, &breq);

    /* Dynamic DHCP implementations need the hostname here. */
    if (intf->set & PUMP_NETINFO_HAS_HOSTNAME) {
	addVendorCode(&breq, BOOTP_OPTION_HOSTNAME,
		      strlen(intf->hostname) + 1,
		      intf->hostname);
    } else {
        pumpGethostname(hostname, sizeof(hostname));
	if (strcmp(hostname, "localhost") && 
	    strcmp(hostname, "localhost.localdomain")) {
	    addVendorCode(&breq, BOOTP_OPTION_HOSTNAME, 
			  strlen(hostname) + 1, hostname);
	}
    }

    i = htonl(intf->reqLease);
    addVendorCode(&breq, DHCP_OPTION_LEASE, 4, &i);

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(BOOTP_SERVER_PORT);	/* bootp server */
    serverAddr.sin_addr = intf->bootServer;

    if (handleTransaction(s, NULL, &breq, &bresp, &serverAddr, NULL, 0,
			   startTime, DHCP_TYPE_ACK)) {
	close(s);
	return 1;
    }

    parseLease(&bresp, intf);
#ifndef __DISABLE_LOG_INFO__
    syslog(LOG_INFO, "renewed lease for interface %s", intf->device);
#endif  /* !__DISABLE_LOG_INFO__ */
    close(s);
    return 0;
}

static void parseLease(struct bootpRequest * bresp, struct pumpNetIntf * intf) {
    int lease;
    time_t now;

    intf->set &= ~PUMP_INTFINFO_HAS_LEASE;
    if (getVendorCode(bresp, DHCP_OPTION_LEASE, &lease, sizeof(int))) 
	return;

    lease = ntohl(lease);

#ifdef __SNSC_PATCH__
    /*
     * For implementation reasons,
     * no support big lease because type is integer
     */
    if (lease > 0) { /* if (lease && lease != 0xffffffff) { */
#else /* __SNSC_PATCH__ */
    if (lease && lease != 0xffffffff) {
#endif /* __SNSC_PATCH__ */
	now = pumpUptime();
	intf->set |= PUMP_INTFINFO_HAS_LEASE;
	intf->leaseExpiration = now + lease;
#ifdef __SNSC_PATCH__
	intf->renewAt = now + (lease / 8 * 7); /* priority overflow */
#else /* __SNSC_PATCH__ */
	intf->renewAt = now + (7 * lease / 8);
#endif /* __SNSC_PATCH__ */
    }
}

static void addClientIdentifier(int flags, struct bootpRequest * req) {
    char ident[256];

    /*
     * Microsoft uses a client identifier field of the 802.3 address with a
     * pre-byte of a "1".  In order to re-use the DHCP address that they set
     * for this interface, we have to mimic their identifier.
    */

#ifndef __AUTOIP__
    if (!(flags & PUMP_FLAG_WINCLIENTID)) return;

    ident[0] = 1;
    memcpy(ident + 1, req->hwaddr, req->hwlength);
    addVendorCode(req, DHCP_OPTION_CLIENT_IDENTIFIER, req->hwlength + 1, 
		  ident);
#else
    if (flags & PUMP_FLAG_WINCLIENTID){

      ident[0] = 1;
      memcpy(ident + 1, req->hwaddr, req->hwlength);
      addVendorCode(req, DHCP_OPTION_CLIENT_IDENTIFIER, req->hwlength + 1, 
		    ident);
    }else if(configClientId){

      ident[0] = 0;
      /* cpy text include NULL */
      memcpy(ident + 1, configClientId, strlen(configClientId) + 1);
      addVendorCode(req, DHCP_OPTION_CLIENT_IDENTIFIER, strlen(configClientId) + 1, 
		    ident);
    }

    /* not relative, but here additional src code */
    if(configScopeId){
      addVendorCode(req, DHCP_OPTION_SCOPE_IDENTIFIER, strlen(configScopeId), 
		    configScopeId);
    }
#endif
}

static void buildRequest(struct bootpRequest * req, int flags, int type,
		         char * reqHostname, int lease) {
    unsigned char messageType = type;
    short aShort;
    int anInt;
    int numOptions;
    char optionsRequested[50];
    static int aCount = 1;

    addVendorCode(req, DHCP_OPTION_TYPE, 1, &messageType);

    addClientIdentifier(flags, req);

    aShort = ntohs(sizeof(struct bootpRequest));
    addVendorCode(req, DHCP_OPTION_MAXSIZE, 2, &aShort);

    numOptions = 0;
    optionsRequested[numOptions++] = BOOTP_OPTION_NETMASK;
    optionsRequested[numOptions++] = BOOTP_OPTION_GATEWAY;
    optionsRequested[numOptions++] = BOOTP_OPTION_DNS;
    optionsRequested[numOptions++] = BOOTP_OPTION_DOMAIN;
    optionsRequested[numOptions++] = BOOTP_OPTION_BROADCAST;
    optionsRequested[numOptions++] = BOOTP_OPTION_HOSTNAME;
    optionsRequested[numOptions++] = DHCP_OPTION_LOGSRVS;
    optionsRequested[numOptions++] = DHCP_OPTION_LPRSRVS;
    optionsRequested[numOptions++] = DHCP_OPTION_NTPSRVS;
    optionsRequested[numOptions++] = DHCP_OPTION_XFNTSRVS;
    optionsRequested[numOptions++] = DHCP_OPTION_XDMSRVS;
    addVendorCode(req, DHCP_OPTION_OPTIONREQ, numOptions, 
		  optionsRequested);

    req->xid += aCount;

    if (!reqHostname) {
	reqHostname = alloca(200);
#ifdef __SNSC_PATCH__
        if (reqHostname) {
                gethostname(reqHostname, 200);
                if (!strcmp(reqHostname, "localhost") ||
                    !strcmp(reqHostname, "localhost.localdomain"))
                        reqHostname = NULL;
        }
#else /* __SNSC_PATCH__ */
	gethostname(reqHostname, 200);
	if (!strcmp(reqHostname, "localhost") ||
	    !strcmp(reqHostname, "localhost.localdomain"))
	    reqHostname = NULL;
#endif /* __SNSC_PATCH__ */
    }

    if (reqHostname) {
	addVendorCode(req, BOOTP_OPTION_HOSTNAME,
		      strlen(reqHostname) + 1, reqHostname);
    }

    anInt = htonl(lease);
    addVendorCode(req, DHCP_OPTION_LEASE, 4, &anInt);
}

char * pumpDhcpRun(char * device, int flags, int reqLease,
		   char * reqHostname, struct pumpNetIntf * intf,
		   struct pumpOverrideInfo * override) {
    int s;
    struct sockaddr_in serverAddr;
#ifndef __SNSC_PATCH__
    struct sockaddr_in clientAddr;
#endif /* __SNSC_PATCH__ */
    struct sockaddr_in broadcastAddr;
    struct bootpRequest breq, bresp;
    unsigned char * chptr;
    time_t startTime = pumpUptime();
    int true = 1;
    char * saveDeviceName;
    unsigned char messageType;

#ifdef __SNSC_PATCH__
    /* sock_raw var */
    int tmp[1516/4];
    /* 32 bit alignment for ip header */
    char* buf = (char*)tmp + 2;
    int plen;
    int ifindex;
    struct sockaddr_ll sll;
    struct ifreq req;
#endif /* __SNSC_PATCH__ */

#ifdef __AUTOIP__
    if(override){
      configClientId = override->clientId;
      configScopeId = override->scopeId;
    }
#endif /* __AUTOIP__ */
    /* If device is the same as intf->device, don't let the memset()
       blow away the device name */
    saveDeviceName = alloca(strlen(device) + 1);
#ifdef __SNSC_PATCH__
    if (!saveDeviceName) { return perrorstr("alloca"); }
#endif
    strcpy(saveDeviceName, device);
    device = saveDeviceName;

    memset(intf, 0, sizeof(*intf));
    strcpy(intf->device, device);
    intf->reqLease = reqLease;
    intf->set |= PUMP_INTFINFO_HAS_REQLEASE;

#ifdef __SNSC_PATCH__
    s = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
#else /* __SNSC_PATCH__ */
    s = socket(AF_INET, SOCK_DGRAM, 0);
#endif /* __SNSC_PATCH__ */
    if (s < 0) {
	return perrorstr("socket");
    }
#ifdef __SNSC_PATCH__
    clear_raw(s);
#endif /* __SNSC_PATCH__ */

    if (setsockopt(s, SOL_SOCKET, SO_BROADCAST, &true, sizeof(true))) {
	close(s);
	return perrorstr("setsockopt");
    }

    if (flags & PUMP_FLAG_NOCONFIG) {
	if ((chptr = (unsigned char*)getInterfaceInfo(intf, s))) {
	    close(s);
 	    return (char*)chptr;
	}
    } else if ((chptr = (unsigned char*)pumpPrepareInterface(intf, s))) {
	close(s);
	return (char*)chptr;
    }

    if ((chptr = (unsigned char*)prepareRequest(&breq, s, intf->device, startTime))) {
	close(s);
	pumpDisableInterface(intf->device);
	return (char*)chptr;
    }

    messageType = DHCP_TYPE_DISCOVER;
    addVendorCode(&breq, DHCP_OPTION_TYPE, 1, &messageType);

    if (reqHostname) {
#ifndef __DISABLE_LOG_DEBUG__
	syslog(LOG_DEBUG, "HOSTNAME: requesting %s\n", reqHostname);
#endif	/* !__DISABLE_LOG_DEBUG__ */
	addVendorCode(&breq, BOOTP_OPTION_HOSTNAME,
		      strlen(reqHostname) + 1, reqHostname);
    }

    memset(&broadcastAddr,0,sizeof(broadcastAddr));
    broadcastAddr.sin_family = AF_INET;
    broadcastAddr.sin_port = htons(BOOTP_SERVER_PORT);

#if 0
    /* this too! */
    if (intf->set & PUMP_INTFINFO_HAS_BROADCAST)
	broadcastAddr.sin_addr = intf->broadcast;
#endif

    memset(&broadcastAddr.sin_addr, 0xff, 
	   sizeof(broadcastAddr.sin_addr));  /* all 1's broadcast */

#ifndef __SNSC_PATCH__
    memset(&clientAddr.sin_addr, 0, sizeof(&clientAddr.sin_addr));
    clientAddr.sin_family = AF_INET;
    clientAddr.sin_port = htons(BOOTP_CLIENT_PORT);	/* bootp client */

    if (bind(s, (struct sockaddr *) &clientAddr, sizeof(clientAddr))) {
	pumpDisableInterface(intf->device);
	close(s);
	return perrorstr("bind");
    }

    memset(&serverAddr,0,sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(BOOTP_SERVER_PORT);	/* bootp server */

#if 0
    /* seems like a good idea?? */
    if (intf->set & PUMP_INTFINFO_HAS_BOOTSERVER)
	serverAddr.sin_addr = intf->bootServer;
#endif 

#ifndef __DISABLE_LOG_DEBUG__
    syslog (LOG_DEBUG, "PUMP: sending discover\n");
#endif	/* !__DISABLE_LOG_DEBUG__ */

#ifndef __DISABLE_LOG_DEBUG__
    if (override && (override->flags & OVERRIDE_FLAG_NOBOOTP))
      syslog (LOG_DEBUG, "PUMP: Ignoring non-DHCP BOOTP responses\n");
#endif	/* !__DISABLE_LOG_DEBUG__ */
 
    if ((chptr = handleTransaction(s, override, &breq, &bresp, &broadcastAddr,
				   NULL, 1, startTime, DHCP_TYPE_OFFER))) {
				   NULL, (override && (override->flags & OVERRIDE_FLAG_NOBOOTP))?0:1, startTime, DHCP_TYPE_OFFER))) {
	close(s);
	pumpDisableInterface(intf->device);
	return chptr;
    }
#else /* __SNSC_PATCH__ */
  /* get interface index number */
  memset(&req, 0, sizeof(req));
  strncpy(req.ifr_name, device, IFNAMSIZ);
  if (ioctl(s, SIOCGIFINDEX, &req) == -1) {
          pumpDisableInterface(device);
          close(s);
          return perrorstr("SIOCGIFINDEX");
  }
  ifindex = req.ifr_ifindex;

  memset(&sll, 0xff, sizeof(sll));
  sll.sll_family = AF_PACKET;	/* allways AF_PACKET */
  sll.sll_protocol = htons(ETH_P_ALL);
  sll.sll_ifindex = ifindex;
  if (bind(s, (struct sockaddr *)&sll, sizeof sll) == -1) {
          pumpDisableInterface(device);
          close(s);
          return perrorstr("bind");
  }

#ifndef __DISABLE_LOG_DEBUG__
  syslog (LOG_DEBUG, "PUMP: sending discover\n");
#endif	/* !__DISABLE_LOG_DEBUG__ */

  memset(&sll, 0, sizeof(sll));
  sll.sll_ifindex = ifindex;

  plen = make_ip_header4dhcp(s, device, buf, &breq, sizeof(breq), 1);
  if (!plen){
          pumpDisableInterface(device);
          close(s);
          return perrorstr("ip_header");
  }

#ifndef __DISABLE_LOG_DEBUG__
    if (override && (override->flags & OVERRIDE_FLAG_NOBOOTP))
      syslog (LOG_DEBUG, "PUMP: Ignoring non-DHCP BOOTP responses\n");
#endif	/* !__DISABLE_LOG_DEBUG__ */

  if ((chptr = (unsigned char*)handleTransaction_raw(s, override, buf, plen, &bresp, &sll,
                 NULL, (override && (override->flags & OVERRIDE_FLAG_NOBOOTP))?0:1, startTime, DHCP_TYPE_OFFER))) {
          close(s);
          pumpDisableInterface(intf->device);
          return (char*)chptr;
  }

#endif /* __SNSC_PATCH__ */

    /* Otherwise we're in the land of bootp */
    if (dhcpMessageType(&bresp) == DHCP_TYPE_OFFER) {
	/* Admittedly, this seems a bit odd. If we find a dhcp server, we
	   rerun the dhcp discover broadcast, but with the proper option
	   field this time. This makes me rfc compliant. */
#ifndef __DISABLE_LOG_DEBUG__
	syslog (LOG_DEBUG, "got dhcp offer\n");
#endif	/* !__DISABLE_LOG_DEBUG__ */

	initVendorCodes(&breq);
	buildRequest(&breq, flags, DHCP_TYPE_DISCOVER, reqHostname, 
		     intf->reqLease);

#ifndef __DISABLE_LOG_DEBUG__
	syslog (LOG_DEBUG, "PUMP: sending second discover");
#endif	/* !__DISABLE_LOG_DEBUG__ */

#ifndef __SNSC_PATCH__
	/* Send another DHCP_DISCOVER with the proper option list */
	if ((chptr = handleTransaction(s, override, &breq, &bresp, 
				       &broadcastAddr, NULL, 0, 
				       startTime, DHCP_TYPE_OFFER))) {
	    close(s);
	    pumpDisableInterface(intf->device);
	    return chptr;
	}
#else /* __SNSC_PATCH__ */
	plen = make_ip_header4dhcp(s, device, buf, &breq, sizeof(breq), 0);
	if (!plen){
	    pumpDisableInterface(device);
	    close(s);
	    return perrorstr("ip_header");
	}

	if ((chptr = (unsigned char*)handleTransaction_raw(s, override, buf, plen, &bresp, &sll,
					   NULL, 0, startTime, DHCP_TYPE_OFFER))) {
            close(s);
	    pumpDisableInterface(intf->device);
	    return (char*)chptr;
	}
#endif /* __SNSC_PATCH__ */

	if (dhcpMessageType(&bresp) != DHCP_TYPE_OFFER) {
	    close(s);
	    pumpDisableInterface(intf->device);
	    return "dhcp offer expected";
	}

#ifndef __DISABLE_LOG_DEBUG__
	syslog (LOG_DEBUG, "PUMP: got an offer");
#endif	/* !__DISABLE_LOG_DEBUG__ */

	if (getVendorCode(&bresp, DHCP_OPTION_SERVER, &serverAddr.sin_addr, sizeof(struct in_addr))) {
#ifndef __DISABLE_LOG_DEBUG__
	    syslog (LOG_DEBUG, "DHCPOFFER didn't include server address");
#endif	/* !__DISABLE_LOG_DEBUG__ */
	    intf->bootServer = broadcastAddr.sin_addr;
	}

	initVendorCodes(&breq);
	buildRequest(&breq, flags, DHCP_TYPE_REQUEST, reqHostname, 
		     intf->reqLease);

	addVendorCode(&breq, DHCP_OPTION_SERVER, 4, &serverAddr.sin_addr);
	addVendorCode(&breq, DHCP_OPTION_REQADDR, 4, &bresp.yiaddr);

#ifndef __SNSC_PATCH__
	/* why do we need to use the broadcast address here? better reread the
	   spec! */
	if ((chptr = handleTransaction(s, override, &breq, &bresp, 
				       &broadcastAddr, NULL, 0, 
				       startTime, DHCP_TYPE_ACK))) {
	    close(s);
	    pumpDisableInterface(intf->device);
	    return chptr;
	}
#else /* __SNSC_PATCH__ */
	plen = make_ip_header4dhcp(s, device, buf, &breq, sizeof(breq), 0);
	if (!plen){
	    pumpDisableInterface(device);
	    close(s);
	    return perrorstr("ip_header");
	}

	if ((chptr = (unsigned char*)handleTransaction_raw(s, override, buf, plen, &bresp, &sll,
					   NULL, 0, startTime, DHCP_TYPE_ACK))) {
            close(s);
	    pumpDisableInterface(intf->device);
	    return (char*)chptr;
	}
#endif /* __SNSC_PATCH__ */

#ifndef __DISABLE_LOG_DEBUG__
	syslog (LOG_DEBUG, "PUMP: got lease");
#endif	/* !__DISABLE_LOG_DEBUG__ */

	parseLease(&bresp, intf);

	if (getVendorCode(&bresp, DHCP_OPTION_SERVER, &intf->bootServer, sizeof(struct in_addr))) {
#ifndef __DISABLE_LOG_DEBUG__
	    syslog (LOG_DEBUG, "DHCPACK didn't include server address");
#endif	/* !__DISABLE_LOG_DEBUG__ */
	    intf->bootServer = broadcastAddr.sin_addr;
	}

	intf->set |= PUMP_INTFINFO_HAS_BOOTSERVER;
    }

    close(s);

#ifndef __SNSC_PATCH__
    parseReply(&bresp, intf);
#else /* __SNSC_PATCH__ */
    if(parseReply(&bresp, intf) != 0)
        return "parse reply";
#endif /* __SNSC_PATCH__ */
    if (flags & PUMP_FLAG_FORCEHNLOOKUP)
	intf->set &= ~(PUMP_NETINFO_HAS_DOMAIN | PUMP_NETINFO_HAS_HOSTNAME);

    /* Save these for later */
    intf->flags = flags & PUMP_FLAG_WINCLIENTID;

#ifdef __AUTOIP__
    intf->set &= ~PUMP_NETINFO_DO_AUTOIP;
    intf->set &= ~PUMP_NETINFO_DO_UNLINK;
#endif
    return NULL;
}

/**
 * This code chunk(check_by_mii(), check_by_ethtool()) was contributed by
 * Sony Corporation.
 */
typedef __uint64_t u64;
typedef __uint32_t u32;
typedef __uint16_t u16;
typedef __uint8_t u8;
#include <linux/ethtool.h>

static int
check_by_mii(const int fd, struct ifreq *ifr)
{
#ifndef SIOCGMIIPHY
#define SIOCGMIIPHY (SIOCDEVPRIVATE)	/* Read from current PHY */
#define SIOCGMIIREG (SIOCDEVPRIVATE+1) 	/* Read any PHY register */
#endif
#define MII_BMCR		0 /* Control Register */
#define MII_BMSR		1 /* Status Register */
#define MII_BMSR_LINK_VALID	0x00000004
#define BMSR_LSTATUS            0x0004  /* Link status */

        /* This data structure is used for all the MII ioctl's */
	struct mii_data {
		__u16	phy_id;
		__u16	reg_num;
		__u16	val_in;
		__u16	val_out;
	};

	struct mii_data *mii;
	uint32_t addr;

	addr = (uint32_t)&ifr->ifr_data;
	mii = (struct mii_data *)addr;
	if(ioctl(fd, SIOCGMIIPHY, ifr) < 0 &&
	   ioctl(fd, SIOCDEVPRIVATE, ifr) < 0){
		DPRINT("SIOCGMIIPHY: %s\n", strerror(errno));
		return -errno;
	}

	mii->reg_num = MII_BMSR;
	if(ioctl(fd, SIOCGMIIREG, ifr) < 0 &&
	   ioctl(fd, SIOCDEVPRIVATE + 1, ifr) < 0){
		DPRINT("SIOCGMIIREG: %s\n", strerror(errno));
		return -errno;
	}
	return (mii->val_out & BMSR_LSTATUS) ? 1 : 0;
}

static int
check_by_ethtool(const int fd, struct ifreq *ifr)
{
#if defined(__SNSC_PATCH__) && defined(DISABLE_CHECK_BY_ETHTOOL)
	return (-1);
#else   /* !(defined(__SNSC_PATCH__) && defined(DISABLE_CHECK_BY_ETHTOOL)) */
	struct ethtool_value edata;

	edata.cmd = ETHTOOL_GLINK;
	ifr->ifr_data = (caddr_t)&edata;
	if(ioctl(fd, SIOCETHTOOL, ifr) == 0){
		return edata.data ? 1 : 0 ;
	}
	return -errno;
#endif /* defined(__SNSC_PATCH__) && defined(DISABLE_CHECK_BY_ETHTOOL) */
}

/**
 * Check the link. First it checks by ethtool.
 * Next, it checks by mii.
 * @param  ifname(in) Interface name, like "eth0".
 * @retval 1  Link OK
 * @retval 0  No link
 * @retval <0 System error, -errno
 */
int32_t
pumpAutoipMiiTool(const char* ifname)
{
	struct ifreq ifr;
	int r;
	int fd;

	fd = socket(AF_INET, SOCK_DGRAM, 0);
	if (fd < 0) {
		return -errno;
	}
	memset(&ifr, 0, sizeof(ifr));
	strncpy(ifr.ifr_name, ifname, IFNAMSIZ - 1);
	r = check_by_ethtool(fd, &ifr);
#if !defined(DEBUG_MII)
	DPRINT("ethtool result:%d\n", r);
	if(r < 0){
		r = check_by_mii(fd, &ifr);
		DPRINT("mii result:%d\n", r);
	}
#else /* defined(DEBUG_MII) */
	r = check_by_mii(fd, &ifr);
	DPRINT("mii result:%d\n", r);
#endif /* defined(DEBUG_MII) */
	close(fd);
	return r;
}

#ifdef __AUTOIP__
char * pumpAutoipRenew(char * device, int flags, int reqLease,
		       char * reqHostname, struct pumpNetIntf * intf,
		       struct pumpOverrideInfo * override) 
{
  int s;
  struct bootpRequest breq, bresp;
  struct pumpNetIntf tmp_intf;
  unsigned char * chptr;
  time_t startTime = pumpUptime();
  int true = 1;
  //  char * saveDeviceName;
  unsigned char messageType;
  int now;

  struct sockaddr_in * addrp;
  struct rtentry route;
  struct ifreq req;

  /* sock_raw var */
  int tmp[1516/4];
  /* 32 bit alignment for ip header */
  char* buf = (char*)tmp + 2;
  int plen;
  int ifindex;
  struct sockaddr_ll sll;

  int autoip_lease_sec = AUTOIP_LEASE_SEC;
  if(override && override->autoip_lease_sec != 0){
      autoip_lease_sec = override->autoip_lease_sec;
  }

  /* renew intf for autoip mode */
  /* lease time second */
  now = pumpUptime();
  intf->set |= PUMP_INTFINFO_HAS_LEASE;
  intf->leaseExpiration = now + autoip_lease_sec;
  intf->renewAt = now + (7 * autoip_lease_sec / 8);

  /* v v v v -- from this line, for link check -- v v v v */
  if(override && override->flags & OVERRIDE_FLAG_LINKCHECK && 
     pumpAutoipMiiTool(device) == 0){ /* no link */
    pumpDisableInterface(device);
    return 0; /* autoip error, 0 means dhcp succeed or no link*/
  }
  /* v v v v -- from this line, for dhcp discover -- v v v v */

  /* If device is the same as intf->device, don't let the memset()
     blow away the device name */
  //  saveDeviceName = alloca(strlen(device) + 1);
  //  strcpy(saveDeviceName, device);
  //  device = saveDeviceName;

  memset(&tmp_intf, 0, sizeof(tmp_intf));
  strcpy(tmp_intf.device, device);
  tmp_intf.reqLease = reqLease;
  tmp_intf.set |= PUMP_INTFINFO_HAS_REQLEASE;

//  s = socket(AF_INET, SOCK_DGRAM, 0);
  s = socket(PF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
  clear_raw(s);

  if (s < 0) {
    pumpDisableInterface(device);
    return perrorstr("socket");
  }

  if (setsockopt(s, SOL_SOCKET, SO_BROADCAST, &true, sizeof(true))) {
    pumpDisableInterface(device);
    close(s);
    return perrorstr("setsockopt");
  }

  /* ---------------------------- */
  memset(&req,0,sizeof(req));
  addrp = (struct sockaddr_in *) &req.ifr_addr;

  strcpy(req.ifr_name, intf->device);
  addrp->sin_family = AF_INET;
  addrp->sin_port = 0;
  memset(&addrp->sin_addr, 0, sizeof(addrp->sin_addr));

  addrp->sin_family = AF_INET;
  addrp->sin_addr.s_addr = htonl(0);

  if (ioctl(s, SIOCGIFFLAGS, &req)){
    pumpDisableInterface(device);
    close(s);
    return perrorstr("SIOCGIFFLAGS");
  }
  req.ifr_flags |= IFF_UP | IFF_BROADCAST | IFF_RUNNING;
  if (ioctl(s, SIOCSIFFLAGS, &req)){
    pumpDisableInterface(device);
    close(s);
    return perrorstr("SIOCSIFFLAGS");
  }

  memset(&route, 0, sizeof(route));
  memcpy(&route.rt_gateway, addrp, sizeof(*addrp));

  addrp->sin_family = AF_INET;
  addrp->sin_port = 0;
  addrp->sin_addr.s_addr = INADDR_ANY;
  memcpy(&route.rt_dst, addrp, sizeof(*addrp));
  memcpy(&route.rt_genmask, addrp, sizeof(*addrp));

  route.rt_dev = intf->device;
  route.rt_flags = RTF_UP;
  route.rt_metric = 0;

  if (ioctl(s, SIOCADDRT, &route)) {
    if (errno != EEXIST) {
      pumpDisableInterface(device);
      close(s);
      return perrorstr("SIOCADDRT 3");
    }
  }

  if ((chptr = (unsigned char*)prepareRequest(&breq, s, tmp_intf.device, startTime))) {
    pumpDisableInterface(device);
    close(s);
    return (char*)chptr;
  }
  /* ---------------------------- */

  messageType = DHCP_TYPE_DISCOVER;
  addVendorCode(&breq, DHCP_OPTION_TYPE, 1, &messageType);

  if (reqHostname) {
#ifndef __DISABLE_LOG_DEBUG__
    syslog(LOG_DEBUG, "HOSTNAME: requesting %s\n", reqHostname);
#endif	/* !__DISABLE_LOG_DEBUG__ */
    addVendorCode(&breq, BOOTP_OPTION_HOSTNAME,
		  strlen(reqHostname) + 1, reqHostname);
  }

#ifndef __DISABLE_LOG_DEBUG__
  syslog (LOG_DEBUG, "PUMP: sending discover @autoip renew\n");
#endif	/* !__DISABLE_LOG_DEBUG__ */

  /* get interface index number */
  memset(&req, 0, sizeof(req));
  strncpy(req.ifr_name, device, IFNAMSIZ);
  if (ioctl(s, SIOCGIFINDEX, &req) == -1) {
          pumpDisableInterface(device);
          close(s);
          return perrorstr("SIOCGIFINDEX");
  }
  ifindex = req.ifr_ifindex;

  memset(&sll, 0xff, sizeof(sll));
  sll.sll_family = AF_PACKET;	/* allways AF_PACKET */
  sll.sll_protocol = htons(ETH_P_ALL);
  sll.sll_ifindex = ifindex;
  if (bind(s, (struct sockaddr *)&sll, sizeof sll) == -1) {
          pumpDisableInterface(device);
          close(s);
          return perrorstr("bind");
  }

#ifndef __DISABLE_LOG_DEBUG__
  syslog (LOG_DEBUG, "PUMP: sending discover @autoip renew\n");
#endif	/* !__DISABLE_LOG_DEBUG__ */

  memset(&sll, 0, sizeof(sll));
  sll.sll_ifindex = ifindex;

  plen = make_ip_header4dhcp(s, device, buf, &breq, sizeof(breq), 1);
  if (!plen){
          pumpDisableInterface(device);
          close(s);
          return perrorstr("ip_header");
  }

#ifndef __DISABLE_LOG_DEBUG__
    if (override && (override->flags & OVERRIDE_FLAG_NOBOOTP))
      syslog (LOG_DEBUG, "PUMP: Ignoring non-DHCP BOOTP responses\n");
#endif	/* !__DISABLE_LOG_DEBUG__ */

  if ((chptr = (unsigned char*)handleTransaction_raw_autoip_with_check_arp(s, override, buf, plen, &bresp, &sll,
             NULL, (override && (override->flags & OVERRIDE_FLAG_NOBOOTP))?0:1, startTime, DHCP_TYPE_OFFER,
             device, intf))) {
#ifndef __DISABLE_LOG_DEBUG__
          syslog (LOG_DEBUG, "PUMP: dhcp discover check fail @autoip %s\n", 
                  chptr);
#endif	/* !__DISABLE_LOG_DEBUG__ */
          /* pumpDisableInterface(device); comment out is for no flush */
          close(s);
          return (char*)chptr;
  }
  close(s);
  return 0;
}
/******************************************************************************

******************************************************************************/
int
pumpGetIfInfo(int iofd, char *devname, struct ifreq *ifreq, int flavor)
{
    bzero(ifreq, sizeof(*ifreq));
    strcpy(ifreq->ifr_name, devname);

    return ioctl(iofd, flavor, ifreq);
}
/******************************************************************************

******************************************************************************/
#ifdef __AUTOIP__
char *pumpAutoipGenLinkLocalAddr(int s, 
				  char* device, 
				  char *hwaddr, 
				  int *lladdr)
{
  int i;

  struct ifreq req;
  unsigned int random;
  memset(&req,0,sizeof(req));


  if(pumpGetIfInfo(s, device, &req, SIOCGIFHWADDR)){
    return perrorstr("SIOCSIFHWADDR");
  }

  memcpy(hwaddr, req.ifr_hwaddr.sa_data, IFHWADDRLEN);

  /* this is making of transaction id,  but usefull to make autoip. */
  random = pumpUptime();
  for (i = 0; i < IFHWADDRLEN; i++)
    random ^= hwaddr[i] << (8 * (i % 2));

  /* Link local addr is "169.254.1.0 ~ 169.254.254.255" */
  if((random &= 0xFFFF) > 0xFDFF)
      random &= 0xFDFF;

  *lladdr = ntohl(0xA9FE0100 + random);
  return 0;
}
/******************************************************************************

******************************************************************************/
char*
substitute_ll_to_sockaddr(struct sockaddr_ll *ll_to, char *ifname)
{
	struct ifreq ifreq;
	int iofd;

	memset(ll_to, 0, sizeof(*ll_to));

	ll_to->sll_family = AF_PACKET;
	ll_to->sll_protocol = htons(ETH_P_ARP);
	ll_to->sll_hatype = htons(ARPHRD_ETHER);
	ll_to->sll_pkttype = PACKET_BROADCAST;
	ll_to->sll_halen = ETH_ALEN;

	if ((iofd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		return perrorstr("ioctl socket creation");
	}
	memset(&(ll_to->sll_addr[0]), 0xFF, ETH_ALEN);

	pumpGetIfInfo(iofd, ifname, &ifreq, SIOCGIFINDEX);
	ll_to->sll_ifindex   = ifreq.ifr_ifindex;
	close(iofd);
	return NULL;
}
char*
substitute_ll_from_sockaddr(struct sockaddr_ll *ll_from, char *ifname)
{
	struct ifreq ifreq;
	int iofd;

	memset(ll_from, 0, sizeof(*ll_from));

	ll_from->sll_family = AF_PACKET;
	ll_from->sll_protocol = htons(ETH_P_ARP);
	ll_from->sll_hatype = htons(ARPHRD_ETHER);
	ll_from->sll_pkttype = PACKET_HOST;
	ll_from->sll_halen = ETH_ALEN;

	if ((iofd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		return perrorstr("ioctl socket creation");
	}
	pumpGetIfInfo(iofd, ifname, &ifreq, SIOCGIFHWADDR);
	memcpy(&(ll_from->sll_addr[0]), ifreq.ifr_hwaddr.sa_data, ETH_ALEN);

	pumpGetIfInfo(iofd, ifname, &ifreq, SIOCGIFINDEX);
	ll_from->sll_ifindex = ifreq.ifr_ifindex;

	close(iofd);
	return NULL;
}

static char*
create_arp_packet(struct arppkt *arppkt, int senderIpAddress, 
			int targetIpAddress, char *ifname)
{
	struct ifreq ifreq;

	memset(arppkt, 0, sizeof(*arppkt));
	arppkt->arpbody.arp_hrd = htons(ARPHRD_ETHER);
	arppkt->arpbody.arp_pro = htons(ETH_P_IP);
	arppkt->arpbody.arp_hln = 6;
	arppkt->arpbody.arp_pln = 4;
	arppkt->arpbody.arp_op  = htons(ARPOP_REQUEST); 

	memcpy(arppkt->arpbody.arp_spa, &senderIpAddress, 4);
	memcpy(arppkt->arpbody.arp_tpa, &targetIpAddress, 4);

	if(getIfInfo(ifname, &ifreq, SIOCGIFHWADDR) == -1){
		DPRINT("ERROR getIfInfo\n");
		return perrorstr("ioctl socket creation");
	}
	memcpy(arppkt->arpbody.arp_sha, ifreq.ifr_hwaddr.sa_data, ETH_ALEN);
	memset(arppkt->arpbody.arp_tha, 0, ETH_ALEN);
	return NULL;
}
static char*
create_arp_announce_packet(struct arppkt *arppkt, int claimIpAddress, char *ifname)
{
   /*
   2.4.  Announcing an Address
   An ARP announcement is identical to the ARP Probe described above, except
   that now the sender and target IP addresses are both set to the host's 
   newly selected IPv4 address. 
   */
	return create_arp_packet(arppkt, claimIpAddress, claimIpAddress, ifname);
}

static char*
create_arp_probe_packet(struct arppkt *arppkt, int targetIpAddress, char *ifname)
{
    /*
    2.2.1.  Probe details
    An ARP Request constructed this way with an all-zero'sender IP address' 
    is referred to as an "ARP Probe".
    */
	return create_arp_packet(arppkt, 0, targetIpAddress, ifname);
}
/******************************************************************************

******************************************************************************/
char *
pumpAutoipClaimCheck(char* device, 
		     int *claimIpAddr, 
		     int numProbes, 
		     int intervalTime)
{
  int rawfd;
  int repeat;
  int spa;
  int tpa;
  ssize_t size;
  struct sockaddr_ll ll_from, ll_to;
  struct arppkt      arppkt;
  /* char thostname[MAXHOSTNAMELEN];*/

  int i;
  struct timeval tv;
  int endTime, restTime;
  fd_set readfs;

  if(create_arp_probe_packet(&arppkt, *claimIpAddr, device)){
    return perrorstr("create_arp_probe_packet");
  }
  if(substitute_ll_to_sockaddr(&ll_to, device) != 0){
    return perrorstr("substitute_ll_to_sockaddr");
  }
  if(substitute_ll_from_sockaddr(&ll_from, device) != 0){
    return perrorstr("substitute_ll_from_sockaddr");
  }

  if ((rawfd = socket(PF_PACKET, SOCK_DGRAM, htons(ETH_P_ARP))) < 0) {
    return perrorstr("raw socket creatin");
  } 

  if (bind(rawfd, (struct sockaddr *)&ll_from, sizeof(ll_from)) < 0) {
	  DPRINT("bind failed:%d\n", errno);
          close(rawfd);
    return perrorstr("bind");
  }

  for(repeat = 0; repeat < numProbes; repeat++){
    if ((size = sendto(rawfd, (void *)&arppkt, sizeof(struct arppkt), 0,
		       (struct sockaddr *)&ll_to, sizeof(ll_to))) < 0) {
          close(rawfd);
      return perrorstr("write");
    }
    endTime = pumpUptime() + intervalTime;

    while((restTime = endTime - pumpUptime()) > 0){
      FD_ZERO(&readfs);
      FD_SET(rawfd, &readfs);
      tv.tv_usec = 0;
      tv.tv_sec = restTime;
      DPRINT("select: Probing...\n");
      i = select(rawfd + 1, &readfs, NULL, NULL, &tv);
      switch (i) {
      case 0: /* time out */
	;
	break;
      case 1: /* arp responce */
	i = sizeof(ll_from);
	bzero(&arppkt, sizeof(arppkt));
	if (recvfrom(rawfd, &arppkt, sizeof(arppkt), 0, 
		     (struct sockaddr *)&ll_from, (socklen_t*)&i) < 0){
	  close(rawfd);
	  return perrorstr("recvfrom");
	}

	if(arppkt.arpbody.arp_hrd == htons(ARPHRD_ETHER) && 
	   arppkt.arpbody.arp_hln == 6 &&
	   arppkt.arpbody.arp_pro == htons(ETH_P_IP) && 
	   arppkt.arpbody.arp_pln == 4){ /* find arp protocol */

          struct ifreq ifreq;
          int iofd;
          /*
           * Check packet for receiving own packet by HW addr.
           */
          if ((iofd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
                  close(rawfd);
                  return perrorstr("socket for SIOCGIFHWADDR");
          }
          if (pumpGetIfInfo(iofd, device, &ifreq, SIOCGIFHWADDR)) {
                  close(iofd);
                  close(rawfd);
                  return perrorstr("SIOCGIFHWADDR");
          }
          close(iofd);

          if (memcmp(ifreq.ifr_hwaddr.sa_data, arppkt.arpbody.arp_sha, 
                     ETH_ALEN) == 0) {
#ifndef __DISABLE_LOG_DEBUG__
                  syslog (LOG_DEBUG, "received own arp packet\n");
#endif	/* !__DISABLE_LOG_DEBUG__ */
                  break;
          }

          memcpy(&spa, arppkt.arpbody.arp_spa, sizeof(int));
	  if(spa == *claimIpAddr){
		if(arppkt.arpbody.arp_op == htons(ARPOP_REPLY) ||
		   arppkt.arpbody.arp_op == htons(ARPOP_REQUEST)){
			DPRINT("1>ARP confilct at ARP Probing" \
				"(ARP_SPA == claim_addr)\n");
			*claimIpAddr = 0;
			close(rawfd);
			return 0;
		}
	  }
          memcpy(&tpa, arppkt.arpbody.arp_tpa, sizeof(int));
	  if(spa == 0 && tpa == *claimIpAddr){
	  	if(arppkt.arpbody.arp_op == htons(ARPOP_REQUEST)){
			DPRINT("2>ARP confilct at ARP Probing" \
			    " (ARP_TPA == claim_address && ARP Probe)\n");
			*claimIpAddr = 0;
			close(rawfd);
			return 0;
		}
	  }
	}
	break;
      default: /* select err */
	close(rawfd);
	return perrorstr("select");
      }
    }
  }
  close(rawfd);
  return 0;
}
int
createAutoipSocket(char* device)
{
	int autoipsock = -1;
	struct sockaddr_ll ll_from;

	if((autoipsock = socket(PF_PACKET, SOCK_DGRAM, htons(ETH_P_ARP))) == -1){
		DPRINT("Error:raw socket creating\n");
		goto NG;
	}
	if(substitute_ll_from_sockaddr(&ll_from, device) != 0){
		DPRINT("Error:substitute_ll_from_sockaddr\n");
		goto NG;
	}
	if(bind(autoipsock, (struct sockaddr *)&ll_from, sizeof(ll_from)) == -1){
		DPRINT("Error:bind\n");
		goto NG;
	}
	/*OK*/
	return autoipsock;
NG:
	if(autoipsock != -1){
		close(autoipsock);
	}
	return -1;
}
static int
judge_packet_at_autoip(char* device, int claimAddr, struct arppkt *recv_arppkt)
{
	int spa;
	struct ifreq  ifreq;

	/* Check whether the packet is ARP or not*/
	if(recv_arppkt->arpbody.arp_hrd != htons(ARPHRD_ETHER) ||
	   recv_arppkt->arpbody.arp_hln != 6 ||
	   recv_arppkt->arpbody.arp_pro != htons(ETH_P_IP) ||
	   recv_arppkt->arpbody.arp_pln != 4){
		return 0; /* not ARP packet */
	}
	if(recv_arppkt->arpbody.arp_op != htons(ARPOP_REPLY) &&
	   recv_arppkt->arpbody.arp_op != htons(ARPOP_REQUEST)){
		return 0; /* not (REQUEST *or* REPLY) */
	}
	memcpy(&spa, recv_arppkt->arpbody.arp_spa, sizeof(int));
	if(spa != claimAddr){
		return 0; /* different IP address */
	}
	/* MAC check */
	if(getIfInfo(device, &ifreq, SIOCGIFHWADDR) == -1){
		DPRINT("Error:SIOCGIFHWADDR\n");
		return -1;
	}
	if(memcmp(ifreq.ifr_hwaddr.sa_data, recv_arppkt->arpbody.arp_sha, 
				ETH_ALEN) == 0){
		DPRINT("NOTICE:Received my own arp packet\n");
		return 0; /* same MAC address */
	}
	return 1; /* conflict detected */
}
/**
 * Receive & judge the packet. 
 * This function is used only at AutoIP state, NOT Probing state.
 * @note  Call this function after you confirm select(2) breaks by AutoIP-socket.
 * @param  device(in) Interface name, like "eth0"
 * @param  rawfd(in) Socket fd
 * @param  claimAddr(in) Claiming IP address
 * @retval -1  System error
 * @retval 0  OK
 * @retval 1  ARP Conflict packet detected.
 */
int
receive_and_judge_packet(char* device, int rawfd, int claimAddr)
{
	socklen_t socklen;
	struct sockaddr_ll from;
	struct arppkt recv_arppkt;
	socklen = sizeof(from);

	memset(&recv_arppkt, 0, sizeof(struct arppkt));
	if(recvfrom(rawfd, &recv_arppkt, sizeof(struct arppkt), 0, 
			(struct sockaddr *)&from, &socklen) == -1){
		DPRINT("Error:recvfrom\n");
		return -1;
	}
	return judge_packet_at_autoip(device, claimAddr, &recv_arppkt);
}
/**
 * Send ARP announce packets 2 times, The interval is 2 seconds.
 * @param  device(in) Device name
 * @param  claimAddr(in) Claiming IP address
 * @retval -1  System error
 * @retval 0  OK
 * @see RFC3927 2.4 & 2.5
 */
static int
autoip_send_arp_announce(char* device, int claimAddr)
{
	int on =  1;
	int fd = -1;
	struct sockaddr_ll ll_to;
	struct arppkt send_arppkt;
	int retv = -1;

	if(create_arp_announce_packet(&send_arppkt, claimAddr, device) != 0){
		DPRINT("Error:create_arp_announce_packet\n");
		retv = -1;
		goto END;
	}
	if(substitute_ll_to_sockaddr(&ll_to, device) != 0){
		DPRINT("Error:substitute_ll_to_sockaddr\n");
		retv = -1;
		goto END;
	}
	if((fd = createAutoipSocket(device)) == -1){
		DPRINT("Error:createAutoipSocket\n");
		retv = -1;
		goto END;
	}
	if(setsockopt(fd, SOL_SOCKET, SO_BROADCAST, &on, sizeof(on))){
		DPRINT("Error:SO_BROADCAST\n");
		retv = -1;
		goto END;
	}
	DPRINT("1st ARP ANNOUNCE\n");
	if(sendto(fd, (void *)&send_arppkt, sizeof(struct arppkt), 0,
			(struct sockaddr *)&ll_to, sizeof(ll_to)) == -1){
		DPRINT("Error:sendto\n");
		retv = -1;
		goto END;
	}
	sleep(AUTOIP_ARP_ANNOUNCE_INTERVAL_SEC);
	DPRINT("2nd ARP ANNOUNCE\n");
	if(sendto(fd, (void *)&send_arppkt, sizeof(struct arppkt), 0,
			(struct sockaddr *)&ll_to, sizeof(ll_to)) == -1){
		DPRINT("Error:sendto\n");
		retv = -1;
		goto END;
	}
	retv = 0;
END:
	if(fd != -1){ close(fd);}
	return retv;
}
/******************************************************************************

******************************************************************************/
static void 
pumpAutoipSetupInterface(struct pumpNetIntf *intf, int ipAddr, 
                         struct pumpOverrideInfo *override)
{

  struct in_addr addr;
  int now;
  int autoip_lease_sec = AUTOIP_LEASE_SEC;
  if(override && override->autoip_lease_sec != 0){
      autoip_lease_sec = override->autoip_lease_sec;
  }

  /* Autoip means static or dynamic ???
     intf->isDynamic = 1;
  */

  if(!ipAddr){
    now = pumpUptime();
    intf->set |= PUMP_INTFINFO_HAS_LEASE;
    intf->leaseExpiration = now + autoip_lease_sec;
    intf->renewAt = now + (7 * autoip_lease_sec / 8);

    intf->set |= PUMP_NETINFO_DO_AUTOIP;
    intf->set &= ~PUMP_NETINFO_DO_UNLINK;
    return ;
  }

  addr.s_addr = ipAddr;
  intf->ip = addr;
  intf->set |= PUMP_INTFINFO_HAS_IP;

  addr.s_addr &= htonl(0xFFFF0000);
  intf->network = addr;
  intf->set |= PUMP_INTFINFO_HAS_NETWORK;

  addr.s_addr = 0xFFFFFFFF;
  intf->broadcast = addr;
  intf->set |= PUMP_INTFINFO_HAS_BROADCAST;

  addr.s_addr = htonl(0xFFFF0000);
  intf->netmask = addr;
  intf->set |= PUMP_INTFINFO_HAS_NETMASK;
  /*
    addr.s_addr = 0;
    intf->gateway = addr;
    intf->set |=  PUMP_NETINFO_HAS_GATEWAY;
  */

  /*
    intf->dnsServers[0] = addr;
  */
  intf->numDns = 0;
  intf->set &= ~PUMP_NETINFO_HAS_HOSTNAME;
  intf->set &= ~PUMP_NETINFO_HAS_DOMAIN;

  /* lease time second */
  now = pumpUptime();
  intf->set |= PUMP_INTFINFO_HAS_LEASE;
  intf->leaseExpiration = now + autoip_lease_sec;
  intf->renewAt = now + (7 * autoip_lease_sec / 8);

  intf->set |= PUMP_NETINFO_DO_AUTOIP;
  intf->set &= ~PUMP_NETINFO_DO_UNLINK;

  return ;
}
/******************************************************************************

******************************************************************************/
static char *
executeArpProbe(char *device, 
	      int flags,                        /* now ignore */
	      int reqLease,                     /* ignore */
	      char *reqHostname,                /* ignore */
	      struct pumpNetIntf *intf,
	      struct pumpOverrideInfo *override,
	      int *result_addr, int useold)
{

  int s, true = 1;
  int tmpAddr = 0;
  int i;
  int nrepeat;
  char hwaddr[14];	/* 14 bytes of protocol address	*/
  unsigned char * chptr;
  FILE* f;
  char buff[50];
  char * saveDeviceName;

  /* If device is the same as intf->device, don't let the memset()
     blow away the device name */
  saveDeviceName = alloca(strlen(device) + 1);
#ifdef __SNSC_PATCH__
  if (!saveDeviceName) { return perrorstr("alloca"); }
#endif /* __SNSC_PATCH__ */
  strcpy(saveDeviceName, device);
  device = saveDeviceName;

  memset(intf, 0, sizeof(*intf));
  strcpy(intf->device, device);

  if (!(override && override->flags & OVERRIDE_FLAG_AUTOIP)){
    intf->set |= PUMP_NETINFO_DO_AUTOIP;
    pumpAutoipSetupInterface(intf, 0, override);
    return 0; /* succeed */
  }
#ifndef __DISABLE_LOG_INFO__
  syslog (LOG_INFO, "autoip start %s", device);
#endif  /* !__DISABLE_LOG_INFO__ */
  s = socket(AF_INET, SOCK_DGRAM, 0);
  if (s < 0) {
    pumpDisableInterface(device);
    DPRINT("socket(AF_INET, SOCK_DGRAM,0) fail\n");
    return perrorstr("socket");
  }
  if (setsockopt(s, SOL_SOCKET, SO_BROADCAST, &true, sizeof(true))) {
    close(s);
    pumpDisableInterface(device);
    DPRINT("setsockopt(s, SOL_SOCKET, SO_BROADCAST...) fail\n");
    return perrorstr("setsockopt");
  }
  if ((chptr = (unsigned char*)pumpPrepareInterface(intf, s))) {
    close(s);
    pumpDisableInterface(device);
    DPRINT("pumpPrepareInterface(intf, s) fail\n");
    return (char*)chptr;
  }

  /* use last time addr */
  if(useold == PUMP_OLD_AUTOIP_ADDR){
    sprintf(buff, "%s.%s", AUTOIP_CONFIG_FILE_PREFIX, device);
    f = fopen(buff, "r");
    if(f){
      fgets(buff, sizeof(buff), f);
      inet_aton(buff, (struct in_addr*)&tmpAddr);
#ifndef __DISABLE_LOG_INFO__
      syslog (LOG_INFO, "last autoip %s", buff);
#endif  /* !__DISABLE_LOG_INFO__ */
      fclose(f);

      if((chptr = (unsigned char*)pumpAutoipClaimCheck(device, 
				     &tmpAddr, 
				     AUTOIP_ARP_PROBES_TIME, 
				     AUTOIP_ARP_INTERVAL_SEC)) != 0){
        close(s);
        pumpDisableInterface(device);
        return (char*)chptr;
      }
    }
  }

  /* last time addr can't be used */
  nrepeat = AUTOIP_ARP_REPEAT_TIME;
  while(1){
	for(i = 0; tmpAddr == 0 && i < nrepeat; i++){
		if((chptr = (unsigned char*)pumpAutoipGenLinkLocalAddr(s, device, hwaddr, &tmpAddr)) != 0){
			close(s);
			pumpDisableInterface(device);
			return (char*)chptr;
		}
		if((chptr = (unsigned char*)pumpAutoipClaimCheck(device, 
			     &tmpAddr, 
			     AUTOIP_ARP_PROBES_TIME, 
			     AUTOIP_ARP_INTERVAL_SEC)) != 0){
			close(s);
			pumpDisableInterface(device);
			return (char*)chptr;
		}
	}
	if(tmpAddr == 0){
		DPRINT("AUTOIP ARP PROBE FAILED\n");
		DPRINT("SLEEP...\n");
		sleep(AUTOIP_RATE_LIMIT_INTERVAL_SEC);
		nrepeat = 1;
		continue;
	}
	break;
  }

  sprintf(buff, "%s.%s", AUTOIP_CONFIG_FILE_PREFIX, device);
  f = fopen(buff, "w");
  if(f == 0){
    pumpDisableInterface(device);
    close(s);
    DPRINT("cannot create %s\n", buff);
    return perrorstr("Cannot create autoip.conf");
  }
  fprintf(f, "%s\n", inet_ntoa(*(struct in_addr*)&tmpAddr)); /* write address */
  fclose(f);


  pumpAutoipSetupInterface(intf, tmpAddr, override);
  *result_addr = tmpAddr;
  close(s);
  return 0;
}
char *
pumpAutoipRun(char *device, 
	      int flags,                        /* now ignore */
	      int reqLease,                     /* ignore */
	      char *reqHostname,                /* ignore */
	      struct pumpNetIntf *intf,
	      struct pumpOverrideInfo *override,
	      int useold)
{
	int decidecaddr = 0;
	char* retv;

	retv = executeArpProbe(device, flags, reqLease, 
			reqHostname, intf, override, &decidecaddr, useold);
	if(retv != 0){
		DPRINT("Error executeArpProbe\n");
		return retv;
	}
	if(decidecaddr != 0){
		if(autoip_send_arp_announce(device, decidecaddr) != 0){
			DPRINT("Error autoip_send_arp_announce\n");
			return perrorstr("autoip_send_arp_announce");
		}
	}
	retv = NULL;
	return retv;
}
#endif /*__AUTOIP__*/
/******************************************************************************

******************************************************************************/
char *
pumpUnlinkRun(char *device, struct pumpNetIntf * intf, 
	      struct pumpOverrideInfo * override){
  int now;
  char * saveDeviceName;

  if (!(override && override->flags & OVERRIDE_FLAG_LINKCHECK)){
    intf->set &= ~PUMP_NETINFO_DO_UNLINK;
    return "link_ok";
  }

  /* at first, link check */
  if(pumpAutoipMiiTool(device) == 0){ /* no link */

    /* If device is the same as intf->device, don't let the memset()
       blow away the device name */
    saveDeviceName = alloca(strlen(device) + 1);
#ifdef __SNSC_PATCH__
  if (!saveDeviceName) { return perrorstr("alloca"); }
#endif /* __SNSC_PATCH__ */
    strcpy(saveDeviceName, device);
    device = saveDeviceName;

    memset(intf, 0, sizeof(struct pumpNetIntf));
    strcpy(intf->device, device);

    intf->set |= PUMP_NETINFO_DO_UNLINK;
    intf->set &= ~PUMP_NETINFO_DO_AUTOIP;

    now = pumpUptime();
    intf->set |= PUMP_INTFINFO_HAS_LEASE;
    intf->leaseExpiration = now + AUTOIP_LEASE_SEC_UNLINK;
    intf->renewAt = now + (7 * AUTOIP_LEASE_SEC_UNLINK / 8);
    return 0;

  }else{
    intf->set &= ~PUMP_NETINFO_DO_UNLINK;
#ifndef __DISABLE_LOG_INFO__
    syslog(LOG_INFO, "link ok %s", device);
#endif  /* !__DISABLE_LOG_INFO__ */
#if 0
    pumpSetupInterface(intf);
#endif

    return "link_ok";
  }
}
/******************************************************************************

******************************************************************************/
char *
pumpUnlinkRenew(char *device, struct pumpNetIntf * intf, 
		struct pumpOverrideInfo * override)
{
  return pumpUnlinkRun(device, intf, override);
}
/******************************************************************************/
#endif /* __AUTOIP__ */

void pumpInitOverride(struct pumpOverrideInfo * override) {
    strcpy(override->intf.device, "MASTER");
    override->timeout = DEFAULT_TIMEOUT;
    override->numRetries = DEFAULT_NUM_RETRIES;
    override->script = NULL;
#ifdef __AUTOIP__
    override->autoip_lease_sec = AUTOIP_LEASE_SEC;
    override->clientId = NULL;
    override->scopeId = NULL;
#endif /* __AUTOIP__ */

#ifdef __TUNEUP__
    override->tscale = TSCALE;
    override->delayed_start = DELAYED_START;
#endif /* __TUNEUP__ */
}

/*
* If time(2) is used, changing the date on a system can cause
* pump to miss the lease renewal time.  The result is a system
* that doesn't seem to want to talk until it is rebooted!  We
* need elapsed time, NOT absolute (wall clock) time to measure
* the expiration of the lease.  Unfortunately I can't see any
* other interface to an unmolested elapsed time value other than
* /proc/uptime (and this is how uptime(1), top(1), w(1) use it).
* No matter, overhead is not an issue here, accuracy is.
* duanev@io.com 9/99
*/
time_t pumpUptime() {
    FILE * fd;
    long secs;
    static int first = 1;

    if ((fd = fopen("/proc/uptime", "r")) == NULL) {
	if (first) {
#ifndef __DISABLE_LOG_INFO__
	    syslog (LOG_INFO, "error opening /proc/uptime: %s", 
		    strerror(errno));
	    syslog (LOG_INFO, "warning: might miss lease renewal if date "
		    "changes");
#endif  /* !__DISABLE_LOG_INFO__ */
	    first = 0;
	}
	return time(NULL);
    }

    fscanf(fd, "%ld", &secs);
    fclose(fd);

    return (time_t)secs;
}
#ifdef __TUNEUP__
time_t pumpUptimeTuned(void){
    struct timeval tv;
    if(gettimeofday(&tv, NULL))
        return 0;
    return (time_t)tv.tv_sec;
}
#endif /* __TUNEUP__ */

#ifdef __SNSC_PATCH__
/******************************************************************************

******************************************************************************/
static u_int16_t checksum(const u_int16_t *data, int len, long init)
{
        long sum = init;
        for (; len > 1; len -=2){
                sum += *data++;
                if (sum & 0x80000000)
                        sum = (sum & 0xFFFF) + (sum >> 16);
        }
        if (len == 1){
                u_int16_t i = 0;
                *(u_int8_t*)(&i) = *(u_int8_t*)data;
                sum += i;
        }
        while (sum >> 16)
                sum = (sum & 0xFFFF) + (sum >> 16);

        return ~sum;
}
static void recalculateUdphdr(char *buf, u_int32_t len)
{
        struct udphdr *udp = 
                (struct udphdr*)(buf + ETH_ALEN*2 + 2 + sizeof(struct iphdr));
        int udplen = len - (ETH_ALEN*2 + 2 + sizeof(struct iphdr));
        long sum = 0;

        if (udplen < 0){
                return ;
        }

        /* udp virtual header checksum */
        sum += 0xFFFF + 0xFFFF;
        sum += htons(0x11);
        if (sum & 0x80000000) sum = (sum & 0xFFFF) + (sum >> 16);
        sum += htons(udplen);
        if (sum & 0x80000000) sum = (sum & 0xFFFF) + (sum >> 16);

        /* udp diff */
	udp->len = htons(udplen);
        udp->check = 0;
	udp->check = checksum((u_int16_t*)udp, udplen, sum);
        
}
static int make_ip_header4dhcp(int sock, char *interface, char *p, 
			       void *msg, u_int32_t msg_len, int flag)
{
        struct ifreq ifr;
        u_int32_t ethp_len = ETH_ALEN*2 + 2;
        u_int32_t udplen, iplen;
        long sum = 0;
        struct iphdr *ip = (struct iphdr*)(p + ethp_len);
        struct udphdr *udp = (struct udphdr*)((char *)ip + sizeof(struct iphdr));

        if (flag){
            udplen = sizeof(struct udphdr) + msg_len - 
	      (DHCP_VENDOR_LENGTH - BOOTP_VENDOR_LENGTH);
        }
        else {
	    udplen = sizeof(struct udphdr) + msg_len;
        }
        iplen = sizeof(struct iphdr) + udplen;

	memset(&ifr, 0, sizeof(ifr));
	strcpy(ifr.ifr_name, interface);
	if (ioctl(sock, SIOCGIFHWADDR, &ifr) == -1) {
                return 0;
	}

        memset((char*)ip, 0, ethp_len + iplen);

        /* msg */
        memcpy((char*)udp + sizeof(struct udphdr), msg, msg_len);

        /* udp virtual header checksum */
        sum += 0xFFFF + 0xFFFF;
        sum += htons(0x11);
        if (sum & 0x80000000) sum = (sum & 0xFFFF) + (sum >> 16);
        sum += htons(udplen);
        if (sum & 0x80000000) sum = (sum & 0xFFFF) + (sum >> 16);

        /* udp */
	udp->source = htons(BOOTP_CLIENT_PORT);//0x44
	udp->dest = htons(BOOTP_SERVER_PORT);//0x43
	udp->len = htons(udplen);
        udp->check = 0;
	udp->check = checksum((u_int16_t*)udp, udplen, sum);

        /* ip */
	ip->ihl = 5;
	ip->version = 4;
	ip->tos = 0;
	ip->tot_len = htons(iplen);
	ip->id = htons(0);
	ip->frag_off = htons(0x4000);//htons(0);
	ip->ttl = IPDEFTTL;//0x40
	ip->protocol = IPPROTO_UDP;//0x11
	ip->check = htons(0);
	ip->saddr = htonl(0);
	ip->daddr = htonl(0xFFFFFFFF);
        ip->check = checksum((u_int16_t*)ip, sizeof(struct iphdr), 0);

        /* ether */
        memset(p, 0xff, ETH_ALEN);
        memcpy(p + ETH_ALEN, ifr.ifr_hwaddr.sa_data, IFHWADDRLEN);
        *(u_int16_t*)(p + ETH_ALEN*2) = htons(0x800);

        return ethp_len + sizeof(struct iphdr) + sizeof(struct udphdr) + msg_len;
}
void
clear_raw(int sock)
{
	int result;
        char buf[1500];
        fd_set fds;
	struct timeval tv;

	/* 
	 * first, flush all received packets. 
	 *
         * raw-socket receives packets from all interfaces,
	 * while the socket is not binded to a interface
         */
	while(1){
		FD_ZERO(&fds);	
		FD_SET(sock, &fds);
		tv.tv_sec  = 0;
		tv.tv_usec = 0;

		DPRINT("select\n");
		result = select(FD_SETSIZE, &fds, NULL, NULL, &tv);
		if(result <= 0){
			break;
		}
		recv(sock, buf, sizeof(buf), 0);
	}
}
#endif /* __SNSC_PATCH__ */
