/* 
 * Copyright 2002-2003,2005-2008 Sony Corporation.
 *
 */

#ifndef H_NET
#define H_NET

#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <sys/time.h>

#define MAX_DNS_SERVERS		3
#define MAX_LOG_SERVERS		3
#define MAX_LPR_SERVERS		3
#define MAX_NTP_SERVERS		3
#define MAX_XFS_SERVERS		3
#define MAX_XDM_SERVERS		3

#define PUMP_INTFINFO_HAS_IP		(1 << 0)
#define PUMP_INTFINFO_HAS_NETMASK	(1 << 1)
#define PUMP_INTFINFO_HAS_BROADCAST	(1 << 2)
#define PUMP_INTFINFO_HAS_NETWORK	(1 << 3)
#define PUMP_INTFINFO_HAS_DEVICE	(1 << 4)
#define PUMP_INTFINFO_HAS_BOOTSERVER	(1 << 5)
#define PUMP_INTFINFO_HAS_BOOTFILE	(1 << 6)
#define PUMP_INTFINFO_HAS_LEASE		(1 << 7)
#define PUMP_INTFINFO_HAS_REQLEASE	(1 << 8)
#define PUMP_INTFINFO_HAS_NEXTSERVER	(1 << 9)
#define PUMP_INTFINFO_NEEDS_NEWLEASE	(1 << 10)
#define PUMP_INTFINFO_HAS_MTU           (1 << 11)
#define PUMP_INTFINFO_HAS_PTPADDR       (1 << 12)

#define PUMP_NETINFO_HAS_LOGSRVS	(1 << 15)
#define PUMP_NETINFO_HAS_LPRSRVS	(1 << 16)
#define PUMP_NETINFO_HAS_NTPSRVS	(1 << 17)
#define PUMP_NETINFO_HAS_XFNTSRVS	(1 << 18)
#define PUMP_NETINFO_HAS_XDMSRVS	(1 << 19)
#define PUMP_NETINFO_HAS_GATEWAY	(1 << 20)
#define PUMP_NETINFO_HAS_HOSTNAME	(1 << 21)
#define PUMP_NETINFO_HAS_DOMAIN		(1 << 22)
#define PUMP_NETINFO_HAS_DNS		(1 << 23)
#define PUMP_NETINFO_HAS_NISDOMAIN	(1 << 24)
#ifdef __AUTOIP__
#define PUMP_NETINFO_DO_UNLINK          (1 << 30)
#define PUMP_NETINFO_DO_AUTOIP          (1 << 31)
#endif /* __AUTOIP__ */

#define PUMP_FLAG_NODAEMON	(1 << 0)
#define PUMP_FLAG_NOCONFIG	(1 << 1)
#define PUMP_FLAG_FORCEHNLOOKUP	(1 << 2)
#define PUMP_FLAG_WINCLIENTID	(1 << 3)

#define PUMP_SCRIPT_NEWLEASE	1
#define PUMP_SCRIPT_RENEWAL	2
#define PUMP_SCRIPT_DOWN	3

#define PUMP_NEW_AUTOIP_ADDR	0
#define PUMP_OLD_AUTOIP_ADDR	1

/******************************************************************************/
#if defined(__AUTOIP__) && !defined(__TUNEUP__)
#error [ !!! Use NO_TUNEUP with NO_AUTOIP !!! ]
#endif

#ifdef __AUTOIP__
#define AUTOIP_ARP_REPEAT_TIME          10
#define AUTOIP_ARP_PROBES_TIME          3
#define AUTOIP_ARP_INTERVAL_SEC         2
#define AUTOIP_ARP_ANNOUNCE_INTERVAL_SEC 2
#define AUTOIP_RATE_LIMIT_INTERVAL_SEC  60
#define AUTOIP_LEASE_SEC_UNLINK         10

#if defined(__DTT__)
#define AUTOIP_CONFIG_FILE_PREFIX      "/tmp/dhcpd/dhclient.autoip"
#else  /*!defined(__DTT__)*/
#define AUTOIP_CONFIG_FILE_PREFIX      "/var/dhcpd/dhclient.autoip"
#endif /*!defined(__DTT__)*/

#ifndef AUTOIP_LEASE_SEC
#define AUTOIP_LEASE_SEC                300
#endif /* AUTOIP_LEASE_SEC */

#ifndef DEFAULT_NUM_RETRIES
#define DEFAULT_NUM_RETRIES	        5
#endif

#ifndef DEFAULT_TIMEOUT
#define DEFAULT_TIMEOUT 	        30
#endif

#endif /* __AUTOIP__ */

#ifdef __TUNEUP__
#ifndef TSCALE
#define TSCALE                          2
#endif /* TSCALE */

#ifndef DELAYED_START
#define DELAYED_START                   1
#endif /* DELAYED_START */
#endif /* __TUNEUP__ */

/* base directories */
#ifdef __DTV_US__
#define PUMP_CONF "/tmp/pump.conf"
#else /* ! defined(__DTV_US__) */
#define PUMP_CONF "/etc/pump.conf"
#endif  /* ! defined(__DTV_US__) */

/******************************************************************************/


/* all of these in_addr things are in network byte order! */
struct pumpNetIntf {
    char device[10];
#ifdef __SNSC_PATCH__
    unsigned int set;
#else /* __SNSC_PATCH__ */
    int set;
#endif /* __SNSC_PATCH__ */
    struct in_addr ip, netmask, broadcast, network;
    struct in_addr bootServer, nextServer;
    char * bootFile;
    time_t leaseExpiration, renewAt;
    int reqLease;		/* in seconds */
    char * hostname, * domain;		/* dynamically allocated */
    char * nisDomain;			/* dynamically allocated */
    struct in_addr gateway;
    struct in_addr logServers[MAX_LOG_SERVERS];
    struct in_addr lprServers[MAX_LPR_SERVERS];
    struct in_addr ntpServers[MAX_NTP_SERVERS];
    struct in_addr xfntServers[MAX_XFS_SERVERS];
    struct in_addr xdmServers[MAX_XDM_SERVERS];
    struct in_addr dnsServers[MAX_DNS_SERVERS];
    int numLog;
    int numLpr;
    int numNtp;
    int numXfs;
    int numXdm;
    int numDns;
    int flags;

    /* these don't really belong here, but anaconda's about the only thing 
     * that uses pump and this stuff is needed for the loader on s390 */
    int mtu;                    
    struct in_addr ptpaddr;             /* ptp address for ptp devs like ctc */
};

#define OVERRIDE_FLAG_NODNS		(1 << 0)
#define OVERRIDE_FLAG_NONISDOMAIN	(1 << 1)
#define OVERRIDE_FLAG_NOGATEWAY		(1 << 2)
#define OVERRIDE_FLAG_NOBOOTP           (1 << 3)
#ifdef __AUTOIP__
#define OVERRIDE_FLAG_LINKCHECK         (1 << 30)
#define OVERRIDE_FLAG_AUTOIP            (1 << 31)
#endif

struct pumpOverrideInfo {
    struct pumpNetIntf intf;
    char * searchPath;
    int flags;
    int numRetries;
    int timeout;
    char * script;
#ifdef __AUTOIP__
    int autoip_lease_sec;
    char * clientId;
    char * scopeId;
#endif /* __AUTOIP__ */
#ifdef __TUNEUP__
    int tscale;
    int delayed_start;
#endif /* __TUNEUP__ */
};

void pumpInitOverride(struct pumpOverrideInfo * override);
char * pumpDhcpRun(char * device, int flags, int lease,
		     char * reqHostname, struct pumpNetIntf * intf,
		     struct pumpOverrideInfo * override);

#ifdef __AUTOIP__
char * pumpAutoipRenew(char * device, int flags, int reqLease,
		     char * reqHostname, struct pumpNetIntf * intf,
		     struct pumpOverrideInfo * override);
char * pumpAutoipRun(char * device, int flags, int lease,
		     char * reqHostname, struct pumpNetIntf * intf,
		     struct pumpOverrideInfo * override, int useold);
char * pumpUnlinkRenew(char * device, struct pumpNetIntf * intf,
		       struct pumpOverrideInfo * override);
char * pumpUnlinkRun(char * device, struct pumpNetIntf * intf, 
		     struct pumpOverrideInfo * override);
int32_t pumpAutoipMiiTool(const char* ifname);
#endif /* __AUTOIP__ */

char * pumpSetupInterface(struct pumpNetIntf * intf);
/* setup an interface for sending a broadcast -- uses all 0's address */
char * pumpPrepareInterface(struct pumpNetIntf * intf, int s);
char * pumpDisableInterface(char * device);
int pumpDhcpRenew(struct pumpNetIntf * intf);
int pumpDhcpRelease(struct pumpNetIntf * intf);
int pumpSetupDefaultGateway(struct in_addr * gw);
time_t pumpUptime(void);

int createAutoipSocket(char* device);
int receive_and_judge_packet(char* device, int rawfd, int claimAddr);
void clear_raw(int sock);

#define RESULT_OKAY		0
#define RESULT_FAILED		1
#define RESULT_UNKNOWNIFACE	2

#ifdef  MERGE_RESOLV_CONF
#include "nnc_netparam.h"
#define PATH_RESOLV_CONF           NNC_PATH_IPV4_RESOLV_CONF
void merge_resolv_conf(void);
#else  /* !MERGE_RESOLV_CONF */
#define PATH_RESOLV_CONF           "/etc/resolv.conf"
#endif /* !MERGE_RESOLV_CONF */

#if defined(__SNSC_PATCH__) && defined(WLAN)
#define PUMP_WLAN_RBUF_SIZE    512
#define PUMP_WLAN_DEV_FILE     "/proc/net/wireless"
#endif

#endif
