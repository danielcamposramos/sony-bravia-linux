/* ========================================================================= *

			    Surface Pool using UXGfx

 * ========================================================================= */
/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrjala <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/

/*
  Copyright 2009-2010 Sony Corporation.

  This was initially based on the systems/x11 implementation.

  ChangeLog:

    - 2009/09/16
        * Ported on Sony DTV products.
 */

#include <direct/debug.h>
#include <direct/mem.h>
#include <core/surface_pool.h>
#include <gfx/convert.h>
#include <directfb_util.h>

#ifndef USE_SYSTEM_MEMORY_INSTEAD_OF_VRAM
# include <UxgTypes.h>
# include <UxgSysForC.h>
# define DTV_SURFACE_POOL_NAME "UXGfx"
#else
# define DTV_SURFACE_POOL_NAME "sysmem-UXGfx"
  typedef void UxgMemHdl_t;
  typedef uint32_t UxgUInt32;
#endif

D_DEBUG_DOMAIN(UXGfx_Pool, "UXGfx/Pool", "UXGfx Memory");

/* ========================================================================= */

typedef struct dtv_pool_data {
	int magic;
} dtv_pool_data_t;

typedef struct dtv_pool_local_data {
	int magic;
	CoreDFB *core;
} dtv_pool_local_data_t;

typedef struct dtv_allocation_data {
	int magic;
	UxgMemHdl_t *hdl;
} dtv_allocation_data_t;

/* ========================================================================= */

static int
dtv_pool_data_size()
{

	return sizeof(dtv_pool_data_t);
}

static int
dtv_pool_local_data_size()
{

	return sizeof(dtv_pool_local_data_t);
}

static int
dtv_allocation_data_size()
{

	return sizeof(dtv_allocation_data_t);
}

static DFBResult
dtv_init_pool(CoreDFB *core,
              CoreSurfacePool *pool,
              void *pool_data,
              void *pool_local,
              void *system_data,
              CoreSurfacePoolDescription *ret_desc)
{

	ret_desc->caps = CSPCAPS_NONE;
	ret_desc->access[CSAID_CPU] = CSAF_READ | CSAF_WRITE;
	ret_desc->access[CSAID_GPU] = CSAF_READ | CSAF_WRITE;
	ret_desc->types = CSTF_SHARED | CSTF_EXTERNAL;
	ret_desc->priority = CSPP_DEFAULT;

	ret_desc->access[CSAID_LAYER0] = CSAF_READ;
	ret_desc->access[CSAID_LAYER1] = CSAF_READ;
	ret_desc->access[CSAID_LAYER2] = CSAF_READ;
	ret_desc->access[CSAID_LAYER3] = CSAF_READ;
	ret_desc->access[CSAID_LAYER4] = CSAF_READ;
	ret_desc->access[CSAID_LAYER5] = CSAF_READ;
	ret_desc->access[CSAID_LAYER6] = CSAF_READ;
	ret_desc->access[CSAID_LAYER7] = CSAF_READ;

	snprintf(ret_desc->name,
		 DFB_SURFACE_POOL_DESC_NAME_LENGTH,
		 DTV_SURFACE_POOL_NAME);

	return DFB_OK;
}

static DFBResult
dtv_destroy_pool(CoreSurfacePool *pool,
                 void *pool_data,
                 void *pool_local)
{

	return DFB_OK;
}

static DFBResult
dtv_test_config(CoreSurfacePool *pool,
                void *pool_data,
                void *pool_local,
                CoreSurfaceBuffer *buffer,
                const CoreSurfaceConfig *config)
{

	if (config->caps & DSCAPS_VIDEOONLY) {
		return DFB_OK;
	} else {
		return DFB_FAILURE;
	}
}

static DFBResult
dtv_allocate_buffer(CoreSurfacePool *pool,
                    void *pool_data,
                    void *pool_local,
                    CoreSurfaceBuffer *buffer,
                    CoreSurfaceAllocation *allocation,
                    void *alloc_data)
{
	CoreSurface *surface;
	UxgUInt32 size;
	UxgMemHdl_t *hdl;
	dtv_allocation_data_t *data;

	surface = buffer->surface;
	size = surface->config.size.h
		* DFB_BYTES_PER_LINE(surface->config.format,
				     surface->config.size.w);

#ifdef USE_SYSTEM_MEMORY_INSTEAD_OF_VRAM
	hdl = (UxgMemHdl_t *)malloc(size);
#else
	hdl = UXGfxHeapManager_heapNew(size);
#endif
	if (!hdl) {
		return DFB_FAILURE;
	}

	allocation->size = (int)size;
	allocation->offset = 0;

	data = (dtv_allocation_data_t *)alloc_data;
	data->hdl = hdl;

	return DFB_OK;
}

static DFBResult
dtv_deallocate_buffer(CoreSurfacePool *pool,
                      void *pool_data,
                      void *pool_local,
                      CoreSurfaceBuffer *buffer,
                      CoreSurfaceAllocation *allocation,
                      void *alloc_data)
{
	dtv_allocation_data_t *data;

	data = (dtv_allocation_data_t *)alloc_data;

#ifdef USE_SYSTEM_MEMORY_INSTEAD_OF_VRAM
	free(data->hdl);
#else
	UXGfxHeapManager_heapDelete(data->hdl);
#endif

	return DFB_OK;
}

static DFBResult
dtv_lock(CoreSurfacePool *pool,
         void *pool_data,
         void *pool_local,
         CoreSurfaceAllocation *allocation,
         void *alloc_data,
         CoreSurfaceBufferLock *lock)
{
	CoreSurfaceConfig *config;
	dtv_allocation_data_t *data;
#ifndef USE_SYSTEM_MEMORY_INSTEAD_OF_VRAM
	UxgErr_t err;
#endif

	config = &allocation->surface->config;
	data = (dtv_allocation_data_t *)alloc_data;

	lock->pitch  = DFB_BYTES_PER_LINE(config->format, config->size.w);
#ifdef USE_SYSTEM_MEMORY_INSTEAD_OF_VRAM
	lock->addr   = (void *)data->hdl;
#else
	err = UXGfxHeapManager_lock(data->hdl);
	if (err) {
		D_ERROR("UXGfxHeapManager_lock(%p) failed! [%d]\n",
			data->hdl, err);
		return DFB_FAILURE;
	}
	lock->addr   = data->hdl->addr;
#endif
	lock->offset = 0;
	lock->phys   = 0;

	return DFB_OK;
}

static DFBResult
dtv_unlock(CoreSurfacePool *pool,
           void *pool_data,
           void *pool_local,
           CoreSurfaceAllocation *allocation,
           void *alloc_data,
           CoreSurfaceBufferLock *lock)
{
#ifdef USE_SYSTEM_MEMORY_INSTEAD_OF_VRAM
#else
	UxgErr_t err;
	dtv_allocation_data_t *data;

	data = (dtv_allocation_data_t *)alloc_data;

	err = UXGfxHeapManager_unlock(data->hdl);
	if (err) {
		D_ERROR("UXGfxHeapManager_unlock(%p) failed! [%d]\n",
			data->hdl, err);
		return DFB_FAILURE;
	}
#endif
	return DFB_OK;
}

const SurfacePoolFuncs dtv_surface_pool_funcs = {
	.PoolDataSize       = dtv_pool_data_size,
	.PoolLocalDataSize  = dtv_pool_local_data_size,
	.AllocationDataSize = dtv_allocation_data_size,
	.InitPool           = dtv_init_pool,
	.DestroyPool        = dtv_destroy_pool,

	.TestConfig         = dtv_test_config,

	.AllocateBuffer     = dtv_allocate_buffer,
	.DeallocateBuffer   = dtv_deallocate_buffer,

	.Lock               = dtv_lock,
	.Unlock             = dtv_unlock,
};

/* ===================================================================== EOF */
