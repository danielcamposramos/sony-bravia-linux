/* ========================================================================= *

 $Id: $
 * ========================================================================= */
/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrjala <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/

/*
  Copyright 2009-2010 Sony Corporation.

  This was initially based on the systems/x11 implementation.

  ChangeLog:

    - 2009/09/16
        * Ported on Sony DTV products.
 */

#include <stdio.h>
#include <stdint.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

#include <fusion/shmalloc.h>
#include <fusion/arena.h>

#include <directfb.h>
#include <core/core.h>
#include <core/screen.h>
#include <core/core_system.h>
#include <core/surface_pool.h>

#include "dtv.h"
#include "dtv_screen.h"
#include "dtv_layer.h"

DFB_CORE_SYSTEM(dtv)

extern const SurfacePoolFuncs dtv_surface_pool_funcs;

/* ----------------------------------------------------------------------------
 * helper functions
 */

/* ----------------------------------------------------------------------------
 * CoreSystemFuncs
 */

static void
system_get_info(CoreSystemInfo *info)
{

	info->type = CORE_ANY;
	info->caps = CSCAPS_ACCELERATION;

	snprintf(info->name,   DFB_CORE_SYSTEM_INFO_NAME_LENGTH, "DTV09");
	snprintf(info->vendor, DFB_CORE_SYSTEM_INFO_VENDOR_LENGTH,
		 "Sony Corporation.");
}

static DFBResult
system_initialize(CoreDFB *core, void **data)
{
	CoreScreen *screen;
	FusionSHMPoolShared *pool;
	dtv_shared_t *shared;

	/*
	 * construct dfb_nsg
	 */
	*data = dtv;	// this is position sensitive code!

	dtv->core = core;

	pool = dfb_core_shmpool(core);
	shared = SHCALLOC(pool, 1, sizeof(dtv_shared_t));
	if (shared == NULL) {
		return D_OOSHM();
	}

	dtv->shared = shared;

	/*
	 * initializations
	 */
	dfb_surface_pool_initialize(core,
				    &dtv_surface_pool_funcs,
				    &dtv->shared->pool);

	screen = dtv_screen_register();

	dtv_layer_register(screen);

	fusion_arena_add_shared_field(dfb_core_arena(core),
				      "dfb-dtv", shared);

	return DFB_OK;
}

static DFBResult
system_join(CoreDFB *core, void **data)
{
	DFBResult ret;
	void *ret_shared;

	/*
	 * construct dtv
	 */
	*data = dtv;	// this is position sensitive code!

	dtv->core = core;

	ret = fusion_arena_get_shared_field(dfb_core_arena(core),
					    "dfb-dtv", &ret_shared);
	if (ret) {
		return ret;
	}

	dtv->shared = ret_shared;

	dfb_surface_pool_join(dtv->core,
			      dtv->shared->pool,
			      &dtv_surface_pool_funcs);

	return DFB_OK;
}

static DFBResult
system_shutdown(bool emergency)
{
	FusionSHMPoolShared *shmpool;

	dfb_surface_pool_destroy(dtv->shared->pool);

	shmpool = dfb_core_shmpool(dtv->core);
	SHFREE(shmpool, dtv->shared);

	CLEAR_DTV(dtv);

	return DFB_OK;
}

static DFBResult
system_leave(bool emergency)
{

	dfb_surface_pool_leave(dtv->shared->pool);

	CLEAR_DTV(dtv);

	return DFB_OK;
}

static DFBResult
system_suspend()
{

	return DFB_UNIMPLEMENTED;
}

static DFBResult
system_resume()
{

	return DFB_UNIMPLEMENTED;
}

static volatile void *
system_map_mmio(unsigned int offset, int length)
{

	return NULL;
}

static void
system_unmap_mmio(volatile void  *addr, int length)
{

}

static int
system_get_accelerator()
{

	return 0;
}

static VideoMode *
system_get_modes()
{

	return NULL;
}

static VideoMode *
system_get_current_mode()
{

	return NULL;
}

static DFBResult
system_thread_init()
{

	return DFB_OK;
}

static bool
system_input_filter(CoreInputDevice *device, DFBInputEvent *event)
{

	return false;
}

static unsigned long
system_video_memory_physical(unsigned int offset)
{

	return 0;
}

static void *
system_video_memory_virtual(unsigned int offset)
{

	return NULL;
}

static unsigned int
system_videoram_length()
{

	return 0;
}

static unsigned long
system_aux_memory_physical(unsigned int offset)
{

	return 0;
}

static void *
system_aux_memory_virtual(unsigned int offset)
{

	return NULL;
}

static unsigned int
system_auxram_length()
{

	return 0;
}

static void
system_get_busid(int *ret_bus, int *ret_dev, int *ret_func)
{

	return;
}

static void
system_get_deviceid(unsigned int *ret_vendor_id, unsigned int *ret_device_id)
{

	return;
}

/* ===================================================================== EOF */
