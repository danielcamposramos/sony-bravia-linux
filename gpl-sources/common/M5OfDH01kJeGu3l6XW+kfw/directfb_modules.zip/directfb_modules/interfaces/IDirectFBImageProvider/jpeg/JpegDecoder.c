/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrj�Cl�C <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/


/*
   Copyright 2009-2010 Sony Corporation.
   
   This is IDirectFBImageProvider implementation based decoder to support devided decoding mode.
   
   ChangeLog:
      2010/01/21 IDirectFBImageProvider can decode png in streaming mode
*/

/* 
   Notice:
      This decoder is a sample implementation for modified IDirectFBImageProvider.
      This implementation can support only simple jpeg images. Grayscale images and 
      some complicated-format images can not be supported.
*/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdarg.h>

#include <directfb.h>

#include <display/idirectfbsurface.h>

#include <media/idirectfbimageprovider.h>

#include <core/coredefs.h>
#include <core/coretypes.h>

#include <core/layers.h>
#include <core/surface.h>

#include <misc/gfx_util.h>
#include <misc/util.h>
#include <direct/interface.h>
#include <direct/mem.h>
#include <direct/memcpy.h>
#include <direct/messages.h>

#include <setjmp.h>
#include <math.h>

#undef HAVE_STDLIB_H
#include "jpeglib.h"
#include "SonyDirectFB.h"
#include "SonyDFBJpegDecoder.h"

#define RET_OK 0
#define RET_NG 1
#define BUFFER_SIZE 4096

typedef struct{
	struct jpeg_decompress_struct cinfo;
	SonyDFBDecoderStatus status;		/*< decoder status */
	SonyDFBJpegRenderCallback renderCB;	/*< callback function for rendering*/
	SonyDFBImageData* userData1;		/*< user data*/
	SonyDFBJpegCallback callback;		/*< callback function for status notify */
	void* userData2;					/*< user data*/
}JPEGDecoder;

#define JPEG_PROG_BUF_SIZE    0x10000

typedef struct{
   struct jpeg_source_mgr  pub; /* public fields */

   JOCTET                  *data;       /* start of buffer */
   JSAMPARRAY buffer;
//   IDirectFBDataBuffer    *buffer;
//   JOCTET				   *buffer;
//   int					   size;
//   int                     peekonly;
//   int                     peekoffset;
} buffer_source_mgr;

typedef buffer_source_mgr * buffer_src_ptr;

static void
buffer_init_source (j_decompress_ptr cinfo)
{
}

static boolean
buffer_fill_input_buffer (j_decompress_ptr cinfo)
{
	return FALSE;
}

static void
buffer_fill_input_buffer_from_memory (j_decompress_ptr cinfo, unsigned char* pStream, int streamBytes)
{
	if (cinfo) {
		buffer_src_ptr src = (buffer_src_ptr) cinfo->src;
		if (src->pub.bytes_in_buffer <= 0 && streamBytes <= 0) {
		/* Insert a fake EOI marker */
			src->data[0] = (JOCTET) 0xFF;
			src->data[1] = (JOCTET) JPEG_EOI;
			src->pub.bytes_in_buffer = 2;
		}
		else {
			memmove(src->data, src->pub.next_input_byte, src->pub.bytes_in_buffer);
		}

		memcpy(src->data + src->pub.bytes_in_buffer, pStream, streamBytes);
		src->pub.next_input_byte = src->data;
		src->pub.bytes_in_buffer += streamBytes;
	}
}


static void
buffer_skip_input_data (j_decompress_ptr cinfo, long num_bytes)
{
	if (cinfo) {
		buffer_src_ptr src = (buffer_src_ptr) cinfo->src;
		if (src->pub.bytes_in_buffer < num_bytes) {
			src->pub.next_input_byte = 0;
			src->pub.bytes_in_buffer = 0;
		}
		else {
			src->pub.next_input_byte += num_bytes;
			src->pub.bytes_in_buffer -= num_bytes;
			if (src->pub.bytes_in_buffer <= 0) {
				src->pub.bytes_in_buffer = 0;
				src->pub.next_input_byte = 0;
			}
		}
	}
}

static void
buffer_term_source (j_decompress_ptr cinfo)
{
}

static void
jpeg_buffer_src (j_decompress_ptr cinfo)
{
	buffer_src_ptr src;
	if (cinfo) {
		cinfo->src = (struct jpeg_source_mgr *)
						cinfo->mem->alloc_small ((j_common_ptr) cinfo, JPOOL_PERMANENT,
						sizeof (buffer_source_mgr));

		src = (buffer_src_ptr) cinfo->src;

		src->data = (JOCTET *)
					cinfo->mem->alloc_small ((j_common_ptr) cinfo, JPOOL_PERMANENT,
												JPEG_PROG_BUF_SIZE * sizeof (JOCTET));
	}

	src->pub.init_source       = buffer_init_source;
	src->pub.fill_input_buffer = buffer_fill_input_buffer;
	src->pub.skip_input_data   = buffer_skip_input_data;
	src->pub.resync_to_restart = jpeg_resync_to_restart; /* use default method */
	src->pub.term_source       = buffer_term_source;
	src->pub.bytes_in_buffer   = 0; /* forces fill_input_buffer on first read */
	src->pub.next_input_byte   = NULL; /* until buffer loaded */
}

struct my_error_mgr{
	struct jpeg_error_mgr pub;     /* "public" fields */
	jmp_buf  setjmp_buffer;          /* for return to caller */
};

static void
jpeglib_panic(j_common_ptr cinfo)
{
	struct my_error_mgr *myerr = (struct my_error_mgr*) cinfo->err;
	(*cinfo->err->output_message)(cinfo);
	longjmp(myerr->setjmp_buffer, 1);
}

void *SonyDFB_createJpegDecoder(void){
	JPEGDecoder *decoder = (JPEGDecoder*)malloc(sizeof(JPEGDecoder));
	struct my_error_mgr jerr;

	if (!decoder) {
		return 0;
	}

	// set error handling
	decoder->cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = jpeglib_panic;

	if (setjmp(jerr.setjmp_buffer)) {
		jpeg_destroy_decompress(&decoder->cinfo);
		return 0;
	}

	// create jpeg_decompress_struct
	jpeg_create_decompress(&decoder->cinfo);
	jpeg_buffer_src(&decoder->cinfo);

	// change decoder status
	decoder->status = SonyDFBDecoderStatus_Initialized;

	return decoder;
}

int SonyDFB_releaseJpegDecoder(void **thiz)
{
	if (*thiz) {
		JPEGDecoder *decoder = (JPEGDecoder*)(*thiz);
	    jpeg_destroy_decompress(&decoder->cinfo);
		free(*thiz);
		return RET_OK;
	}
	else {
		return RET_NG;
	}
}

int SonyDFB_feedStreamJpegDecoder(void *thiz, unsigned char* pStream, int streamBytes){
	struct my_error_mgr jerr;
	JPEGDecoder *decoder;
	unsigned char *image;
	JSAMPROW outbuf;      /* Output row buffer */
	int row_stride;       /* physical row width in output buffer */
	unsigned int i;
	
	if (thiz) {
		decoder = (JPEGDecoder*)thiz;
	}
	else {
		return RET_NG;
	}

	// set error handling
	decoder->cinfo.err	= jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = jpeglib_panic;

	if (setjmp(jerr.setjmp_buffer)) {
        jpeg_destroy_decompress(&decoder->cinfo);
		return RET_NG;
	}

	// input next source data
	buffer_fill_input_buffer_from_memory(&decoder->cinfo, pStream, streamBytes);

	// start decoding
	while(TRUE) {
		switch(decoder->status) {
			case SonyDFBDecoderStatus_Initialized:
				if (jpeg_read_header(&decoder->cinfo, TRUE) != JPEG_SUSPENDED) {
				    jpeg_calc_output_dimensions(&decoder->cinfo);
					decoder->callback(decoder->userData2, SonyDFBDecoderStatus_Parsed);
					decoder->status = SonyDFBDecoderStatus_Parsed;
					if (!jpeg_start_decompress(&decoder->cinfo)) {
						return RET_NG;
					}
				    buffer_src_ptr src = (buffer_src_ptr) decoder->cinfo.src;
			        row_stride = decoder->cinfo.output_width * 3; // RGB
					src->buffer = (*decoder->cinfo.mem->alloc_sarray)((j_common_ptr) &decoder->cinfo, JPOOL_IMAGE, row_stride, 1);
				}
				else {
					return RET_OK;
				}
				break;
			case SonyDFBDecoderStatus_Parsed:
			case SonyDFBDecoderStatus_Decoding:
				while (decoder->cinfo.output_scanline < decoder->cinfo.output_height) {
				    buffer_src_ptr src = (buffer_src_ptr) decoder->cinfo.src;
					outbuf = src->buffer[0];
					if (jpeg_read_scanlines(&decoder->cinfo, src->buffer, 1) == 1) {
						decoder->status = SonyDFBDecoderStatus_Decoding;
						// set the pointer of destination
						image = (unsigned char*)((unsigned char*)(decoder->userData1->pDstData) + (decoder->cinfo.output_scanline - 1) * decoder->userData1->pitch);
						if (decoder->cinfo.out_color_components == 3) { //RGB
							// color format conversion(ARGB -> BGRA)
							for (i=0;i<decoder->cinfo.output_width;i++) {
								*image     = *(outbuf+2);  // B
								*(image+1) = *(outbuf+1);  // G
								*(image+2) = *(outbuf);    // R
								*(image+3) = 0xff;         // A
								image  += 4;
								outbuf += 3;
							}
						}
						else {
							return RET_NG;
						}
					}
					else {
						return RET_OK;
					}
				}
				if (decoder->cinfo.output_scanline == decoder->cinfo.output_height) {
					decoder->status = SonyDFBDecoderStatus_End;
				}
				break;
			case SonyDFBDecoderStatus_End:
				jpeg_finish_decompress(&decoder->cinfo);
				jpeg_destroy_decompress(&decoder->cinfo);
				return RET_OK;
			default:
				decoder->status = SonyDFBDecoderStatus_Error;
				return RET_NG;
		}
	}
}

int SonyDFB_setRenderCallbackJpegDecoder(void *thiz, const SonyDFBJpegRenderCallback callback, void* userData)
{
	if (thiz) {
		((JPEGDecoder*)thiz)->renderCB = callback;
		((JPEGDecoder*)thiz)->userData1 = userData;
		return RET_OK;
	}
	return RET_NG;
}

int SonyDFB_setNostifyFuncJpegDecoder(void* thiz, SonyDFBJpegCallback callback, void* userData)
{
	if (thiz) {
		((JPEGDecoder*)thiz)->callback = callback;
		((JPEGDecoder*)thiz)->userData2 = userData;
		return RET_OK;
	}
	return RET_NG;
}

int SonyDFB_getStructJpegDecoder(void* thiz, struct jpeg_decompress_struct *ptr)
{
	if (thiz) {
		*ptr = ((JPEGDecoder*)thiz)->cinfo;
		if (ptr) {
			return RET_OK;
		}
	}
	return RET_NG;
}

int SonyDFB_getStatusJpegDecoder(void* thiz)
{
	if (thiz) {
		return ((JPEGDecoder*)thiz)->status;
	}
	else {
		return SonyDFBDecoderStatus_Error;
	}
}

int SonyDFB_getImageSizeJpegDecoder(void *thiz, int *w, int *h)
{
	if (thiz) {
	    *w = ((JPEGDecoder*)thiz)->cinfo.output_width;
		*h = ((JPEGDecoder*)thiz)->cinfo.output_height;
		return RET_OK;
	}
	else {
		return RET_NG;
	}
}
