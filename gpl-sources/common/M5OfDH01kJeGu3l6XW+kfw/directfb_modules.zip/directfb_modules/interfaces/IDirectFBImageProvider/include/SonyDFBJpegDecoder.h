/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrj�Cl�C <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/


/* 
   Copyright 2009-2010 Sony Corporation.

   This is modified IDirectFBImageProvider to support devided decoding mode.
   
   ChangeLog:
      2010/01/30 Defining functions and structures for custimize 
                 IDirectFBImageProvider to devided decoding mode on Sony products
*/

#ifndef __SonyDFBJpegDecoder_H__
#define __SonyDFBJpegDecoder_H__

#ifdef __cplusplus
extern "C"
{
#endif

typedef void (*SonyDFBJpegCallback)(void *data, int status);
typedef int (*SonyDFBJpegRenderCallback)(void *rect, void *ctx);

void *SonyDFB_createJpegDecoder(void);
int SonyDFB_releaseJpegDecoder(void **thiz);
int SonyDFB_feedStreamJpegDecoder(void *thiz, unsigned char* pStream, int streamBytes);
int SonyDFB_setRenderCallbackJpegDecoder(void *thiz, const SonyDFBJpegRenderCallback callback, void* userData);
int SonyDFB_setNostifyFuncJpegDecoder(void* thiz, SonyDFBJpegCallback callback, void* userData);
int SonyDFB_getStructJpegDecoder(void* thiz, struct jpeg_decompress_struct *ptr);
int SonyDFB_getStatusJpegDecoder(void* thiz);
int SonyDFB_getImageSizeJpegDecoder(void *thiz, int *w, int *h);

#ifdef __cplusplus
}
#endif // __cplusplus

#endif
