/* 2010-12-13: File added and changed by Sony Corporation */
/*
 *  kernel/periodic_timer.c
 *
 *  Copyright 2008,2009,2010 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/slab.h>
#include <linux/list.h>
#include <linux/module.h>
#include <linux/spinlock.h>
#include <linux/periodic_timer.h>

struct periodic_timer_handle_body {
	struct list_head list;
	spinlock_t lock;
	void (*function)(periodic_timer_t*);
};

static ktime_t ktime_zero;

static enum hrtimer_restart periodic_timer_interrupt(struct hrtimer *hrt)
{
	periodic_timer_t *entry = container_of(hrt, periodic_timer_t, hrt);
	periodic_timer_handle_t handle = entry->handle;
	unsigned long flags;

	handle->function(entry);

	if (ktime_equal(entry->interval, ktime_zero)) {
		spin_lock_irqsave(&handle->lock, flags);
		list_del(&entry->list);
		spin_unlock_irqrestore(&handle->lock, flags);
		kfree(entry);
		return HRTIMER_NORESTART;
	} else {
		hrtimer_forward(hrt, hrt->base->get_time(), entry->interval);
		return HRTIMER_RESTART;
	}
}

periodic_timer_handle_t periodic_timer_create_handle(void (*function)
						     (periodic_timer_t*))
{
	periodic_timer_handle_t handle;

	if (function == NULL) {
		return NULL;
	}

	handle = kmalloc(sizeof(struct periodic_timer_handle_body), GFP_KERNEL);
	if (handle == NULL) {
		return NULL;
	}
	INIT_LIST_HEAD(&handle->list);
	spin_lock_init(&handle->lock);
	handle->function = function;

	return handle;
}
EXPORT_SYMBOL(periodic_timer_create_handle);

void periodic_timer_destroy_handle(periodic_timer_handle_t handle)
{
	struct list_head *ptr, *next;
	periodic_timer_t *ent;
	unsigned long flags;

	spin_lock_irqsave(&handle->lock, flags);
	list_for_each_safe(ptr, next, &handle->list) {
		ent = list_entry(ptr, periodic_timer_t, list);
		hrtimer_cancel(&ent->hrt);
		list_del(&ent->list);
		kfree(ent);
	}
	spin_unlock_irqrestore(&handle->lock, flags);

	kfree(handle);
}
EXPORT_SYMBOL(periodic_timer_destroy_handle);

periodic_timer_t* periodic_timer_add(periodic_timer_handle_t handle,
				     ktime_t start, ktime_t interval,
				     void *data)
{
	periodic_timer_t *timer;
	unsigned long flags;

	timer = kmalloc(sizeof(periodic_timer_t), GFP_ATOMIC);
	if (timer == NULL) {
		return NULL;
	}
	timer->start = start;
	timer->interval = interval;
	timer->data = data;
	timer->handle = handle;
	hrtimer_init(&timer->hrt, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
	timer->hrt.function = periodic_timer_interrupt;

	spin_lock_irqsave(&handle->lock, flags);
	list_add_tail(&timer->list, &handle->list);
	if (ktime_equal(start, ktime_zero)) {
		handle->function(timer);
		if (ktime_equal(interval, ktime_zero)) {
			list_del(&timer->list);
			kfree(timer);
		} else {
			hrtimer_start(&timer->hrt, interval, HRTIMER_MODE_REL);
		}
	} else {
		hrtimer_start(&timer->hrt, start, HRTIMER_MODE_REL);
	}
	spin_unlock_irqrestore(&handle->lock, flags);

	return timer;
}
EXPORT_SYMBOL(periodic_timer_add);

void periodic_timer_del(periodic_timer_handle_t handle,
			periodic_timer_t *timer)
{
	unsigned long flags;
	int ret;

	spin_lock_irqsave(&handle->lock, flags);
	ret = hrtimer_cancel(&timer->hrt);
	if (ret == 1 /* the timer was active */) {
		list_del(&timer->list);
		kfree(timer);
	}
	spin_unlock_irqrestore(&handle->lock, flags);
}
EXPORT_SYMBOL(periodic_timer_del);

static int __init periodic_timer_init(void)
{
	ktime_zero = ktime_set(0, 0);
	return 0;
}
subsys_initcall(periodic_timer_init);
