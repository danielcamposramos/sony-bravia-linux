/* 2010-06-16: File added by Sony Corporation */
/*
 *  Check memory contents at resume time
 *
 *  Copyright 2010 Sony Corporation.
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/pm.h>
#include <linux/mm.h>
#include <linux/mmzone.h>
#include <linux/pfn.h>
#include <linux/console.h>
#include <linux/crc32.h>
#include <asm/page.h>
#include <asm/sections.h>

/*
 * Following pm_printk related functions only use data structures on
 * the stack and don't pollute any kernel data pages.
 * We also assume that con->write will not pollute kernel data pages.
 *
 * These functions are implemented based on linux/kernel/printk.c.
 */

#define PRINTK_BUF_SIZE		128	/* 1 line is enough */

static void
pm_call_console_drivers(const char *buf, unsigned len)
{
	extern struct console *console_drivers;
	struct console *con;

	for (con = console_drivers; con; con = con->next) {
		if ((con->flags & CON_ENABLED) && con->write &&
				(cpu_online(raw_smp_processor_id()) ||
				(con->flags & CON_ANYTIME))) {
			con->write(con, buf, len);
		}
	}
}

static int
pm_vprintk(const char *fmt, va_list args)
{
	char printk_buf[PRINTK_BUF_SIZE];
	int printed_len;

	printed_len = vscnprintf(printk_buf, sizeof(printk_buf), fmt, args);
	pm_call_console_drivers(printk_buf, printed_len);

	return printed_len;
}

static int
pm_printk(const char *fmt, ...)
{
	va_list args;
	int r;

	va_start(args, fmt);
	r = pm_vprintk(fmt, args);
	va_end(args);

	return r;
}


#define HOTBOOT_CHKMEM_MAGIC	0x4d454d52
#define MAX_IGNORE_REGION	64

static struct {
	unsigned long pfn;
	unsigned long num_pages;
} ignore_region[MAX_IGNORE_REGION];

static u_int32_t *crc_buf_base =
	(u_int32_t *)CONFIG_SNSC_HOTBOOT_CHKMEM_CRC_BUFFER_BASE;

static int num_ignore_region = 0;
static int num_chk_pages = 0;
static int check_result = 0;

static inline void *
pfn_to_virt(unsigned long pfn)
{
	return phys_to_virt(PFN_PHYS(pfn));
}

static inline unsigned long
virt_to_pfn(void *virt)
{
	return PFN_DOWN(virt_to_phys(virt));
}

/* return true if pfn is smaller than kernel start address */
static inline int
pfn_is_below_stext(unsigned long pfn)
{
	return (pfn < PFN_DOWN(__pa(&_stext)));
}

/* return true if pfn is on 'current' stack pages */
static inline int
pfn_is_stack_page(unsigned long pfn)
{
	unsigned long start_pfn, end_pfn;

	start_pfn = virt_to_pfn(task_stack_page(current));
	end_pfn   = start_pfn + PFN_DOWN(THREAD_SIZE);

	return (start_pfn <= pfn && pfn < end_pfn);
}

static inline int
pfn_is_ignored(unsigned long pfn)
{
	unsigned long start_pfn, end_pfn;
	int i;

	for (i = 0; i < num_ignore_region; i++) {

		start_pfn = ignore_region[i].pfn;
		end_pfn   = start_pfn + ignore_region[i].num_pages;

		if (start_pfn <= pfn && pfn < end_pfn) {
			return 1;
		}
	}

	return 0;
}

static inline int
is_zone_to_check(struct zone *zone)
{
	if (is_highmem(zone) || !zone->spanned_pages) {
		return 0;
	}

	return 1;
}

#ifdef CONFIG_SNSC_HOTBOOT_CHKMEM_IGNORE_FREE_PAGE
static inline int pfn_is_free(unsigned long pfn);
#endif

static inline int
is_pfn_to_check(unsigned long pfn)
{
	if (!pfn_valid(pfn) || pfn_is_below_stext(pfn) ||
	    pfn_is_ignored(pfn) || pfn_is_stack_page(pfn)) {
		return 0;
	}

#ifdef CONFIG_SNSC_HOTBOOT_CHKMEM_IGNORE_FREE_PAGE
	if (pfn_is_free(pfn)) {
		return 0;
	}
#endif

	return 1;
}

#define for_each_zone_to_check(zone)				\
	for_each_zone(zone)					\
		if (is_zone_to_check(zone))

#define for_each_pfn_in_zone(zone, pfn)				\
	for (pfn = zone->zone_start_pfn;			\
	     pfn < zone->zone_start_pfn + zone->spanned_pages;	\
	     pfn++)

#define for_each_pfn_to_check(zone, pfn)			\
	for_each_zone_to_check(zone)				\
		for_each_pfn_in_zone(zone, pfn)			\
			if (is_pfn_to_check(pfn))


#ifdef CONFIG_SNSC_HOTBOOT_CHKMEM_IGNORE_FREE_PAGE
static inline int
pfn_is_free(unsigned long pfn)
{
	struct zone *zone;
	struct page *page;
	struct list_head *pos;
	unsigned long start_pfn, end_pfn;
	int order;
#ifdef CONFIG_PAGE_GROUP_BY_MOBILITY
	int type;
#endif

	for_each_zone_to_check(zone) {

#ifdef CONFIG_PAGE_GROUP_BY_MOBILITY
		for_each_migratetype_order(order, type) {
			list_for_each(pos,
				&zone->free_area[order].free_list[type]) {
#else
		for (order = MAX_ORDER - 1; order >= 0; --order) {
			list_for_each(pos, &zone->free_area[order].free_list) {
#endif
				page = list_entry(pos, struct page, lru);
				start_pfn = page_to_pfn(page);
				end_pfn   = start_pfn + (1 << order);
				if (start_pfn <= pfn && pfn < end_pfn) {
					return 1;
				}
			}
		}
	}

	return 0;
}
#endif

int
hotboot_chkmem_register_ignore(void *virt_addr, size_t len)
{
	unsigned long pfn, num_pages;

	/* check alignment */
	if (((unsigned long)virt_addr | len) & ~PAGE_MASK) {
		printk(KERN_WARNING "%s: invalid alignment 0x%08lx-0x%08lx\n",
		       __FUNCTION__, (unsigned long)virt_addr,
		       (unsigned long)virt_addr + len - 1);
		return -1;
	}

	if (num_ignore_region >= MAX_IGNORE_REGION) {
		printk(KERN_WARNING "%s: too many ignore regions\n",
		       __FUNCTION__);
		return -1;
	}

	pfn = virt_to_pfn(virt_addr);
	num_pages = PFN_DOWN(PFN_ALIGN(len));

	ignore_region[num_ignore_region].pfn = pfn;
	ignore_region[num_ignore_region].num_pages = num_pages;

#ifdef CONFIG_SNSC_HOTBOOT_CHKMEM_DEBUG
	printk(KERN_INFO "%s: 0x%08lx-0x%08lx will be ignored.\n",
	       __FUNCTION__, PFN_PHYS(pfn), PFN_PHYS(pfn + num_pages - 1) - 1);
#endif

	num_ignore_region++;

	return 0;
}

int
hotboot_chkmem_calculate_checksum(void)
{
	struct zone *zone;
	unsigned long pfn;
	u_int32_t *p;
	int prog, prev_prog;
	int n;

	pm_printk("calculating checksum for each memory pages...\n");

	p = crc_buf_base;
	prev_prog = -1;
	n = 0;

	num_chk_pages = 0;
	check_result = 0;

	for_each_pfn_to_check(zone, pfn) {
		num_chk_pages++;
	}

	pm_printk("%d pages to check.\n", num_chk_pages);

	*p++ = HOTBOOT_CHKMEM_MAGIC;
	*p++ = num_chk_pages;

	for_each_pfn_to_check(zone, pfn) {

		*p++ = crc32(0, pfn_to_virt(pfn), PAGE_SIZE);

		prog = ++n * 20 / num_chk_pages;
		if (prog != prev_prog) {
			pm_printk(".");
			prev_prog = prog;
		}
	}

	pm_printk("\ndone.\n");

	return 0;
}

int
hotboot_chkmem_check(void)
{
	struct zone *zone;
	unsigned long pfn;
	u_int32_t *p, crc;
	int prog, prev_prog;
	int n;

	p = crc_buf_base;
	prev_prog = -1;
	n = 0;

	pm_printk("checking checksum for each memory pages...\n");

	/* sanity check */
	if (*p++ != HOTBOOT_CHKMEM_MAGIC) {
		printk(KERN_WARNING "%s: invalid magic, check failed.\n",
		       __FUNCTION__);
		return -1;
	}
	if (*p++ != num_chk_pages) {
		printk(KERN_WARNING "%s: invalid num of pages, check faild.\n",
			__FUNCTION__);
		return -1;
	}

	pm_printk("%d pages to check.\n", num_chk_pages);

	for_each_pfn_to_check(zone, pfn) {

		crc = crc32(0, pfn_to_virt(pfn), PAGE_SIZE);

		if (*p != crc) {
			pm_printk("\n0x%08lx-0x%08lx: CRC mismatch !! "
				  "(0x%08x != 0x%08x)\n",
				  PFN_PHYS(pfn),
				  PFN_PHYS(pfn + 1) - 1, *p, crc);
			check_result = -1;
		}
		p++;

		prog = ++n * 20 / num_chk_pages;
		if (prog != prev_prog) {
			pm_printk(".");
			prev_prog = prog;
		}
	}

	pm_printk("\ndone, result: %s\n", (check_result == 0) ? "OK" : "NG");

	return check_result;
}

int
hotboot_chkmem_get_result(void)
{
	return check_result;
}

EXPORT_SYMBOL(hotboot_chkmem_get_result);
