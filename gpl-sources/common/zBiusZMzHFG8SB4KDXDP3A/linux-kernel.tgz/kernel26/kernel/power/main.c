/* 2009-07-26: File changed by Sony Corporation */
/*
 * kernel/power/main.c - PM subsystem core functionality.
 *
 * Copyright (c) 2003 Patrick Mochel
 * Copyright (c) 2003 Open Source Development Lab
 * 
 * This file is released under the GPLv2
 *
 */

#include <linux/module.h>
#include <linux/suspend.h>
#include <linux/kobject.h>
#include <linux/string.h>
#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/init.h>
#include <linux/console.h>
#include <linux/cpu.h>
#include <linux/resume-trace.h>
#include <linux/freezer.h>
#include <linux/vmstat.h>
#include <linux/device.h>
#include <linux/snsc_boot_time.h>

#ifdef	CONFIG_SNSC_SAFE_SUSPEND
extern int suspend_remount(void);
extern int resume_remount(void);
#endif

#ifdef CONFIG_SNSC_DEFERRED_RESUME
#include <linux/kthread.h>
#endif
#ifdef CONFIG_SNSC_SSBOOT
#include <linux/ssboot.h>
#endif

#include "power.h"

BLOCKING_NOTIFIER_HEAD(pm_chain_head);

DEFINE_MUTEX(pm_mutex);

unsigned int pm_flags;
EXPORT_SYMBOL(pm_flags);

#ifdef CONFIG_SUSPEND

/* This is just an arbitrary number */
#define FREE_PAGE_NUMBER (100)

struct pm_ops *pm_ops;

/**
 *	pm_set_ops - Set the global power method table. 
 *	@ops:	Pointer to ops structure.
 */

void pm_set_ops(struct pm_ops * ops)
{
	mutex_lock(&pm_mutex);
	pm_ops = ops;
	mutex_unlock(&pm_mutex);
}

/**
 * pm_valid_only_mem - generic memory-only valid callback
 *
 * pm_ops drivers that implement mem suspend only and only need
 * to check for that in their .valid callback can use this instead
 * of rolling their own .valid callback.
 */
int pm_valid_only_mem(suspend_state_t state)
{
	return state == PM_SUSPEND_MEM;
}


static inline void pm_finish(suspend_state_t state)
{
	if (pm_ops->finish)
		pm_ops->finish(state);
}

/**
 *	suspend_prepare - Do prep work before entering low-power state.
 *
 *	This is common code that is called for each state that we're entering.
 *	Run suspend notifiers, allocate a console and stop all processes.
 */
#ifdef CONFIG_SNSC_SSBOOT
static int suspend_prepare(suspend_state_t state)
#else
static int suspend_prepare(void)
#endif
{
	int error;
	unsigned int free_pages;

	if (!pm_ops || !pm_ops->enter)
		return -EPERM;

	error = pm_notifier_call_chain(PM_SUSPEND_PREPARE);
	if (error)
		goto Finish;

	pm_prepare_console();

#ifdef CONFIG_SNSC_SSBOOT
	if (state == PM_SUSPEND_SNAPSHOT) {
		if (freeze_tasks(FREEZER_USER_SPACE)) {
			error = -EAGAIN;
			goto Thaw;
		}
		error = ssboot_prepare();
		if (error) {
			goto Thaw;
		}
		if (freeze_tasks(FREEZER_KERNEL_THREADS)) {
			error = -EAGAIN;
			goto Thaw;
		}
	} else
#endif
	if (freeze_processes()) {
		error = -EAGAIN;
		goto Thaw;
	}

	free_pages = global_page_state(NR_FREE_PAGES);
	if (free_pages < FREE_PAGE_NUMBER) {
		pr_debug("PM: free some memory\n");
		shrink_all_memory(FREE_PAGE_NUMBER - free_pages);
		if (nr_free_pages() < FREE_PAGE_NUMBER) {
			error = -ENOMEM;
			printk(KERN_ERR "PM: No enough memory\n");
		}
	}
	if (!error) {
#ifdef	CONFIG_SNSC_SAFE_SUSPEND
		(void) suspend_remount();
#endif
		return 0;
	}

 Thaw:
	thaw_processes();
	pm_restore_console();
 Finish:
	pm_notifier_call_chain(PM_POST_SUSPEND);
	return error;
}

/* default implementation */
void __attribute__ ((weak)) arch_suspend_disable_irqs(void)
{
	local_irq_disable();
}

/* default implementation */
void __attribute__ ((weak)) arch_suspend_enable_irqs(void)
{
	local_irq_enable();
}

/**
 *	suspend_enter - enter the desired system sleep state.
 *	@state:		state to enter
 *
 *	This function should be called after devices have been suspended.
 */
int suspend_enter(suspend_state_t state)
{
	int error = 0;

	arch_suspend_disable_irqs();
	BUG_ON(!irqs_disabled());

	if ((error = device_power_down(PMSG_SUSPEND))) {
		printk(KERN_ERR "Some devices failed to power down\n");
		goto Done;
	}
	BOOT_TIME_ADD1("PM: suspend enter");
	error = pm_ops->enter(state);
#ifdef CONFIG_SNSC_BOOT_TIME
	boot_time_resume();
#endif
	BOOT_TIME_ADD1("PM: resume start");
	device_power_up();
	BOOT_TIME_ADD1("PM: device resumed(noirq)");
 Done:
	arch_suspend_enable_irqs();
	BUG_ON(irqs_disabled());
	return error;
}

/**
 *	suspend_devices_and_enter - suspend devices and enter the desired system sleep
 *			  state.
 *	@state:		  state to enter
 */
int suspend_devices_and_enter(suspend_state_t state)
{
	int error;

	if (!pm_ops)
		return -ENOSYS;

	if (pm_ops->set_target) {
		error = pm_ops->set_target(state);
		if (error)
			return error;
	}
	suspend_console();
	error = device_suspend(PMSG_SUSPEND);
	if (error) {
		printk(KERN_ERR "Some devices failed to suspend\n");
		goto Resume_console;
	}
	if (pm_ops->prepare) {
		error = pm_ops->prepare(state);
		if (error)
			goto Resume_devices;
	}
	error = disable_nonboot_cpus();
	if (!error)
#ifdef CONFIG_SNSC_SSBOOT
		error = suspend_enter(state);
#else
		suspend_enter(state);
#endif

	enable_nonboot_cpus();
	pm_finish(state);
 Resume_devices:
	device_resume();
	BOOT_TIME_ADD1("PM: device resumed");
 Resume_console:
	resume_console();

#ifdef CONFIG_SNSC_SSBOOT
	if (state == PM_SUSPEND_SNAPSHOT) {
		int ret;
		if (!error && ssboot_is_writing()) {
#ifdef CONFIG_SNSC_SAFE_SUSPEND
			resume_remount();
#endif
			thaw_tasks(FREEZER_KERNEL_THREADS);
			error = ssboot_write();
		}
		ret = ssboot_finish();
		if (!error) {
			error = ret;
		}
	}
#endif
	return error;
}

/**
 *	suspend_finish - Do final work before exiting suspend sequence.
 *
 *	Call platform code to clean up, restart processes, and free the 
 *	console that we've allocated. This is not called for suspend-to-disk.
 */
static void suspend_finish(void)
{
#ifdef	CONFIG_SNSC_SAFE_SUSPEND
	(void) resume_remount();
#endif
	thaw_processes();
	pm_restore_console();
	pm_notifier_call_chain(PM_POST_SUSPEND);
}




static const char * const pm_states[PM_SUSPEND_MAX] = {
	[PM_SUSPEND_STANDBY]	= "standby",
	[PM_SUSPEND_MEM]	= "mem",
#ifdef CONFIG_SNSC_SSBOOT
	[PM_SUSPEND_SNAPSHOT]	= "snapshot",
#endif
};

static inline int valid_state(suspend_state_t state)
{
	/* All states need lowlevel support and need to be valid
	 * to the lowlevel implementation, no valid callback
	 * implies that none are valid. */
	if (!pm_ops || !pm_ops->valid || !pm_ops->valid(state))
		return 0;
	return 1;
}

#ifdef CONFIG_SNSC_DEFERRED_RESUME

#include <linux/completion.h>

static DECLARE_COMPLETION(resume_thread_wakeup);

static struct task_struct *resume_thread_tsk = 0;
static int enable_deferred_resume = 0;
static u32 resume_state;

#endif /* CONFIG_SNSC_DEFERRED_RESUME */

/**
 *	enter_state - Do common work of entering low-power state.
 *	@state:		pm_state structure for state we're entering.
 *
 *	Make sure we're the only ones trying to enter a sleep state. Fail
 *	if someone has beat us to it, since we don't want anything weird to
 *	happen when we wake up.
 *	Then, do the setup for suspend, enter the state, and cleaup (after
 *	we've woken up).
 */
static int enter_state(suspend_state_t state)
{
	int error;

	if (!valid_state(state))
		return -ENODEV;
	if (!mutex_trylock(&pm_mutex))
		return -EBUSY;

	pr_debug("PM: Preparing system for %s sleep\n", pm_states[state]);
#ifdef CONFIG_SNSC_SSBOOT
	if ((error = suspend_prepare(state)))
#else
	if ((error = suspend_prepare()))
#endif
		goto Unlock;

	pr_debug("PM: Entering %s sleep\n", pm_states[state]);
	error = suspend_devices_and_enter(state);

#ifdef CONFIG_SNSC_DEFERRED_RESUME

	if (enable_deferred_resume && resume_thread_tsk) {
		if (!error) {
			extern void  thaw_process_group(int pgid);

			device_resume();

			/* wake up related threads */
			thaw_process_group(process_group(current));
			printk("woke up minimal threads\n");

			/* wake up resume thread */
			resume_state=state;
			smp_wmb();
			complete(&resume_thread_wakeup);

			pr_debug("PM: Return without finishing up.\n");
			printk("Return without finishing up\n");

			return 0;
		}
	}
#endif /* CONFIG_SNSC_DEFERRED_RESUME */

	pr_debug("PM: Finishing wakeup.\n");
	suspend_finish();
	BOOT_TIME_ADD1("PM: resume finished");
 Unlock:
	mutex_unlock(&pm_mutex);
	return error;
}


#ifdef CONFIG_SNSC_DEFERRED_RESUME
static int resume_thread(void *state_p)
{
	struct k_sigaction sa;
	sigset_t blocked;

	/* resume-thread is not freezable */
	current->flags |= PF_NOFREEZE;

	/* set scheduling params. */
	set_user_nice(current, 10);

	/* Block and flush all signals */
	sigfillset(&blocked);
	sigprocmask(SIG_BLOCK, &blocked, NULL);
	flush_signals(current);

	/* SIG_IGN makes children autoreap: see do_notify_parent(). */
	sa.sa.sa_handler = SIG_IGN;
	sa.sa.sa_flags = 0;
	siginitset(&sa.sa.sa_mask, sigmask(SIGCHLD));
	do_sigaction(SIGCHLD, &sa, (struct k_sigaction *)0);

	pr_debug("init\n");

	set_current_state(TASK_INTERRUPTIBLE);
	while (!kthread_should_stop()) {

		__set_current_state(TASK_RUNNING);

		pr_debug("waiting completion\n");

		wait_for_completion (&resume_thread_wakeup); /* wait until resume */
		printk("begin deferred finishing up\n");

		pr_debug("PM(deferred): Finishing up.\n");
		suspend_finish();

		printk("end deferred finishing up\n");

		mutex_unlock(&pm_mutex);

		set_current_state(TASK_INTERRUPTIBLE);
	}
	__set_current_state(TASK_RUNNING);

	pr_debug("end\n");

	resume_thread_tsk = 0;
	enable_deferred_resume = 0;
	mb();
	return 0;
}

int __init resume_thread_init(void)
{
	struct task_struct *p = 0;
	p = kthread_create(resume_thread, &resume_state, "kresume");
	if (IS_ERR(p)) {
		resume_thread_tsk = NULL;
	}
	else {
		resume_thread_tsk = p;
		wake_up_process(resume_thread_tsk);
	}
	return 0;
}

__initcall(resume_thread_init);

#endif /* CONFIG_SNSC_DEFERRED_RESUME */

/**
 *	pm_suspend - Externally visible function for suspending system.
 *	@state:		Enumerated value of state to enter.
 *
 *	Determine whether or not value is within range, get state 
 *	structure, and enter (above).
 */

int pm_suspend(suspend_state_t state)
{
	if (state > PM_SUSPEND_ON && state <= PM_SUSPEND_MAX)
		return enter_state(state);
	return -EINVAL;
}

EXPORT_SYMBOL(pm_suspend);

#endif /* CONFIG_SUSPEND */

decl_subsys(power,NULL,NULL);


/**
 *	state - control system power state.
 *
 *	show() returns what states are supported, which is hard-coded to
 *	'standby' (Power-On Suspend), 'mem' (Suspend-to-RAM), and
 *	'disk' (Suspend-to-Disk).
 *
 *	store() accepts one of those strings, translates it into the 
 *	proper enumerated value, and initiates a suspend transition.
 */

static ssize_t state_show(struct kset *kset, char *buf)
{
	char *s = buf;
#ifdef CONFIG_SUSPEND
	int i;

	for (i = 0; i < PM_SUSPEND_MAX; i++) {
		if (pm_states[i] && valid_state(i))
			s += sprintf(s,"%s ", pm_states[i]);
	}
#endif
#ifdef CONFIG_HIBERNATION
	s += sprintf(s, "%s\n", "disk");
#else
	if (s != buf)
		/* convert the last space to a newline */
		*(s-1) = '\n';
#endif
	return (s - buf);
}

static ssize_t state_store(struct kset *kset, const char *buf, size_t n)
{
#ifdef CONFIG_SUSPEND
	suspend_state_t state = PM_SUSPEND_STANDBY;
	const char * const *s;
#endif
	char *p;
	int len;
	int error = -EINVAL;

	p = memchr(buf, '\n', n);
	len = p ? p - buf : n;

#ifdef CONFIG_HIBERNATION
	/* First, check if we are requested to hibernate */
	if (len == 4 && !strncmp(buf, "disk", len)) {
		error = hibernate();
  goto Exit;
	}
#endif

#ifdef CONFIG_SUSPEND
	for (s = &pm_states[state]; state < PM_SUSPEND_MAX; s++, state++) {
		if (*s && len == strlen(*s) && !strncmp(buf, *s, len))
			break;
	}
	if (state < PM_SUSPEND_MAX && *s)
		error = enter_state(state);
#endif

#ifdef CONFIG_HIBERNATION
 Exit:
#endif
	return error ? error : n;
}

power_attr(state);

#ifdef CONFIG_SNSC_FAST_CLEAN_SHUTDOWN

#include <linux/reboot.h>
#include <linux/fs.h>

extern void tcp_shutdown_all(void);

void fast_clean_shutdown(void)
{
	(void)freeze_processes();
	(void)suspend_remount();
	tcp_shutdown_all();
	device_shutdown(); /* try to flush cache on device side */
	machine_power_off();

	panic("fast_shutdown: can't power off\n");

	/* NOTREACHED */

}

static ssize_t fast_clean_shutdown_show(struct kset * subsys, char * buf)
{
	return sprintf(buf,"enabled\n");
}

static ssize_t fast_clean_shutdown_store(struct kset * subsys, const char * buf,
				  size_t n)
{
	if (n > 2)
		return -EINVAL;
	if ((n == 2) && (buf[1] != '\n'))
		return -EINVAL;
	if (!(buf[0] == '1' || buf[0] == 'y'))
		return -EINVAL;

	fast_clean_shutdown();
	return n;
}

power_attr(fast_clean_shutdown);

#endif /* CONFIG_SNSC_FAST_CLEAN_SHUTDOWN */

#ifdef CONFIG_SNSC_DEFERRED_RESUME

char * deferred_resume_states[] = {
	"disable",
	"enable",
	NULL
};


static ssize_t deferred_resume_show(struct kset * subsys, char * buf)
{
	char * s = buf;

	s += sprintf(s, deferred_resume_states[enable_deferred_resume]);
	s += sprintf(s, "\n");
	return (s - buf);
}

static ssize_t deferred_resume_store(struct kset * subsys, const char * buf, size_t n)
{
	char ** s;
	char *p;
	int len;
	int i;

	p = memchr(buf, '\n', n);
	len = p ? p - buf : n;

	i = 0;
	s = &deferred_resume_states[0];
	while (*s) {
		if (!strncmp(buf, *s, len))
			break;
		s++; i++;
	}

	if (!*s) {
		return -EINVAL;
	}

	if (resume_thread_tsk)
		enable_deferred_resume = i;
	return n;
}

power_attr(deferred_resume);

#endif /* CONFIG_SNSC_DEFERRED_RESUME */

#ifdef CONFIG_PM_TRACE
int pm_trace_enabled;

static ssize_t pm_trace_show(struct kset *kset, char *buf)
{
	return sprintf(buf, "%d\n", pm_trace_enabled);
}

static ssize_t
pm_trace_store(struct kset *kset, const char *buf, size_t n)
{
	int val;

	if (sscanf(buf, "%d", &val) == 1) {
		pm_trace_enabled = !!val;
		return n;
	}
	return -EINVAL;
}

power_attr(pm_trace);

static struct attribute * g[] = {
	&state_attr.attr,
	&pm_trace_attr.attr,
#ifdef CONFIG_SNSC_FAST_CLEAN_SHUTDOWN
	&fast_clean_shutdown_attr.attr,
#endif
#ifdef CONFIG_SNSC_DEFERRED_RESUME
	&deferred_resume_attr.attr,
#endif /* CONFIG_SNSC_DEFERRED_RESUME */
	NULL,
};
#else
static struct attribute * g[] = {
	&state_attr.attr,
#ifdef CONFIG_SNSC_FAST_CLEAN_SHUTDOWN
	&fast_clean_shutdown_attr.attr,
#endif
#ifdef CONFIG_SNSC_DEFERRED_RESUME
	&deferred_resume_attr.attr,
#endif /* CONFIG_SNSC_DEFERRED_RESUME */
	NULL,
};
#endif /* CONFIG_PM_TRACE */

static struct attribute_group attr_group = {
	.attrs = g,
};


static int __init pm_init(void)
{
	int error = subsystem_register(&power_subsys);
	if (!error)
		error = sysfs_create_group(&power_subsys.kobj,&attr_group);
	return error;
}

core_initcall(pm_init);
