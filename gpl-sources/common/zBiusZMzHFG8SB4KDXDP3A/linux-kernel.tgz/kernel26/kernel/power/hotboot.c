/* 2009-06-19: File added by Sony Corporation */
/*
 *  HotBoot support
 *
 *  Copyright 2009 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/crc32.h>
#include <linux/pm.h>
#include <linux/hotboot.h>

struct resume_desc {
	u_int32_t magic;
	u_int16_t version;
	u_int16_t len;
	u_int32_t entry_addr;
	u_int32_t crc;
};

int
hotboot_create_resume_desc(void *entry_addr)
{
	struct resume_desc *desc;

	desc = (struct resume_desc *)CONFIG_SNSC_HOTBOOT_RESUME_DESC_BASE;

	memset(desc, 0, sizeof(struct resume_desc));

	desc->magic      = SNSC_HOTBOOT_RESUME_DESC_MAGIC;
	desc->version    = SNSC_HOTBOOT_RESUME_DESC_VERSION;
	desc->len        = sizeof(struct resume_desc);
	desc->entry_addr = (u_int32_t)entry_addr;
	desc->crc = crc32(0, desc, sizeof(struct resume_desc));

	return 0;
}

