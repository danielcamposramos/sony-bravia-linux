/* 2010-07-26: File added by Sony Corporation */
/*
 *  arch/mips/ayu/common/spaces.c
 *
 *  Copyright 2010 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/init.h>
#include <linux/types.h>
#include <linux/module.h>
#include <asm/ayu.h>
#include <asm/addrspace.h>

#define AYU_MBUS_WIN0_START		0x40000000
#ifdef CONFIG_AYU_HADW
#define AYU_MBUS_WIN0_END		0x41000000
#define AYU_MBUS_WIN1_START		hadw_win1_dbase
#define AYU_PHYS_WIN1_START		hadw_win1_sbase
#endif
#ifdef CONFIG_AYUBRD_UMEM
#define AYU_MBUS_UMEM_START		umem_addr
#define AYU_MBUS_UMEM_END		(umem_addr + umem_size)
#endif

unsigned long ayu_phys_to_mbus(unsigned long phys)
{
	if (phys >= AYU_VPCBUS_BASE) {
		return phys;
	}
#ifdef CONFIG_AYU_HADW
	if (phys >= AYU_PHYS_WIN1_START) {
		return (phys - AYU_PHYS_WIN1_START
			     + AYU_MBUS_WIN1_START);
	}
#endif
	return (phys + AYU_MBUS_WIN0_START);
}
EXPORT_SYMBOL(ayu_phys_to_mbus);

unsigned long ayu_mbus_to_phys(unsigned long mbus)
{
#ifdef CONFIG_AYUBRD_UMEM
	if (mbus >= AYU_MBUS_UMEM_START && mbus < AYU_MBUS_UMEM_END) {
		return mbus;
	}
#endif
#ifdef CONFIG_AYU_HADW
	if (mbus >= AYU_MBUS_WIN1_START) {
		return (mbus - AYU_MBUS_WIN1_START
			     + AYU_PHYS_WIN1_START);
	}
	if (mbus >= AYU_MBUS_WIN0_END) {
		return mbus;
	}
#endif
	if (mbus >= AYU_MBUS_WIN0_START) {
		return (mbus - AYU_MBUS_WIN0_START);
	}
	return mbus;
}
EXPORT_SYMBOL(ayu_mbus_to_phys);

unsigned long ayu_virt_to_phys(volatile const void *pvirt)
{
	unsigned long virt = (unsigned long)pvirt;

#ifdef CONFIG_SNSC_UMA
	if (virt >= AYU_VIRT_UMA_UNCAC_MAPBASE) {
		return (virt - AYU_VIRT_UMA_UNCAC_MAPBASE
			     + AYU_PHYS_UMA_MAPBASE);
	}
	if (virt >= AYU_VIRT_UMA_CAC_MAPBASE) {
		return (virt - AYU_VIRT_UMA_CAC_MAPBASE
			     + AYU_PHYS_UMA_MAPBASE);
	}
#endif
	return CPHYSADDR(virt);
}
EXPORT_SYMBOL(ayu_virt_to_phys);

void* ayu_phys_to_virt(unsigned long phys)
{
#ifdef CONFIG_SNSC_UMA
	if (phys >= AYU_PHYS_UMA_MAPBASE) {
		return (void *)(phys - AYU_PHYS_UMA_MAPBASE
				     + AYU_VIRT_UMA_CAC_MAPBASE);
	}
#endif
	return (void *)KSEG0ADDR(phys);
}
EXPORT_SYMBOL(ayu_phys_to_virt);
