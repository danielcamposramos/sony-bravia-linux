/* 2010-07-26: File added and changed by Sony Corporation */
/*
 *  arch/mips/ayu/ayubrd/setup.c
 *
 *  Copyright 2009,2010 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/init.h>
#include <linux/types.h>
#include <linux/pm.h>
#include <asm/bootinfo.h>
#include <asm/reboot.h>
#include <asm/sizes.h>
#include <asm/ayu.h>

const char*
get_system_type(void)
{
	return "Sony Ayubrd";
}

static void __init
ayubrd_setup(void)
{
	char* size;
	unsigned long ramsize, kern_ramsize;

	mips_machtype = MACH_SONY_AYUBRD;

	/*
	 * Since __setup() or parse_early_param() is called after
	 * plat_mem_setup(), ramsize should be updated here.
	 */
	size = strstr(arcs_cmdline, "ramsize=");
	if (size) {
		size += 8;
		ramsize = memparse(size, &size);

		if (ramsize < (256 << 20)) {
			ramsize = 256 << 20;
		}
	} else {
		ramsize = *(unsigned long *)AYU_BDI_RAMSIZE;
	}

	if (ramsize > (256 << 20)) {
		kern_ramsize = 256 << 20;
	} else {
		kern_ramsize = ramsize;
	}

#ifdef CONFIG_AYUBRD_UMEM
	ayubrd_umem_init(ramsize, kern_ramsize);
#else
	add_memory_region(0, kern_ramsize, BOOT_MEM_RAM);
#endif

#ifdef CONFIG_SNSC_UMA
	ayubrd_uma_init(ramsize);
#endif
}

void __init
plat_mem_setup(void)
{
	ayu_setup_common();
	ayubrd_setup();

	_machine_restart = ayu_machine_restart;
	_machine_halt    = ayu_machine_halt;
	pm_power_off     = ayu_machine_power_off;

#ifndef CONFIG_SNSC_PANIC_TIMEOUT
	panic_timeout = 180;
#endif
}
