/* 2010-07-26: File added and changed by Sony Corporation */
/*
 *  arch/mips/ayu/common/irq_pcb.c
 *
 *  Copyright 2009 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/module.h>
#include <linux/types.h>
#include <linux/interrupt.h>
#ifdef CONFIG_PM
#include <linux/pm.h>
#include <linux/sysdev.h>
#endif
#include <asm/ayu.h>

static unsigned int pcb_irq_base;
static unsigned int pcb_irq_enabled = 0;
static unsigned int pcb_irq_masked = 0;
static DEFINE_SPINLOCK(pcb_irq_lock);

#define IRQ_TO_INT(irq)		(irq - pcb_irq_base)

static void
mask_pcb_irqs(void)
{
	clear_c0_status(STATUSF_IP3);
	irq_disable_hazard();
}

static void
unmask_pcb_irqs(void)
{
	set_c0_status(STATUSF_IP3);
	irq_enable_hazard();
}

static unsigned int
ayu_pcb_irq_startup(unsigned int irq)
{
	unsigned long flags;

	spin_lock_irqsave(&pcb_irq_lock, flags);
	if (!pcb_irq_enabled && !pcb_irq_masked) {
		unmask_pcb_irqs();
	}
	pcb_irq_enabled |= 1 << IRQ_TO_INT(irq);
	spin_unlock_irqrestore(&pcb_irq_lock, flags);

	return 0;
}

static void
ayu_pcb_irq_shutdown(unsigned int irq)
{
	unsigned long flags;

	spin_lock_irqsave(&pcb_irq_lock, flags);
	pcb_irq_enabled &= ~(1 << IRQ_TO_INT(irq));
	if (!pcb_irq_enabled && !pcb_irq_masked) {
		mask_pcb_irqs();
	}
	spin_unlock_irqrestore(&pcb_irq_lock, flags);
}

static void
ayu_pcb_irq_enable(unsigned int irq)
{
	/* do nothing for enable_irq() */
}

static void
ayu_pcb_irq_disable(unsigned int irq)
{
	/* do nothing for disable_irq() */
}

static void
ayu_pcb_irq_mask(unsigned int irq)
{
	unsigned long flags;

	spin_lock_irqsave(&pcb_irq_lock, flags);
	if (pcb_irq_enabled && !pcb_irq_masked) {
		mask_pcb_irqs();
	}
	spin_unlock_irqrestore(&pcb_irq_lock, flags);
}

static void
ayu_pcb_irq_unmask(unsigned int irq)
{
	unsigned long flags;

	spin_lock_irqsave(&pcb_irq_lock, flags);
	if (pcb_irq_enabled && !pcb_irq_masked) {
		unmask_pcb_irqs();
	}
	spin_unlock_irqrestore(&pcb_irq_lock, flags);
}

static void
ayu_pcb_irq_end(unsigned int irq)
{
	if (!(irq_desc[irq].status & (IRQ_DISABLED | IRQ_INPROGRESS))) {
		ayu_pcb_irq_unmask(irq);
	}
}

struct irq_chip ayu_pcb_irq_chip = {
	.name		= "PCB",
	.startup	= ayu_pcb_irq_startup,
	.shutdown	= ayu_pcb_irq_shutdown,
	.enable		= ayu_pcb_irq_enable,
	.disable	= ayu_pcb_irq_disable,
	.ack		= ayu_pcb_irq_mask,
	.mask		= ayu_pcb_irq_mask,
	.mask_ack	= ayu_pcb_irq_mask,
	.unmask		= ayu_pcb_irq_unmask,
	.end		= ayu_pcb_irq_end,
};

void
ayu_pcb_irq_init(u32 irq_base)
{
	unsigned int num;

	for (num = 0; num < AYU_PCB_IRQ_NUM; num++) {
		set_irq_chip_and_handler(irq_base + num,
					 &ayu_pcb_irq_chip,
					 handle_level_irq);
	}
	pcb_irq_base = irq_base;
}

void
ayu_pcb_irq_dispatch(struct pt_regs *regs)
{
	u_int32_t val;
	int n;

	/* dispatch TSP -> Host */
	val = ayu_in32(AYU_PCB_RPC_THINT_INF);
	val &= AYU_PCB_RPC_THINT_INF_MASK;
	if (val) {
		do_IRQ(AYU_PCB_TSP_IRQ);
		return;
	}

	/* dispatch CRISC -> Host */
	val = ayu_in32(AYU_PCB_RPC_CHINT_INF);
	val &= AYU_PCB_RPC_CHINT_INF_MASK;
	if (val) {
		do_IRQ(AYU_PCB_CRISC_IRQ);
		return;
	}

	/* dispatch ASPn -> Host */
	for (n = 0; n < AYU_PCB_ASP_IRQ_NUM; n++) {
		val  =  ayu_in32(AYU_PCB_RPC_AnHINT0(n));
		val &= ~ayu_in32(AYU_PCB_RPC_AnHINT0_MSK(n));
		if (val) {
			do_IRQ(AYU_PCB_ASP_IRQ(n));
			return;
		}
	}

	/* dispatch Extend CPUn -> Host */
	for (n = 0; n < AYU_PCB_EXCPU_IRQ_NUM; n++) {
		val  =  ayu_in32(AYU_PCB_RPC_EXnHINT0(n));
		val &= ~ayu_in32(AYU_PCB_RPC_EXnHINT0_MSK(n));
		if (val) {
			do_IRQ(AYU_PCB_EXCPU_IRQ(n));
			return;
		}
	}

	/* dispatch Any -> Host */
	val  =  ayu_in32(AYU_PCB_RPC_XHINT0);
	val &= ~ayu_in32(AYU_PCB_RPC_XHINT0_MSK);
	if (val) {
		do_IRQ(AYU_PCB_ANY_IRQ);
		return;
	}

	/* spurious interrupt */
	printk(KERN_ERR "IRQ: spurious interrupt on PCB\n");
}

void
ayu_pcb_mask_irqs(void)
{
	unsigned long flags;

	spin_lock_irqsave(&pcb_irq_lock, flags);
	if (!pcb_irq_masked++ && pcb_irq_enabled) {
		mask_pcb_irqs();
	}
	spin_unlock_irqrestore(&pcb_irq_lock, flags);
}
EXPORT_SYMBOL(ayu_pcb_mask_irqs);

void
ayu_pcb_unmask_irqs(void)
{
	unsigned long flags;

	spin_lock_irqsave(&pcb_irq_lock, flags);
	switch (pcb_irq_masked) {
	case 0:
		printk(KERN_ERR "IRQ: unbalanced unmask for PCB\n");
		WARN_ON(1);
		break;
	case 1:
		if (pcb_irq_enabled) {
			unmask_pcb_irqs();
		}
		/* fall through */
	default:
		pcb_irq_masked--;
	}
	spin_unlock_irqrestore(&pcb_irq_lock, flags);
}
EXPORT_SYMBOL(ayu_pcb_unmask_irqs);

#ifdef CONFIG_PM
/*
 * Suspend/Resume support for PCB
 */
static int
ayu_pcb_resume(struct sys_device *dev)
{
	unsigned long flags;

	/* restore interrupt mask for PCB */
	spin_lock_irqsave(&pcb_irq_lock, flags);
	if (pcb_irq_enabled) {
		unmask_pcb_irqs();
	}
	spin_unlock_irqrestore(&pcb_irq_lock, flags);

	return 0;
}

static struct sysdev_class ayu_pcb_sysclass = {
	set_kset_name("pcb"),
	.suspend	= NULL,
	.resume		= ayu_pcb_resume,
};

static struct sys_device ayu_pcb_sysdev = {
	.id		= 0,
	.cls		= &ayu_pcb_sysclass,
};

static int __init
ayu_pcb_sysdev_init(void)
{
	int ret;

	ret = sysdev_class_register(&ayu_pcb_sysclass);
	if (ret < 0) {
		return ret;
	}
	return sysdev_register(&ayu_pcb_sysdev);
}
device_initcall(ayu_pcb_sysdev_init);
#endif
