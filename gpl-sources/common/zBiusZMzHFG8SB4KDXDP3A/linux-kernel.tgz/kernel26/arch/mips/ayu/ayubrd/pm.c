/* 2010-02-27: File added and changed by Sony Corporation */
/*
 *  arch/mips/ayu/ayubrd/pm.c
 *
 *  Copyright 2010 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/init.h>
#include <linux/pm.h>
#include <linux/ssboot.h>
#include <asm/page.h>
#include <asm/ayu.h>

/*
 * Suspend/Resume support
 */
void
ayubrd_suspend(void)
{
#ifdef CONFIG_AYUBRD_UMEM
	ayubrd_umem_suspend();
#endif
}

void
ayubrd_resume(void)
{
#ifdef CONFIG_AYUBRD_UMEM
	ayubrd_umem_resume();
#endif
}

#ifdef CONFIG_SNSC_SSBOOT
/*
 * Snapshot Boot support
 */
static void __init
ayubrd_ssboot_init(void)
{
	/* discard unused region */
	ssboot_region_register_discard(0, __pa(CONFIG_AYU_KERNEL_BASE_ADDR));

#ifdef CONFIG_AYUBRD_UMEM
	/* discard UMEM region by default */
	ssboot_region_register_discard(__pa(umem_vaddr), umem_vsize);
#endif
}
#endif

/*
 * Initialization
 */
static int __init
ayubrd_pm_init(void)
{
#ifdef CONFIG_SNSC_SSBOOT
	ayubrd_ssboot_init();
#endif
	return 0;
}
late_initcall(ayubrd_pm_init);
