/* 2010-12-13: File changed by Sony Corporation */
/*
 *  arch/mips/ayu/common/prom.c
 *
 *  Copyright 2009 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/string.h>
#include <linux/module.h>
#include <asm/bootinfo.h>
#include <asm/ayu.h>

#define ROOTDEV		"root=/dev/nanda1"
#define ROOTFS		"rootfstype=vfat rootflags=batch_sync"
#define INITRAMFS	"rdinit=/init_root/init"
#define NO_INITRAMFS	"rdinit=/NO_INIT"
#define CONSOLE_DEFAULT	"ttyAMA0,115200n8"
#define CONSOLE_NULL	"ttynull"

void (*prom_reset)(void);
int (*prom_print)(char *fmt, va_list args);
int (*prom_getenv)(char *name, char *value, int size);
int (*prom_exit)(int error);

char ayubrd_mode[CL_SIZE];
int ayubrd_wbi;
EXPORT_SYMBOL(ayubrd_mode);
EXPORT_SYMBOL(ayubrd_wbi);

void
prom_printf(char *fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	prom_print(fmt, args);
	va_end(args);
}

static void __init
prom_init_cmdline(void)
{
	int i;
	char ip[CL_SIZE];
	char boardip[CL_SIZE];
	char gateway[CL_SIZE];
	char netmask[CL_SIZE];
	char syslogip[CL_SIZE];
	char message[CL_SIZE];
	char nfsroot[CL_SIZE];
	char initramfs[CL_SIZE];
	char rootdev[CL_SIZE];
	char rootfs[CL_SIZE];
	char wbi[CL_SIZE];
#ifdef CONFIG_SNSC_KINSPECT
	char kinspect[CL_SIZE];
#endif
	const char *console;
	char *str;
	size_t len;

	strcpy(ip, "ip=off");	/* default: down eth0 on boot time */
	nfsroot[0] = '\0';
	initramfs[0] = '\0';
	rootdev[0] = '\0';
	strncpy(rootfs, ROOTFS, CL_SIZE);
	rootfs[CL_SIZE - 1] = '\0';
#ifdef CONFIG_SNSC_KINSPECT
	kinspect[0] = '\0';
#endif
	arcs_cmdline[0] = '\0';

	ayubrd_mode[0] = '\0';
	ayubrd_wbi = -1;

	if (prom_getenv("boardip", boardip, CL_SIZE)) {
		boardip[0] = '\0';
	}
	if (prom_getenv("gateway", gateway, CL_SIZE)) {
		gateway[0] = '\0';
	}
	if (prom_getenv("netmask", netmask, CL_SIZE)) {
		netmask[0] = '\0';
	}
	if (prom_getenv("syslogip", syslogip, CL_SIZE)) {
		syslogip[0] = '\0';
	}
	if (prom_getenv("message", message, CL_SIZE)) {
		message[0] = '\0';
	}

	if (!strncmp(message, "on", 2) && (boardip[0] != '\0') && (syslogip[0] != '\0')) {
		snprintf(ip, CL_SIZE, "ip=%s::%s:%s", boardip, gateway, netmask);
		ip[CL_SIZE - 1] = '\0';
	}

	if (prom_getenv("boot_option", arcs_cmdline, CL_SIZE)) {
		arcs_cmdline[0] = '\0';
		strncpy(rootdev, ROOTDEV, CL_SIZE);
		rootdev[CL_SIZE - 1] = '\0';
		strncpy(initramfs, INITRAMFS, CL_SIZE);
		initramfs[CL_SIZE - 1] = '\0';
	} else {
#ifdef CONFIG_SNSC_KINSPECT
		str = strstr(arcs_cmdline, "kinspect=on");
		if (str) {
			if (prom_getenv("kinspect", kinspect, CL_SIZE)) {
				kinspect[0] = '\0';
			}
		}
#endif

		str = strstr(arcs_cmdline, "mode=");
		if (str) {
			len = strlen(str);
			for (i = 5; i < len; i++) {
				if (str[i] == ' ') {
					break;
				}
				ayubrd_mode[i - 5] = str[i];
			}
			ayubrd_mode[i - 5] = '\0';
		}

		if (str) {
			nfsroot[8] = '\0';
			if (prom_getenv("nfsroot", nfsroot + 8, CL_SIZE)) {
				nfsroot[0] = '\0';
			}

			if (strncmp(str + 5, "release", 7) &&
			    strncmp(str + 5, "validation", 10) &&
			    strncmp(boardip, "off", 3)) {
				snprintf(ip, CL_SIZE, "ip=%s::%s:%s",
					boardip, gateway, netmask);
				ip[CL_SIZE - 1] = '\0';
			}

			/* if boardip is not set, DHCP will be used. */
			if (!strncmp(str + 5, "nfsdev", 6)) {
				if (nfsroot[8] == '\0') {
					printk("nfsroot not specified. "
					       "changed to normal boot\n");
					strcpy(str + 5, "      ");
					strncpy(initramfs, INITRAMFS, CL_SIZE);
					initramfs[CL_SIZE - 1] = '\0';
				} else {
					strncpy(nfsroot, "nfsroot=", 8);

					/* set rdinit as a nonexistent file so
					   that we can use NFS mount in kernel
					   for development. NFS in kinit is not
					   stable so far. */
					strncpy(initramfs, NO_INITRAMFS, CL_SIZE);
					initramfs[CL_SIZE - 1] = '\0';
				}
			} else {
				strncpy(rootdev, ROOTDEV, CL_SIZE);
				rootdev[CL_SIZE - 1] = '\0';
				strncpy(initramfs, INITRAMFS, CL_SIZE);
				initramfs[CL_SIZE - 1] = '\0';
			}
		}
	}

	if (prom_getenv("create_wbi", wbi, CL_SIZE)) {
	} else {
		if (!strncmp(wbi, "on", 2)) {
			ayubrd_wbi = 1;
		} else {
			ayubrd_wbi = 0;
		}
	}

	if ((*(unsigned long *)AYU_BDI_BOOT_MODE != 3) &&
	    (*(unsigned long *)AYU_BDI_BOOT_MODE != 0)) {
		console_silent();
		console = CONSOLE_NULL;
	} else {
		console = CONSOLE_DEFAULT;
	}

	/* check cmdline length */
	len = strlen(arcs_cmdline);
	if (len >= CL_SIZE - 1) {
		return;
	}

	/* setup cmdline strings */
	snprintf(arcs_cmdline + len, CL_SIZE - len,
		 " console=%s %s %s %s %s %s"
#ifdef CONFIG_SNSC_KINSPECT
		 " %s"
#endif
		 , console, ip, nfsroot, initramfs, rootdev, rootfs
#ifdef CONFIG_SNSC_KINSPECT
		 , kinspect
#endif
		 );
	arcs_cmdline[CL_SIZE - 1] = '\0';
}

void __init
prom_init(void)
{
#ifdef CONFIG_AYU_BDI
	unsigned long bdi;
#endif
	unsigned long clk = *((unsigned long *)AYU_BDI_CPUCLOCK) / 1000000;
	unsigned long *tick = (unsigned long *)0xa0000020;

	prom_reset = (void (*)(void))0x80001800;
	prom_print = (int (*)(char *, va_list))0x800010c0;
	prom_getenv = (int (*)(char *, char *, int))0x80001500;
	prom_exit = (int (*)(int))0x80001410;

	printk(KERN_ALERT "Stby    : %10dus\n", -*(int *)0xbe600004 / 24);
	printk(KERN_ALERT "LPT     : %10dus\n", tick[2] / clk);
	printk(KERN_ALERT "FSCK-A  : %10dus\n", tick[3] / clk);
	printk(KERN_ALERT "FSCK-E  : %10dus\n", tick[4] / clk);
	printk(KERN_ALERT "Load    : %10dus\n", tick[13] / clk);
	printk(KERN_ALERT "Extract : %10dus\n", tick[14] / clk);
	printk(KERN_ALERT "Entry   : %10dus\n", tick[15] / clk);

#ifdef CONFIG_AYU_BDI
	/* check BDI version */
	bdi = *((unsigned long *)AYU_BDI_INFO_VERSION);
	printk(KERN_ALERT "BDI=0x%08lx\n", bdi);
	if (((bdi & 0xff000000) != 0x02000000) || (bdi < 0x02000003)) {
		prom_printf("BDI is old [0x%08x]. Please update BDI.\n", bdi);
		while(1);
	}
#endif
	mips_machgroup = MACH_GROUP_SONY_AYU;

	prom_init_cmdline();
}

void __init
prom_free_prom_memory(void)
{
	/* nothing to do */
}
