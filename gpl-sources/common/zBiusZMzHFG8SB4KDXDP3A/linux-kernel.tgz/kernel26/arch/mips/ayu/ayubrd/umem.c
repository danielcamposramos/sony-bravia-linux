/* 2010-07-26: File added and changed by Sony Corporation */
/*
 *  arch/mips/ayu/ayubrd/umem.c
 *
 *  Copyright 2009,2010 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/pfn.h>
#include <linux/page-flags.h>
#include <linux/mm.h>
#include <linux/swap.h>
#include <linux/proc_fs.h>
#include <linux/ioport.h>
#include <linux/module.h>
#include <linux/ssboot.h>
#include <asm/uaccess.h>
#include <asm/bootinfo.h>
#include <asm/ayu.h>
#include <asm/snsc/emma3_uma.h>

/* UMEM region on MBUS */
unsigned long umem_addr;
unsigned long umem_size;
EXPORT_SYMBOL(umem_addr);
EXPORT_SYMBOL(umem_size);

/* UMEM region on KSEG0 */
unsigned long umem_vaddr;
unsigned long umem_vsize;

#ifdef CONFIG_AYU_HADW
#define AYU_HADW_WIN1_SBASE		0x01000000
#define AYU_HADW_WIN1_DBASE(idx)	(0x41000000 + (128 << 20) * (idx))

/* HADW settings */
unsigned long hadw_win1_sbase;
unsigned long hadw_win1_dbase;

static unsigned long hadw_mode[] __initdata = {
	AYU_MISC_M_HADW_MODE_1,
	AYU_MISC_M_HADW_MODE_6,
	AYU_MISC_M_HADW_MODE_7,
};
#endif

/* default size table */
static unsigned long ayubrd_umem_default_size[] __initdata = {
	0x08000000, 0x0b600000, 0x0f000000
};


/* for proc interfaces */
static DECLARE_MUTEX(umem_proc_sem);

void __init
ayubrd_umem_init(unsigned long ramsize, unsigned long kern_ramsize)
{
	char* size;
#ifdef CONFIG_AYU_HADW
	unsigned long index = ((ramsize >> 20) - 256) / 128;
#endif

	umem_addr = CONFIG_AYUBRD_UMEM_ADDR;
	umem_size = ayubrd_umem_default_size[index];

	/*
	 * Since __setup() or parse_early_param() is called after
	 * plat_mem_setup(), umem should be updated here.
	 */
	size = strstr(arcs_cmdline, "umem=");
	if (size) {
		size += 5;
		umem_size = memparse(size, &size);
	}

#ifdef CONFIG_AYU_HADW
	/* save HADW settings for address conversion */
	hadw_win1_sbase = AYU_HADW_WIN1_SBASE;
	hadw_win1_dbase = AYU_HADW_WIN1_DBASE(index);

	/* UMEM region size in KSEG0 */
	if (umem_addr + umem_size > hadw_win1_dbase) {
		umem_vsize = umem_addr + umem_size - hadw_win1_dbase;
	} else {
		umem_vsize = 0;
	}

	/* enable HADW */
	printk(" enabled HADW: mode=%02lx\n", hadw_mode[index]);
	ayu_out32(AYU_MISC_M_HADW_MODE, hadw_mode[index]);
#else
	/* UMEM region size in KSEG0 */
	umem_vsize = umem_size;
#endif

	/*
	 * bus_to_virt() may change address with offset by HADW.
	 * negative offset in bus_to_virt() makes sure that this address
	 * could not be offset by HADW.
	 */
	umem_vaddr = (unsigned long)bus_to_virt(umem_addr - 0x1000) + 0x1000;

	/*
	 * +----------+ 0x80000000 + kern_ramsize
	 * |          |
	 * |   heap   |
	 * |          |
	 * +----------+ umem_vaddr + umem_vsize
	 * |          |
	 * |   umem   |
	 * |          |
	 * +----------+ 0x81000000 (umem_vaddr)
	 * |  kernel  |
	 * +----------+ 0x80c00000
	 */
	/*
	 * negative offset is used to avoid contiguous virtual memory
	 * assignment between separated physical memories.
	 */
	add_memory_region(0,
			  __pa(umem_vaddr - 0x1000),
			  BOOT_MEM_RAM);
	add_memory_region(__pa(umem_vaddr + umem_vsize),
			  kern_ramsize - __pa(umem_vaddr + umem_vsize),
			  BOOT_MEM_RAM);

	/*
	 * Show UMEM info. on MBUS
	 */
	if(umem_size > 0) {
		printk(" umem: %08lx @ %08lx (on MBUS)\n",
		       umem_size, umem_addr);
	}
}

static int
ayubrd_umem_free_memory(unsigned long start, unsigned long size)
{
	struct resource *res;
	struct page *page;
	unsigned long addr;

	/* add memory region to the system */
	res = request_mem_region(__pa(start), size, "System RAM");
	if (!res) {
		return -EBUSY;
	}
	res->flags |= IORESOURCE_MEM;

	/* free memory */
	for (addr = start; addr < start + size; addr += PAGE_SIZE) {
		page = virt_to_page((void*)addr);
		ClearPageReserved(page);
		init_page_count(page);
		free_page(addr);
		totalram_pages++;
	}
	return 0;
}

static int
ayubrd_umem_proc_read_size(char *page, char **start, off_t off, int count,
			 int *eof, void *data)
{
	int ret;

	if (down_interruptible(&umem_proc_sem)) {
		return -ERESTARTSYS;
	}

	ret = scnprintf(page, PAGE_SIZE, "%lu\n", umem_size / 1024);

	up(&umem_proc_sem);
	return ret;
}

static int
ayubrd_umem_proc_write_size(struct file *file, const char __user *buffer,
			  unsigned long count, void *data)
{
	unsigned long new_size, min_size;
	unsigned long free_addr, free_size;
	int ret;
	char str[16];

	if (down_interruptible(&umem_proc_sem)) {
		return -ERESTARTSYS;
	}

	/* check string length */
	if (count >= sizeof(str)) {
		ret = -EINVAL;
		goto out;
	}

	/* get new size */
	if (copy_from_user(str, buffer, count)) {
		ret = -EFAULT;
		goto out;
	}
	str[count] = '\0';
	new_size = simple_strtoul(str, NULL, 0);
	new_size = PFN_ALIGN(new_size * 1024);

	/* check new size */
	min_size = umem_size - umem_vsize;
#ifdef CONFIG_SNSC_UMA
	min_size = max(uma_region->size_used, min_size);
#endif
	if (new_size < min_size || new_size > umem_size) {
		printk(KERN_ERR
		       "umem: invalid region size: %lukB "
		       "(min=%lukB, max=%lukB)\n", new_size / 1024,
		       min_size / 1024, umem_size / 1024);
		ret = -EINVAL;
		goto out;
	}

	/* free memory */
	free_addr = umem_vaddr + (new_size - min_size);
	free_size = umem_vsize - (new_size - min_size);
	if (free_size > 0) {
		ret = ayubrd_umem_free_memory(free_addr, free_size);
		if (ret < 0) {
			printk(KERN_ERR
			       "umem: cannot free memory %08lx@%08lx\n",
			       free_size, free_addr);
			goto out;
		}
		printk(KERN_INFO
		       "umem: new region size: %lukB (%lukB freed)\n",
		       new_size / 1024, free_size / 1024);
	}

#ifdef CONFIG_SNSC_SSBOOT
	/* unregister old region */
	ssboot_region_unregister(__pa(umem_vaddr), umem_vsize);
#endif

	/* update current size */
	umem_size = new_size;
	umem_vsize = (new_size - min_size);

#ifdef CONFIG_SNSC_SSBOOT
	/* register new region */
	ssboot_region_register_discard(__pa(umem_vaddr), umem_vsize);
#endif

#ifdef CONFIG_SNSC_UMA
	/* update UMA region size */
	uma_region->size = new_size;
#endif

	/* success */
	ret = count;
 out:
	up(&umem_proc_sem);
	return ret;
}

static int __init
ayubrd_umem_proc_init(void)
{
	struct proc_dir_entry *ayubrd, *umem, *size;

	/* create directories */
	ayubrd = proc_mkdir("ayubrd", &proc_root);
	if (!ayubrd) {
		return -ENOMEM;
	}
	umem = proc_mkdir("umem", ayubrd);
	if (!umem) {
		return -ENOMEM;
	}

	/* create 'size' entry for umem */
	size = create_proc_entry("size", S_IRUGO | S_IWUSR, umem);
	if (!size) {
		return -ENOMEM;
	}
	size->read_proc = ayubrd_umem_proc_read_size;
	size->write_proc = ayubrd_umem_proc_write_size;

	return 0;
}
late_initcall(ayubrd_umem_proc_init);

#ifdef CONFIG_PM
/*
 * Suspend/Resume support for UMEM
 */
#ifdef CONFIG_AYU_HADW
static ayu_save_reg_t hadw_regs[] = {
	AYU_SAVE_REG(AYU_MISC_M_HADW_MODE),
	AYU_SAVE_REG_END
};
#endif

void
ayubrd_umem_suspend(void)
{
#ifdef CONFIG_AYU_HADW
	/* save HADW setting */
	ayu_save_registers(hadw_regs);
#endif
}

void
ayubrd_umem_resume(void)
{
#ifdef CONFIG_AYU_HADW
	/* restore HADW setting */
	ayu_restore_registers(hadw_regs);
#endif
}
#endif
