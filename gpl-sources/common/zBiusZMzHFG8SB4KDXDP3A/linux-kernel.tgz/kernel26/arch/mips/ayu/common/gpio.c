/* 2010-07-26: File added and changed by Sony Corporation */
/*
 *  arch/mips/ayu/common/gpio.c
 *
 *  Copyright 2010 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/types.h>
#include <linux/errno.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#ifdef CONFIG_PM
#include <linux/pm.h>
#include <linux/sysdev.h>
#endif
#include <asm/ayu.h>

/* GPIO register types */
typedef enum ayu_gpio_reg {
	GPIO_INT,
	GPIO_DEF,
	GPIO_DIR
} ayu_gpio_reg_t;

static void
gpio_set(ayu_gpio_reg_t reg, unsigned int off, unsigned int bit)
{
	unsigned int num, ch;
	int stby;
	u32 addr;

	/* determine GPIO controller/channel */
	num = (off << 5) + bit;
	if (num >= AYU_GPIO_NUM_MAX) {
		return;
	}
	if (num < AYU_GPIO_NUM_STANDBY) {
		ch = num;
		stby = 1;
	} else {
		ch = num - AYU_GPIO_NUM_STANDBY;
		stby = 0;
	}

	/* determine GPIO register address */
	switch(reg){
	case GPIO_INT:
		addr = stby ? AYU_GPIO_S_SW(ch) : AYU_GPIO_M_SW(ch);
		break;
	case GPIO_DEF:
		addr = stby ? AYU_GPIO_S_SET(ch) : AYU_GPIO_M_SET(ch);
		break;
	case GPIO_DIR:
		addr = stby ? AYU_GPIO_S_DIR(ch) : AYU_GPIO_M_DIR(ch);
		break;
	default:
		return;
	}

	/* set 1 to GPIO register */
	ayu_out32(addr, 1);
}

void
ayu_gpio_init(void)
{
	unsigned int off;
	unsigned int val_int, val_dir, val_def;
	int bit, bit_int, bit_dir;

	/* select GPIO or Interrupt */
	for (off = 0; off < ((AYU_GPIO_NUM_MAX + 31) / 32); off++) {
		/* GPIO interrupt setting */
		val_int = *((unsigned int *)
			    (AYU_BDI_GPIO_INT + (off << 2)));

		while ((bit_int = ffs(val_int))) {
			bit = bit_int - 1;
			gpio_set(GPIO_INT, off, bit);
			val_int &= ~(1 << bit);
		}
	}

	/* setup GPIO */
	for (off = 0; off < ((AYU_GPIO_NUM_MAX + 31) / 32); off++) {
		/* GPIO direction setting */
		val_dir = *((unsigned int *)
			    (AYU_BDI_GPIO_DIR + (off << 2)));

		/* GPIO default setting */
		val_def = *((unsigned int *)
			    (AYU_BDI_GPIO_DEFAULT + (off << 2)));

		while ((bit_dir = ffs(val_dir))) {
			bit = bit_dir - 1;
			gpio_set(GPIO_DIR, off, bit);
			val_dir &= ~(1 << bit);
			if (val_def & (1 << bit)) {
				gpio_set(GPIO_DEF, off, bit);
			}
		}
	}
}

#ifdef CONFIG_PM
/*
 * Suspend/Resume support for GPIO
 */
static int
ayu_gpio_resume(struct sys_device *dev)
{
	ayu_gpio_init();

	return 0;
}

static struct sysdev_class ayu_gpio_sysclass = {
	set_kset_name("gpio"),
	.suspend	= NULL,
	.resume		= ayu_gpio_resume,
};

static struct sys_device ayu_gpio_sysdev = {
	.id		= 0,
	.cls		= &ayu_gpio_sysclass,
};

static int __init
ayu_gpio_sysdev_init(void)
{
	int ret;

	ret = sysdev_class_register(&ayu_gpio_sysclass);
	if (ret < 0) {
		return ret;
	}
	return sysdev_register(&ayu_gpio_sysdev);
}
device_initcall(ayu_gpio_sysdev_init);
#endif
