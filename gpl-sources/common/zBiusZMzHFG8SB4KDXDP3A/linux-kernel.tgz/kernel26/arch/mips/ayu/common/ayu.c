/* 2010-07-26: File added by Sony Corporation */
/*
 *  arch/mips/ayu/common/ayu.c
 *
 *  Copyright 2009 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/init.h>
#include <linux/types.h>
#include <asm/time.h>
#include <asm/ayu.h>

void
ayu_time_init(void)
{
	mips_hpt_frequency = *((unsigned long *)AYU_BDI_CPUCLOCK);

#ifdef CONFIG_GENERIC_CLOCKEVENTS
	/* enable printk-time before time_init() */
	set_cyc2ns_scale();
	safe_to_call_sched_clock = 1;
#endif
}

void
ayu_show_version(void)
{
	u32 rev;

	rev = ayu_in32(AYU_STBREG_ESREV);

	printk("Ayu ");
	switch (rev & AYU_STBREG_ESREV_MASK) {
	case AYU_STBREG_ESREV_ES1:
		printk("ES1");
		break;
	case AYU_STBREG_ESREV_ES2:
		printk("ES2");
		break;
	default:
		printk("unknown");
		break;
	}
	printk(" (Rev: 0x%x)\n", rev);
}
