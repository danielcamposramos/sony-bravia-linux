/* 2010-07-26: File added and changed by Sony Corporation */
/*
 *  arch/mips/ayu/common/devices.c
 *
 *  Copyright 2009 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/platform_device.h>
#include <linux/amba/bus.h>
#include <linux/resource.h>
#ifdef CONFIG_SMAC
#include <linux/smac_platform.h>
#endif
#include <asm/irq.h>
#include <asm/ayu.h>
#include <asm/delay.h>

/*
 * AMBA devices
 */
static struct amba_device uart0_device = {
	.dev = {
		.bus_id			= "uart0",
		.coherent_dma_mask	= ~0,
		.platform_data		= NULL,
	},
	.res = {
		.start	= AYU_UART_A_BASE,
		.end	= AYU_UART_A_BASE + 0x0fff,
		.flags	= IORESOURCE_MEM,
	 },
	.dma_mask	= ~0,
	.irq		= { AYU_UART_A_IRQ, NO_IRQ },
};

#if AYU_UART_NUM >= 2
static struct amba_device uart1_device = {
	.dev = {
		.bus_id			= "uart1",
		.coherent_dma_mask	= ~0,
		.platform_data		= NULL,
	},
	.res = {
		.start	= AYU_UART_B_BASE,
		.end	= AYU_UART_B_BASE + 0x0fff,
		.flags	= IORESOURCE_MEM,
	 },
	.dma_mask	= ~0,
	.irq		= { AYU_UART_B_IRQ, NO_IRQ },
};
#endif

#if AYU_UART_NUM >= 3
static struct amba_device uart2_device = {
	.dev = {
		.bus_id			= "uart2",
		.coherent_dma_mask	= ~0,
		.platform_data		= NULL,
	},
	.res = {
		.start	= AYU_UART_C_BASE,
		.end	= AYU_UART_C_BASE + 0x0fff,
		.flags	= IORESOURCE_MEM,
	 },
	.dma_mask	= ~0,
	.irq		= { AYU_UART_C_IRQ, NO_IRQ },
};
#endif

#if AYU_UART_NUM >= 4
static struct amba_device uart3_device = {
	.dev = {
		.bus_id			= "uart3",
		.coherent_dma_mask	= ~0,
		.platform_data		= NULL,
	},
	.res = {
		.start	= AYU_UART_D_BASE,
		.end	= AYU_UART_D_BASE + 0x0fff,
		.flags	= IORESOURCE_MEM,
	 },
	.dma_mask	= ~0,
	.irq		= { AYU_UART_D_IRQ, NO_IRQ },
};
#endif

static struct amba_device *uart_devices[] __initdata = {
	&uart0_device,
#if AYU_UART_NUM >= 2
	&uart1_device,
#endif
#if AYU_UART_NUM >= 3
	&uart2_device,
#endif
#if AYU_UART_NUM >= 4
	&uart3_device,
#endif
};

/*
 * platform devices
 */
#ifdef CONFIG_SMAC
static struct smac_platform_data smac_data = {
	.mac_addr	= { 0x10, 0x00, 0x00, 0x00, 0x00, 0x0d },
	.phy_addr	= 0x01,
#ifdef CONFIG_AYU_FPGA
	.phy_mcr	= 0x00,	/* AHB: 66MHz */
#else
	.phy_mcr	= 0x01,	/* AHB: 133MHz */
#endif
};

static struct resource smac_resources[] = {
	{
		.name	= "smac_regs",
		.start	= AYU_SMAC_BASE,
		.end	= AYU_SMAC_BASE + 0xffff,
		.flags	= IORESOURCE_MEM,
	},
	{
		.name	= "smac_irq",
		.start	= AYU_SMAC_IRQ,
		.end	= AYU_SMAC_IRQ,
		.flags	= IORESOURCE_IRQ,
	},
};

static struct platform_device smac_device = {
	.name		= "smac",
	.id 		= 0,
	.num_resources	= ARRAY_SIZE(smac_resources),
	.resource	= smac_resources,
	.dev = {
		.platform_data	= &smac_data,
	}
};
#endif

#if defined(CONFIG_USB) || defined(CONFIG_USB_MODULE)
#define AYU_USB_DMA_MASK	0x000000001fffffffULL
static u64 ayu_usb_dma_mask = AYU_USB_DMA_MASK;

#if defined(CONFIG_USB_OHCI_HCD) || defined(CONFIG_USB_OHCI_HCD_MODULE)
static struct resource ayu_ohci_resources[] = {
	{
		.name	= "ohci_mem",
		.start	= AYU_OHCI_BASE,
		.end	= AYU_OHCI_BASE + 0xff,
		.flags	= IORESOURCE_MEM,
	},
	{
		.name	= "ohci_irq",
		.start	= AYU_USB_IRQ,
		.end	= AYU_USB_IRQ,
		.flags	= IORESOURCE_IRQ,
	},
};

static struct platform_device ayu_ohci_device = {
	.name		= "ayu-ohci",
	.id 		= 0,
	.num_resources	= ARRAY_SIZE(ayu_ohci_resources),
	.resource	= ayu_ohci_resources,
	.dev = {
		.dma_mask		= &ayu_usb_dma_mask,
		.coherent_dma_mask	= AYU_USB_DMA_MASK,
	}
};
#endif

#if defined(CONFIG_USB_EHCI_HCD) || defined(CONFIG_USB_EHCI_HCD_MODULE)
static struct resource ayu_ehci_resources[] = {
	{
		.name	= "ehci_mem",
		.start	= AYU_EHCI_BASE,
		.end	= AYU_EHCI_BASE + 0xff,
		.flags	= IORESOURCE_MEM,
	},
	{
		.name	= "ehci_irq",
		.start	= AYU_USB_IRQ,
		.end	= AYU_USB_IRQ,
		.flags	= IORESOURCE_IRQ,
	},
};

static struct platform_device ayu_ehci_device = {
	.name		= "ayu-ehci",
	.id 		= 0,
	.num_resources	= ARRAY_SIZE(ayu_ehci_resources),
	.resource	= ayu_ehci_resources,
	.dev = {
		.dma_mask		= &ayu_usb_dma_mask,
		.coherent_dma_mask	= AYU_USB_DMA_MASK,
	}
};
#endif

#define AYU_USBHCB_RESET_TIMEOUT	1000  /* > 814 [usec] */

static void
ayu_usb_init(void)
{
	int timeout = AYU_USBHCB_RESET_TIMEOUT;
	u32 val;

	/* FEIP USB Reset release sequence */
	ayu_out32(AYU_SYSREG_RSTRELEASE, AYU_SYSREG_RSTRELEASE_FEIPORRST);
	ayu_out32(AYU_SYSREG_RSTRELEASE, AYU_SYSREG_RSTRELEASE_FEIBUSQRST);
	do {
		val =ayu_in32(AYU_SYSREG_RSTMONITOR);
		udelay(1);
	} while((val & AYU_SYSREG_RSTMONITOR_FEIBUSQRST)
		!= AYU_SYSREG_RSTMONITOR_FEIBUSQRST);

	/* wait for reset deasserted */
	while (timeout-- > 0) {
		val = ayu_in32(AYU_USBHCB_CONTROL);
		if ((val & AYU_USBHCB_CONTROL_RSTSTS) != 0)
			break;
		udelay(1);
	}
	if (timeout == 0) {
		printk(KERN_ERR "Ayu: timeout USBHCB reset.\n");
	}

	/* setup dummy read */
	val = ayu_in32(AYU_USBHCB_CONTROL);
	val &= ~AYU_USBHCB_CONTROL_DRDEN;
	ayu_out32(AYU_USBHCB_CONTROL, val);

	ayu_out32(AYU_USBHCB_DR_ADDRESS, 0x18470000);
	ayu_out32(AYU_USBHCB_DR_TRIG_ADR0, 0x00001114);
	ayu_out32(AYU_USBHCB_DR_ADR_MASK0, 0x00000000);
	ayu_out32(AYU_USBHCB_DR_TRIG_ADR1, 0x0000100c);
	ayu_out32(AYU_USBHCB_DR_ADR_MASK1, 0x00000000);

	/* setup control register */
	val = ayu_in32(AYU_USBHCB_CONTROL);
	val |= AYU_USBHCB_CONTROL_DRDEN;
#ifdef CONFIG_AYU_GPIO
	val |= AYU_USBHCB_CONTROL_OVCP;
#endif
	ayu_out32(AYU_USBHCB_CONTROL, val);

	/* for fixing ehci fatal error */
	ayu_out32(AYU_EHCI_BASE + 0x94, 0x0f008000);
	ayu_out32(AYU_EHCI_BASE + 0x9c, 0x01000000);
}
#endif

static struct platform_device *platform_devices[] __initdata = {
#ifdef CONFIG_SMAC
	&smac_device,
#endif
#if defined(CONFIG_USB) || defined(CONFIG_USB_MODULE)
#if defined(CONFIG_USB_OHCI_HCD) || defined(CONFIG_USB_OHCI_HCD_MODULE)
	&ayu_ohci_device,
#endif
#if defined(CONFIG_USB_EHCI_HCD) || defined(CONFIG_USB_EHCI_HCD_MODULE)
	&ayu_ehci_device,
#endif
#endif
};

/*
 * initialization
 */
static int __init
ayu_device_init(void)
{
	int i, ret, err = 0;
#ifdef CONFIG_AYU_BDI
	unsigned long ch;
#endif

#if defined(CONFIG_USB) || defined(CONFIG_USB_MODULE)
	ayu_usb_init();
#endif

	/* register AMBA devices */
#ifdef CONFIG_AYU_BDI
	ch = *(unsigned long *)AYU_BDI_UART_ASSIGN;
#endif
	for (i = 0; i < ARRAY_SIZE(uart_devices); i++) {
#ifdef CONFIG_AYU_BDI
		if (((ch >> (i << 1)) & 0x3) == 0x00) {
#endif
		ret = amba_device_register(uart_devices[i], &iomem_resource);
		if (ret < 0) {
			printk(KERN_ERR
			       "Ayu: cannot register amba device '%s': %d\n",
			       uart_devices[i]->dev.bus_id, ret);
			err = ret;
		}
#ifdef CONFIG_AYU_BDI
		}
#endif
	}
	/* register platform devices */
	ret = platform_add_devices(platform_devices,
				   ARRAY_SIZE(platform_devices));
	if (ret < 0) {
		printk(KERN_ERR
		       "Ayu: cannot register platform devices: %d\n", ret);
		err = ret;
	}

	return err;
}
arch_initcall(ayu_device_init);

#ifdef CONFIG_PM
/*
 * Suspend/Resume support
 */
void
ayu_device_resume(void)
{
#if defined(CONFIG_USB) || defined(CONFIG_USB_MODULE)
	ayu_usb_init();
#endif
}
#endif
