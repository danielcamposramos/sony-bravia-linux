/* 2010-12-13: File changed by Sony Corporation */
/*
 *  arch/mips/ayu/common/pm.c
 *
 *  Copyright 2008,2009,2010 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/init.h>
#include <linux/pm.h>
#include <linux/ssboot.h>
#include <asm/io.h>
#include <asm/time.h>
#include <asm/ayu.h>

static unsigned long saved_c0_count;

/*
 * Functions to save/restore registers
 */
void
ayu_save_registers(ayu_save_reg_t *regs)
{
	/* save listed registers */
	while (regs->addr != 0) {
		regs->val = ayu_in32(regs->addr);
#ifdef CONFIG_PM_VERBOSE
		printk(KERN_DEBUG "PM: Save register: "
		       "addr=0x%08lx, val=0x%08x\n",
		       regs->addr, regs->val);
#endif
		regs++;
	}
}

void
ayu_restore_registers(ayu_save_reg_t *regs)
{
	/* restore listed registers */
	while (regs->addr != 0) {
#ifdef CONFIG_PM_VERBOSE
		u_int32_t old_val;
		old_val = ayu_in32(regs->addr);
		printk(KERN_DEBUG "PM: Restore register: "
		       "addr=0x%08lx, val=0x%08x->0x%08x\n",
		       regs->addr, old_val, regs->val);
#endif
		ayu_out32(regs->addr, regs->val);
		regs++;
	}
}

/*
 * Suspend/Resume routine for Ayu
 */
static void
ayu_save_state(void)
{
	/* call board dependent routine */
#ifdef CONFIG_AYUBRD
	ayubrd_suspend();
#endif

	/* save CP0 count register */
	saved_c0_count = read_c0_count();

	/* save printk-clock */
	printk_clock_suspend();
}

static void
ayu_restore_state(void)
{
	unsigned long clk = *((unsigned long *)AYU_BDI_CPUCLOCK) / 1000000;
	unsigned long *tick = (unsigned long *)0xa0000020;

	/* adjust printk-clock */
	printk_clock_resume();

	/* restore CP0 count register */
	write_c0_count(saved_c0_count);

	/* call board dependent routine */
#ifdef CONFIG_AYUBRD
	ayubrd_resume();
#endif

	printk(KERN_ALERT "Stby    : %10dus\n", -*(int *)0xbe600004 / 24);
	printk(KERN_ALERT "LPT     : %10dus\n", tick[2] / clk);
	printk(KERN_ALERT "FSCK-A  : %10dus\n", tick[3] / clk);
	printk(KERN_ALERT "FSCK-E  : %10dus\n", tick[4] / clk);
	printk(KERN_ALERT "Load    : %10dus\n", tick[13] / clk);
	printk(KERN_ALERT "Extract : %10dus\n", tick[14] / clk);
	printk(KERN_ALERT "Entry   : %10dus\n", tick[15] / clk);

	/* reinitialization for devices */
	ayu_device_resume();
}

/*
 * PM interfaces
 */
static int
ayu_pm_prepare(suspend_state_t state)
{
	return 0;
}

static int
ayu_pm_enter(suspend_state_t state)
{
	int ret = -EINVAL;

	switch (state) {
#ifdef CONFIG_SNSC_SSBOOT
	case PM_SUSPEND_SNAPSHOT:
		ayu_save_state();
		ret = ayu_suspend(ssboot_snapshot);
		ayu_restore_state();
		break;
#endif
	default:
		break;
	}
	return ret;
}

static int
ayu_pm_finish(suspend_state_t state)
{
	return 0;
}

static int
ayu_pm_valid(suspend_state_t state)
{
#ifdef CONFIG_SNSC_SSBOOT
	if (state == PM_SUSPEND_SNAPSHOT) {
		return 1;
	}
#endif
	return 0;
}

struct pm_ops ayu_pm_ops = {
	.prepare	= ayu_pm_prepare,
	.enter		= ayu_pm_enter,
	.finish		= ayu_pm_finish,
	.valid		= ayu_pm_valid,
};

/*
 * Initialization
 */
static int __init
ayu_pm_init(void)
{
	pm_set_ops(&ayu_pm_ops);
	return 0;
}
late_initcall(ayu_pm_init);
