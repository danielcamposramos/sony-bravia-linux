/* 2010-07-26: File added by Sony Corporation */
/*
 *  arch/mips/ayu/common/irq.c
 *
 *  Copyright 2009 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/types.h>
#include <asm/irq_cpu.h>
#include <asm/mipsregs.h>
#include <asm/time.h>
#include <asm/ayu.h>

static struct irqaction intc_cascade = {
	.handler	= no_action,
	.flags		= IRQF_DISABLED,
	.name		= "INTC cascade",
};

void __init
arch_init_irq(void)
{
	/* setup CPU core interrupts */
	mips_cpu_irq_init();

	/* setup PCB interrupts */
	ayu_pcb_irq_init(AYU_PCB_IRQ_BASE);

	/* setup INTC interrupts */
	ayu_intc_irq_init(AYU_INTC_IRQ_BASE);
	setup_irq(AYU_INTC_CASCADE_IRQ, &intc_cascade);
}

asmlinkage void
plat_irq_dispatch(struct pt_regs *regs)
{
        unsigned int pending;

	/* dispatch top level interrupts */
	pending = read_c0_status() & read_c0_cause() & ST0_IM;
	if (pending & STATUSF_IP7) {
#ifdef CONFIG_GENERIC_CLOCKEVENTS
		do_IRQ(AYU_CP0TIMER_IRQ);
#else
		ll_timer_interrupt(AYU_CP0TIMER_IRQ);
#endif
	} else if (pending & STATUSF_IP6) {
		do_IRQ(AYU_FIF_IRQ);
	} else if (pending & STATUSF_IP5) {
		do_IRQ(AYU_SMAC_IRQ);
	} else if (pending & STATUSF_IP4) {
		do_IRQ(AYU_USB_IRQ);
	} else if (pending & STATUSF_IP3) {
		ayu_pcb_irq_dispatch(regs);
	} else if (pending & STATUSF_IP2) {
		ayu_intc_irq_dispatch(regs);
	} else if (pending & STATUSF_IP1) {
		do_IRQ(AYU_CPU_IRQ(1));
	} else if (pending & STATUSF_IP0) {
		do_IRQ(AYU_CPU_IRQ(0));
	} else {
		spurious_interrupt();
	}
}
