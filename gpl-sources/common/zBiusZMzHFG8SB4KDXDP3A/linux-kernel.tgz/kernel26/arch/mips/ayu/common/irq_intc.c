/* 2010-07-26: File added and changed by Sony Corporation */
/*
 *  arch/mips/ayu/common/irq_intc.c
 *
 *  Copyright 2009 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/types.h>
#include <linux/interrupt.h>
#ifdef CONFIG_PM
#include <linux/pm.h>
#include <linux/sysdev.h>
#endif
#include <asm/ayu.h>

static unsigned int intc_irq_base;

#define IRQ_TO_INT(irq)		(irq - intc_irq_base)
#define GET_INTTYPE(info)	(((info)->type_level >> 4) & 0xf)
#define GET_INTLVL(info)	((info)->type_level & 0xf)

static void
ayu_intc_irq_clear(unsigned int irq)
{
	unsigned int num = IRQ_TO_INT(irq);

	/* clear edge interrupt */
	ayu_out32(AYU_INTC_INTCLRVECT, num);
}

static void
ayu_intc_irq_enable(unsigned int irq)
{
	unsigned int num = IRQ_TO_INT(irq);
	ayu_intc_table_t *info;
	u32 level;

	info = (ayu_intc_table_t *)AYU_BDI_INTC_TABLE;

	for (; info->irq != 0xff; info++) {
		if (info->irq == num) {
			level = GET_INTLVL(info);
			ayu_out32(AYU_INTC_INTLVL(num), level);
			break;
		}
	}
}

static void
ayu_intc_irq_disable(unsigned int irq)
{
	unsigned int num = IRQ_TO_INT(irq);

	ayu_out32(AYU_INTC_INTLVL(num), AYU_INTC_INTLVL_DISABLE);
}

static unsigned int
ayu_intc_irq_startup(unsigned int irq)
{
	ayu_intc_irq_enable(irq);
	return 0;
}

static void
ayu_intc_irq_ack_level(unsigned int irq)
{
	ayu_intc_irq_disable(irq);
}

static void
ayu_intc_irq_ack_edge(unsigned int irq)
{
	ayu_intc_irq_disable(irq);
	ayu_intc_irq_clear(irq);
}

static void
ayu_intc_irq_end(unsigned int irq)
{
	if (!(irq_desc[irq].status & (IRQ_DISABLED | IRQ_INPROGRESS))) {
		ayu_intc_irq_enable(irq);
	}
}

struct irq_chip ayu_intc_irq_chip_level = {
	.name		= "INTC (level)",
	.startup	= ayu_intc_irq_startup,
	.shutdown	= ayu_intc_irq_disable,
	.enable		= ayu_intc_irq_enable,
	.disable	= ayu_intc_irq_disable,
	.ack		= ayu_intc_irq_ack_level,
	.mask		= ayu_intc_irq_disable,
	.mask_ack	= ayu_intc_irq_ack_level,
	.unmask		= ayu_intc_irq_enable,
	.end		= ayu_intc_irq_end,
};

struct irq_chip ayu_intc_irq_chip_edge = {
	.name		= "INTC (edge)",
	.startup	= ayu_intc_irq_startup,
	.shutdown	= ayu_intc_irq_disable,
	.enable		= ayu_intc_irq_enable,
	.disable	= ayu_intc_irq_disable,
	.ack		= ayu_intc_irq_ack_edge,
	.mask		= ayu_intc_irq_disable,
	.mask_ack	= ayu_intc_irq_ack_edge,
	.unmask		= ayu_intc_irq_enable,
	.end		= ayu_intc_irq_end,
};

void
ayu_intc_irq_init(u32 irq_base)
{
	ayu_intc_table_t *info;
	u32 type;

	info = (ayu_intc_table_t *)AYU_BDI_INTC_TABLE;

	for (; info->irq != 0xff; info++) {
		/* initialize INTC setting */
		type = GET_INTTYPE(info);

		ayu_out32(AYU_INTC_INTLVL(info->irq), AYU_INTC_INTLVL_DISABLE);

		if (AYU_INTC_INTTYPE_LEVEL_POS != type) {
			ayu_out32(AYU_INTC_INTTYPE(info->irq), type);
		}

		if (AYU_INTC_INTTYPE_IS_EDGE(type)) {
			/* edge triggered source */
			ayu_out32(AYU_INTC_INTCLRVECT, info->irq);
			set_irq_chip_and_handler(irq_base + info->irq,
						 &ayu_intc_irq_chip_edge,
						 handle_level_irq);
		} else {
			/* level triggered source */
			set_irq_chip_and_handler(irq_base + info->irq,
						 &ayu_intc_irq_chip_level,
						 handle_level_irq);
		}
	}

	/* unmask INTC interrupt */
	ayu_out32(AYU_INTC_INTMSKLVL, AYU_INTC_INTMSKLVL_MASK_NONE);
	ayu_out32(AYU_INTC_OUTINTMSKLVL_A, AYU_INTC_OUTINTMSKLVL_MASK_NONE);

	/* save base IRQ number */
	intc_irq_base = irq_base;
}

void
ayu_intc_irq_dispatch(struct pt_regs *regs)
{
	u32 val, num, lvl;

	/* get source number and interrupt level */
	val = ayu_in32(AYU_INTC_OUTINTVECT_A);
	num = AYU_INTC_OUTINTVECT_NUM(val);
	lvl = AYU_INTC_OUTINTVECT_LVL(val);

	/* dispatch INTC 0-223 */
	if (lvl > 0) {
		do_IRQ(AYU_INTC_IRQ(num));
		return;
	}

	/* spurious interrupt */
	printk(KERN_ERR "IRQ: spurious interrupt on INTC\n");
}

#ifdef CONFIG_PM
/*
 * Suspend/Resume support for INTC
 */
#define INTC_TABLE_MAX		(AYU_BDI_INTC_TABLE_SIZE / \
				 sizeof(ayu_intc_table_t))
static ayu_save_reg_t intc_regs[(INTC_TABLE_MAX - 1) * 2 + 3];

static int
ayu_intc_suspend(struct sys_device *dev, pm_message_t mesg)
{
	ayu_intc_table_t *info;
	int i = 0;

	info = (ayu_intc_table_t *)AYU_BDI_INTC_TABLE;

	/* create save list */
	for (; info->irq != 0xff; info++) {
		intc_regs[i++].addr = AYU_INTC_INTLVL(info->irq);
		intc_regs[i++].addr = AYU_INTC_INTTYPE(info->irq);
	}
	intc_regs[i++].addr = AYU_INTC_INTMSKLVL;
	intc_regs[i++].addr = AYU_INTC_OUTINTMSKLVL_A;
	intc_regs[i++].addr = 0;

	/* save INTC settings */
	ayu_save_registers(intc_regs);

	return 0;
}

static int
ayu_intc_resume(struct sys_device *dev)
{
	/* restore INTC settings */
	ayu_restore_registers(intc_regs);

	return 0;
}

static struct sysdev_class ayu_intc_sysclass = {
	set_kset_name("intc"),
	.suspend	= ayu_intc_suspend,
	.resume		= ayu_intc_resume,
};

static struct sys_device ayu_intc_sysdev = {
	.id		= 0,
	.cls		= &ayu_intc_sysclass,
};

static int __init
ayu_intc_sysdev_init(void)
{
	int ret;

	ret = sysdev_class_register(&ayu_intc_sysclass);
	if (ret < 0) {
		return ret;
	}
	return sysdev_register(&ayu_intc_sysdev);
}
device_initcall(ayu_intc_sysdev_init);
#endif
