/* 2010-04-04: File added and changed by Sony Corporation */
/*
 *  arch/mips/ayu/ayubrd/uma.c
 *
 *  Copyright 2010 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <linux/init.h>
#include <linux/types.h>
#include <linux/ssboot.h>
#include <asm/pgtable.h>
#include <asm/ayu.h>
#include <asm/snsc/emma3_uma.h>

/*
 * UMA regions
 */
static struct emma3_uma_region uma_region_umem[] = {
	{
		.name	= "VR_High_MEM0",
		.param	= UMA_HIMEM | UMA_MEM0 | UMA_VR,
		.vaddr	= AYU_VIRT_UMA_CAC_BASE,
	},
	{
		.param	= UMA_INVALID,
		.umaddr	= 0x0,
	}
};

static struct emma3_uma_region uma_region_none[] = {
	{
		.param	= UMA_INVALID,
		.umaddr	= 0x0,
	}
};

struct emma3_uma_region *uma_region = uma_region_none;

/*
 * TLB setup functions
 */
int __init
emma3_uma_tlb_init(void)
{
	/*
	 * Physical Address         Virtual Address
	 * 0x40000000-0x4FFFFFFF -> 0xC0000000-0xCFFFFFFF (cached)
	 * 0x40000000-0x4FFFFFFF -> 0xD0000000-0xDFFFFFFF (uncached)
	 */
	add_wired_entry(ENTRYLO(AYU_PHYS_UMA_MAPBASE + 0x00000000),
			ENTRYLO(AYU_PHYS_UMA_MAPBASE + 0x04000000),
			(AYU_VIRT_UMA_CAC_MAPBASE + 0x00000000), PM_64M);
	add_wired_entry(ENTRYLO(AYU_PHYS_UMA_MAPBASE + 0x08000000),
			ENTRYLO(AYU_PHYS_UMA_MAPBASE + 0x0c000000),
			(AYU_VIRT_UMA_CAC_MAPBASE + 0x08000000), PM_64M);
	add_wired_entry(ENTRYLO_UNCAC(AYU_PHYS_UMA_MAPBASE + 0x00000000),
			ENTRYLO_UNCAC(AYU_PHYS_UMA_MAPBASE + 0x04000000),
			(AYU_VIRT_UMA_UNCAC_MAPBASE + 0x00000000), PM_64M);
	add_wired_entry(ENTRYLO_UNCAC(AYU_PHYS_UMA_MAPBASE + 0x08000000),
			ENTRYLO_UNCAC(AYU_PHYS_UMA_MAPBASE + 0x0c000000),
			(AYU_VIRT_UMA_UNCAC_MAPBASE + 0x08000000), PM_64M);

#ifdef CONFIG_SNSC_SSBOOT
	/* register UMA memory map */
	ssboot_memmap_register(AYU_PHYS_UMA_MAPBASE,
			       (void *)AYU_VIRT_UMA_CAC_MAPBASE,
			       0x10000000);
#endif
	return 0;
}

/*
 * Initialization
 */
void __init
ayubrd_uma_init(unsigned int ramsize)
{
	/* setup UMA region */
	if (ramsize > MB(256)) {
		uma_region = uma_region_umem;

		/* use whole UMEM region as UMA */
		uma_region->umaddr = umem_addr;
		uma_region->size = umem_size;
	}
}
