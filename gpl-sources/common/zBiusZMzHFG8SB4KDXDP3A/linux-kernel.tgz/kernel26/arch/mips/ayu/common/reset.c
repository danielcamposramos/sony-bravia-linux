/* 2010-07-26: File added by Sony Corporation */
/*
 *  arch/mips/ayu/common/reset.c
 *
 *  Copyright 2009 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <asm/irq.h>
#include <asm/ayu.h>

void
ayu_machine_restart(char *command)
{
	printk("Ayu restart.\n");

	local_irq_disable();
	set_c0_status(ST0_BEV | ST0_ERL);
	__asm__("jr\t%0"::"r"(0xbfc00000));
}

void
ayu_machine_halt(void)
{
	printk("Ayu halted.\n");

	local_irq_disable();
	while (1) {
		__asm__(".set\tmips3\n\t"
	                "wait\n\t"
			".set\tmips0");
	}
}

void
ayu_machine_power_off(void)
{
	printk("Ayu halted. Please turn off the power.\n");

	local_irq_disable();
	while (1) {
		__asm__(".set\tmips3\n\t"
	                "wait\n\t"
			".set\tmips0");
	}
}
