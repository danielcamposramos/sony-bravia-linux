/* 2010-07-26: File added and changed by Sony Corporation */
/*
 *  arch/mips/ayu/common/setup.c
 *
 *  Copyright 2009 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/init.h>
#include <linux/types.h>
#include <linux/irq.h>
#include <asm/time.h>
#include <asm/ayu.h>

void __init
ayu_setup_common(void)
{
	ayu_time_init();

	ayu_show_version();

#ifdef CONFIG_AYU_GPIO
	ayu_gpio_init();
#endif
}

#ifdef CONFIG_GENERIC_CLOCKEVENTS
void __init
plat_time_init(void)
#else
void __init
plat_timer_setup(struct irqaction *irq)
#endif
{
#ifndef CONFIG_GENERIC_CLOCKEVENTS
	/* we are using the cpu counter for timer interrupts */
	irq->handler = no_action;
	setup_irq(AYU_CP0TIMER_IRQ, irq);
#endif

	/* fixup performance counter IRQ for sharing with timer */
	cp0_perfcount_irq = -1;
}
