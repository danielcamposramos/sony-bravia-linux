/* 2010-07-26: File changed by Sony Corporation */
/*
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 *
 * Copyright (C) 1995 Linus Torvalds
 * Copyright (C) 1995 Waldorf Electronics
 * Copyright (C) 1994, 95, 96, 97, 98, 99, 2000, 01, 02, 03  Ralf Baechle
 * Copyright (C) 1996 Stoned Elipot
 * Copyright (C) 1999 Silicon Graphics, Inc.
 * Copyright (C) 2000 2001, 2002  Maciej W. Rozycki
 */
#include <linux/init.h>
#include <linux/ioport.h>
#include <linux/module.h>
#include <linux/screen_info.h>
#include <linux/bootmem.h>
#include <linux/initrd.h>
#include <linux/root_dev.h>
#include <linux/highmem.h>
#include <linux/console.h>
#include <linux/pfn.h>
#include <linux/debugfs.h>
#ifdef CONFIG_SNSC_NBLARGS
#include <linux/snsc_nblargs.h>
#endif /* CONFIG_SNSC_NBLARGS */
#include <linux/snsc_boot_time.h>
#ifdef CONFIG_SNSC_MACADDR
#include <linux/snsc_macaddr.h>
#endif /* CONFIG_SNSC_MACADDR */
#ifdef CONFIG_SNSC_UMA
#include <linux/snsc_uma.h>
#endif

#include <asm/addrspace.h>
#include <asm/bootinfo.h>
#include <asm/cache.h>
#include <asm/cpu.h>
#include <asm/sections.h>
#include <asm/setup.h>
#include <asm/system.h>
#ifdef CONFIG_SNSC_BOOTINFO
#include <asm/bootinfo.h>
#ifdef CONFIG_SNSC_USE_TARGETID_FROM_NBL
#include <asm/snsc/snsc_machtype.h>
#endif /* CONFIG_SNSC_USE_TARGETID_FROM_NBL */
#endif
#include <linux/mm.h>

struct cpuinfo_mips cpu_data[NR_CPUS] __read_mostly;

EXPORT_SYMBOL(cpu_data);

#ifdef CONFIG_VT
struct screen_info screen_info;
#endif

/*
 * Despite it's name this variable is even if we don't have PCI
 */
unsigned int PCI_DMA_BUS_IS_PHYS;

EXPORT_SYMBOL(PCI_DMA_BUS_IS_PHYS);

/*
 * Setup information
 *
 * These are initialized so they are in the .data section
 */
unsigned long mips_machtype __read_mostly = MACH_UNKNOWN;
unsigned long mips_machgroup __read_mostly = MACH_GROUP_UNKNOWN;

EXPORT_SYMBOL(mips_machtype);
EXPORT_SYMBOL(mips_machgroup);

struct boot_mem_map boot_mem_map;

#ifdef CONFIG_SNSC_USE_ADDITIONAL_KERNEL_CMDLINE
static char command_line[CL_SIZE + SNSC_ADDITIONAL_COMMAND_LINE_SIZE];
static char __initdata additional_boot_command_line[SNSC_ADDITIONAL_COMMAND_LINE_SIZE]
                                                   = CONFIG_SNSC_ADDITIONAL_CMDLINE;
#else
static char command_line[CL_SIZE];
#endif
       char arcs_cmdline[CL_SIZE]=CONFIG_CMDLINE;

/*
 * mips_io_port_base is the begin of the address space to which x86 style
 * I/O ports are mapped.
 */
const unsigned long mips_io_port_base __read_mostly = -1;
EXPORT_SYMBOL(mips_io_port_base);

/*
 * isa_slot_offset is the address where E(ISA) busaddress 0 is mapped
 * for the processor.
 */
unsigned long isa_slot_offset;
EXPORT_SYMBOL(isa_slot_offset);

static struct resource code_resource = { .name = "Kernel code", };
static struct resource data_resource = { .name = "Kernel data", };

#ifdef CONFIG_NUMA
void __init add_memory_region_node(phys_t start, phys_t size, int nid, long type)
{
	int x = boot_mem_map.nr_map;
	struct boot_mem_map_entry *prev = boot_mem_map.map + x - 1;

	/* Sanity check */
	if (start + size < start) {
		printk("Trying to add an invalid memory region, skipped\n");
		return;
	}

	/*
	 * Try to merge with previous entry if any.  This is far less than
	 * perfect but is sufficient for most real world cases.
	 */
	if (x &&
	    prev->addr + prev->size == start &&
	    prev->type == type &&
	    prev->nid == nid) {
		prev->size += size;
		return;
	}

	if (x == BOOT_MEM_MAP_MAX) {
		printk("Ooops! Too many entries in the memory map!\n");
		return;
	}

	boot_mem_map.map[x].addr = start;
	boot_mem_map.map[x].size = size;
	boot_mem_map.map[x].nid = nid;
	boot_mem_map.map[x].type = type;
	boot_mem_map.nr_map++;
}
#endif

void __init add_memory_region(phys_t start, phys_t size, long type)
{
	int x = boot_mem_map.nr_map;
	struct boot_mem_map_entry *prev = boot_mem_map.map + x - 1;

	/* Sanity check */
	if (start + size < start) {
		printk("Trying to add an invalid memory region, skipped\n");
		return;
	}

	/*
	 * Try to merge with previous entry if any.  This is far less than
	 * perfect but is sufficient for most real world cases.
	 */
	if (x && prev->addr + prev->size == start && prev->type == type) {
		prev->size += size;
		return;
	}

	if (x == BOOT_MEM_MAP_MAX) {
		printk("Ooops! Too many entries in the memory map!\n");
		return;
	}

	boot_mem_map.map[x].addr = start;
	boot_mem_map.map[x].size = size;
	boot_mem_map.map[x].type = type;
	boot_mem_map.nr_map++;
}

static void __init print_memory_map(void)
{
	int i;
	const int field = 2 * sizeof(unsigned long);

	for (i = 0; i < boot_mem_map.nr_map; i++) {
		printk(" memory: %0*Lx @ %0*Lx ",
		       field, (unsigned long long) boot_mem_map.map[i].size,
		       field, (unsigned long long) boot_mem_map.map[i].addr);

		switch (boot_mem_map.map[i].type) {
		case BOOT_MEM_RAM:
			printk("(usable)\n");
			break;
		case BOOT_MEM_ROM_DATA:
			printk("(ROM data)\n");
			break;
		case BOOT_MEM_RESERVED:
			printk("(reserved)\n");
			break;
		default:
			printk("type %lu\n", boot_mem_map.map[i].type);
			break;
		}
	}
}

/*
 * Manage initrd
 */
#ifdef CONFIG_BLK_DEV_INITRD

static int __init rd_start_early(char *p)
{
	unsigned long start = memparse(p, &p);

#ifdef CONFIG_64BIT
	/* Guess if the sign extension was forgotten by bootloader */
	if (start < XKPHYS)
		start = (int)start;
#endif
	initrd_start = start;
	initrd_end += start;
	return 0;
}
early_param("rd_start", rd_start_early);

static int __init rd_size_early(char *p)
{
	initrd_end += memparse(p, &p);
	return 0;
}
early_param("rd_size", rd_size_early);

/* it returns the next free pfn after initrd */
static unsigned long __init init_initrd(void)
{
	unsigned long end;
	u32 *initrd_header;

	/*
	 * Board specific code or command line parser should have
	 * already set up initrd_start and initrd_end. In these cases
	 * perfom sanity checks and use them if all looks good.
	 */
	if (initrd_start && initrd_end > initrd_start)
		goto sanitize;

	/*
	 * See if initrd has been added to the kernel image by
	 * arch/mips/boot/addinitrd.c. In that case a header is
	 * prepended to initrd and is made up by 8 bytes. The fisrt
	 * word is a magic number and the second one is the size of
	 * initrd.  Initrd start must be page aligned in any cases.
	 */
	initrd_header = __va(PAGE_ALIGN(__pa_symbol(&_end) + 8)) - 8;
	if (initrd_header[0] != 0x494E5244)
		goto disable;
	initrd_start = (unsigned long)(initrd_header + 2);
	initrd_end = initrd_start + initrd_header[1];

sanitize:
	if (initrd_start & ~PAGE_MASK) {
		printk(KERN_ERR "initrd start must be page aligned\n");
		goto disable;
	}
	if (initrd_start < PAGE_OFFSET) {
		printk(KERN_ERR "initrd start < PAGE_OFFSET\n");
		goto disable;
	}

	/*
	 * Sanitize initrd addresses. For example firmware
	 * can't guess if they need to pass them through
	 * 64-bits values if the kernel has been built in pure
	 * 32-bit. We need also to switch from KSEG0 to XKPHYS
	 * addresses now, so the code can now safely use __pa().
	 */
	end = __pa(initrd_end);
	initrd_end = (unsigned long)__va(end);
	initrd_start = (unsigned long)__va(__pa(initrd_start));

	ROOT_DEV = Root_RAM0;
	return PFN_UP(end);
disable:
	initrd_start = 0;
	initrd_end = 0;
	return 0;
}

static void __init finalize_initrd(void)
{
	unsigned long size = initrd_end - initrd_start;

	if (size == 0) {
		printk(KERN_INFO "Initrd not found or empty");
		goto disable;
	}
	if (__pa(initrd_end) > PFN_PHYS(max_low_pfn)) {
		printk("Initrd extends beyond end of memory");
		goto disable;
	}

	reserve_bootmem(__pa(initrd_start), size);
	initrd_below_start_ok = 1;

	printk(KERN_INFO "Initial ramdisk at: 0x%lx (%lu bytes)\n",
	       initrd_start, size);
	return;
disable:
	printk(" - disabling initrd\n");
	initrd_start = 0;
	initrd_end = 0;
}

#else  /* !CONFIG_BLK_DEV_INITRD */

static unsigned long __init init_initrd(void)
{
	return 0;
}

#define finalize_initrd()	do {} while (0)
#endif

/*
 * Initialize the bootmem allocator. It also setup initrd related data
 * if needed.
 */
#ifdef CONFIG_SGI_IP27

static void __init bootmem_init(void)
{
	init_initrd();
	finalize_initrd();
}

#else  /* !CONFIG_SGI_IP27 */

#ifdef CONFIG_NUMA
#define EARLY_PFN_TO_NID(pfn)	early_pfn_to_nid(pfn)
#define EARLY_PHYS_TO_NID(addr) EARLY_PFN_TO_NID((addr) >> PAGE_SHIFT)

#ifdef CONFIG_HAVE_ARCH_EARLY_PFN_TO_NID
extern struct node_active_region __meminitdata early_node_map[];
extern int __meminitdata nr_nodemap_entries;
/*
 * Basicly the same to the one in mm/page_alloc.c, but return -1 instead of
 * 0 when no node matches for the pfn. This is important to implement
 * memory reservation.
 */
int __meminit early_pfn_to_nid(unsigned long pfn)
{
	int i;

	for (i = 0; i < nr_nodemap_entries; i++) {
		unsigned long start_pfn = early_node_map[i].start_pfn;
		unsigned long end_pfn = early_node_map[i].end_pfn;

		if (start_pfn <= pfn && pfn < end_pfn)
			return early_node_map[i].nid;
	}

	return -1;
}
#endif

#ifdef CONFIG_SNSC_MEMORY_RESERVE_SUPPORT
static __init void reserve_mem(int nid, pg_data_t *pgdat)
{
	unsigned long index;
	unsigned int start, size;

	for (index = 0; index < reserve_mem_nr_map; index++) {
		start = reserved_mem[index].start;
		size = reserved_mem[index].size;

		if (EARLY_PHYS_TO_NID(start) == nid) {
			if (start < pgdat->bdata->node_boot_start
			    || start + size > (pgdat->bdata->node_low_pfn) << PAGE_SHIFT) {
				panic("reserve area: 0x%x@0x%x crossed node%d boundary. Stop booting.\n",
				      size, start, nid);
			}
			printk("reserving: nid: %d start: %x, size: %x\n",
			       nid, start, size);
			reserve_bootmem_node(pgdat, start, size);
		}
	}
}

static int __init parse_memrsv(char *p)
{
	unsigned long size,start;

	size = start = 0;
	size = memparse(p, &p);
	if(*p == '@' || *p == '$' || *p == '#'){
		start = memparse(p + 1, &p);
	}

	if(size && start){
		if(reserve_mem_nr_map == MAX_RESERVE_AREAS){
			printk(KERN_ERR "too many reserved areas(max %d)!\n", MAX_RESERVE_AREAS);
			return 1;
		}

		printk("reserve area %lu: %lX @ %lX\n",reserve_mem_nr_map, size, start);
		reserved_mem[reserve_mem_nr_map].start = start;
		reserved_mem[reserve_mem_nr_map++].size = size;
	}
	return 0;
}
early_param("memrsv", parse_memrsv);
#endif

static void __init bootmem_init(void)
{
	unsigned long reserved_end;
	unsigned long mapstart = ~0UL, mapend;

	pg_data_t *pgdat;
	int i, nid;

	/*
	 * Init any data related to initrd. It's a nop if INITRD is
	 * not selected. Once that done we can determine the low bound
	 * of usable memory.
	 */
#ifdef CONFIG_SNSC
	init_initrd();
	reserved_end = PFN_UP(__pa_symbol(&_end));
#else
	reserved_end = max(init_initrd(), PFN_UP(__pa_symbol(&_end)));
#endif
	/*
	 * max_low_pfn is not a number of pages. The number of pages
	 * of the system is given by 'max_low_pfn - min_low_pfn'.
	 */
	min_low_pfn = ~0UL;
	max_low_pfn = 0;

	/*
	 * Find the highest page frame number we have available.
	 */
	for (i = 0; i < boot_mem_map.nr_map; i++) {

		unsigned long start_pfn, end_pfn;
		unsigned int boot_pages;

		if (boot_mem_map.map[i].type != BOOT_MEM_RAM)
			continue;

		start_pfn = PFN_UP(boot_mem_map.map[i].addr);
		end_pfn = PFN_DOWN(boot_mem_map.map[i].addr
				+ boot_mem_map.map[i].size);

		if (end_pfn > max_low_pfn)
			max_low_pfn = end_pfn;
		if (start_pfn < min_low_pfn)
			min_low_pfn = start_pfn;
		if (end_pfn <= reserved_end)
			continue;

		nid = boot_mem_map.map[i].nid;
		pgdat = NODE_DATA(nid);

		/* At current, no support for two different memory chunks
		 * with the same nid. */
		boot_pages = bootmem_bootmap_pages(end_pfn - start_pfn);
		mapstart = max(reserved_end, start_pfn);

		node_set_online(nid);
		/* Free all pages from bitmap's end to node's end */
		mapend = mapstart + boot_pages;
#ifdef CONFIG_NODEZERO_ALLOCATION
		{
			unsigned long boot_pfn;
			if (nid == 0) {
				boot_pfn = mapstart;
			} else {
				boot_pfn = (virt_to_phys(alloc_bootmem_low_pages_node(NODE_DATA(0), boot_pages << PAGE_SHIFT))) >> PAGE_SHIFT;
			}

			init_bootmem_node(pgdat, boot_pfn, start_pfn, end_pfn);

			free_bootmem_node(pgdat,
					  start_pfn << PAGE_SHIFT,
					  (end_pfn - start_pfn) << PAGE_SHIFT);
			if (nid == 0) {
				/* Reserve the bootmem bitmap for node0. */
				reserve_bootmem_node(pgdat, mapstart << PAGE_SHIFT, boot_pages << PAGE_SHIFT);
				/* Reserve kernel area in node0 */
				reserve_bootmem_node(pgdat, start_pfn << PAGE_SHIFT, (mapstart - start_pfn) << PAGE_SHIFT);
			}
		}
#else
		init_bootmem_node(pgdat, mapstart, start_pfn, end_pfn);
		free_bootmem_node(pgdat,
				  mapend << PAGE_SHIFT,
				  (end_pfn - mapend) << PAGE_SHIFT);
#endif
		add_active_range(nid, start_pfn, end_pfn);
		memory_present(nid, start_pfn, end_pfn);
		sparse_init_region(start_pfn, end_pfn);

	}
#ifdef CONFIG_SNSC_MEMORY_RESERVE_SUPPORT
	for_each_node(nid) {
		pgdat = NODE_DATA(nid);
		reserve_mem(nid, pgdat);
 	}
#endif
	if (min_low_pfn >= max_low_pfn)
		panic("Incorrect memory mapping !!!");
	if (min_low_pfn > ARCH_PFN_OFFSET) {
		printk(KERN_INFO
		       "Wasting %lu bytes for tracking %lu unused pages\n",
		       (min_low_pfn - ARCH_PFN_OFFSET) * sizeof(struct page),
		       min_low_pfn - ARCH_PFN_OFFSET);
	} else if (min_low_pfn < ARCH_PFN_OFFSET) {
		printk(KERN_INFO
		       "%lu free pages won't be used\n",
		       ARCH_PFN_OFFSET - min_low_pfn);
	}
	min_low_pfn = ARCH_PFN_OFFSET;

	/*
	 * Determine low and high memory ranges
	 */
	if (max_low_pfn > PFN_DOWN(HIGHMEM_START)) {
#ifdef CONFIG_HIGHMEM
		highstart_pfn = PFN_DOWN(HIGHMEM_START);
		highend_pfn = max_low_pfn;
#endif
		max_low_pfn = PFN_DOWN(HIGHMEM_START);
	}

	/*
	 * Reserve initrd memory if needed.
	 */
	finalize_initrd();
}

#else

static void __init bootmem_init(void)
{
	unsigned long reserved_end;
	unsigned long mapstart = ~0UL;
	unsigned long bootmap_size;
	int i;

	/*
	 * Init any data related to initrd. It's a nop if INITRD is
	 * not selected. Once that done we can determine the low bound
	 * of usable memory.
	 */
#if defined(CONFIG_SNSC_BOOTINFO) && defined(CONFIG_BLK_DEV_INITRD)
	init_initrd();
	reserved_end = PFN_UP(__pa_symbol(&_end));
#else
	reserved_end = max(init_initrd(), PFN_UP(__pa_symbol(&_end)));
#endif

	/*
	 * max_low_pfn is not a number of pages. The number of pages
	 * of the system is given by 'max_low_pfn - min_low_pfn'.
	 */
	min_low_pfn = ~0UL;
	max_low_pfn = 0;

	/*
	 * Find the highest page frame number we have available.
	 */
	for (i = 0; i < boot_mem_map.nr_map; i++) {
		unsigned long start, end;

		if (boot_mem_map.map[i].type != BOOT_MEM_RAM)
			continue;

		start = PFN_UP(boot_mem_map.map[i].addr);
		end = PFN_DOWN(boot_mem_map.map[i].addr
				+ boot_mem_map.map[i].size);

#ifndef CONFIG_SNSC_MALTA_MEMPLUG_MM_INIT_FIX
		add_active_range(0, start, end);
#endif

		if (end > max_low_pfn)
			max_low_pfn = end;
		if (start < min_low_pfn)
			min_low_pfn = start;
		if (end <= reserved_end)
			continue;
		if (start >= mapstart)
			continue;
		mapstart = max(reserved_end, start);
	}

	if (min_low_pfn >= max_low_pfn)
		panic("Incorrect memory mapping !!!");
	if (min_low_pfn > ARCH_PFN_OFFSET) {
		printk(KERN_INFO
		       "Wasting %lu bytes for tracking %lu unused pages\n",
		       (min_low_pfn - ARCH_PFN_OFFSET) * sizeof(struct page),
		       min_low_pfn - ARCH_PFN_OFFSET);
	} else if (min_low_pfn < ARCH_PFN_OFFSET) {
		printk(KERN_INFO
		       "%lu free pages won't be used\n",
		       ARCH_PFN_OFFSET - min_low_pfn);
	}
	min_low_pfn = ARCH_PFN_OFFSET;

	/*
	 * Determine low and high memory ranges
	 */
	if (max_low_pfn > PFN_DOWN(HIGHMEM_START)) {
#ifdef CONFIG_HIGHMEM
		highstart_pfn = PFN_DOWN(HIGHMEM_START);
		highend_pfn = max_low_pfn;
#endif
		max_low_pfn = PFN_DOWN(HIGHMEM_START);
	}

#if defined(CONFIG_SNSC_BOOTINFO) && defined(CONFIG_BLK_DEV_INITRD)
	/*
	 * Fixup mapstart address to avoid overlap between the initrd region
	 * and the boot bitmap region.
	 */
	if (initrd_start > 0) {
		unsigned long start, end;

		start = PFN_DOWN(__pa(initrd_start));
		end = PFN_UP(__pa(initrd_end));

		if ((mapstart <= start) &&
		    (start - mapstart < max_low_pfn - end)) {
			mapstart = end;
		}
	}
#endif

	/*
	 * Initialize the boot-time allocator with low memory only.
	 */
	bootmap_size = init_bootmem_node(NODE_DATA(0), mapstart,
					 min_low_pfn, max_low_pfn);

#ifdef CONFIG_SNSC_MALTA_MEMPLUG_MM_INIT_FIX
	for (i = 0; i < boot_mem_map.nr_map; i++) {
		unsigned long start, end;

		start = PFN_UP(boot_mem_map.map[i].addr);
		end = PFN_DOWN(boot_mem_map.map[i].addr
				+ boot_mem_map.map[i].size);

		if (start <= min_low_pfn)
			start = min_low_pfn;
		if (start >= end)
			continue;

#ifndef CONFIG_HIGHMEM
		if (end > max_low_pfn)
			end = max_low_pfn;

		/*
		 * ... finally, is the area going away?
		 */
		if (end <= start)
			continue;
#endif
		add_active_range(0, start, end);
	}
#endif /* CONFIG_SNSC_MALTA_MEMPLUG_MM_INIT_FIX */

	/*
	 * Register fully available low RAM pages with the bootmem allocator.
	 */
	for (i = 0; i < boot_mem_map.nr_map; i++) {
		unsigned long start, end, size;

		/*
		 * Reserve usable memory.
		 */
		if (boot_mem_map.map[i].type != BOOT_MEM_RAM)
			continue;

		start = PFN_UP(boot_mem_map.map[i].addr);
		end   = PFN_DOWN(boot_mem_map.map[i].addr
				    + boot_mem_map.map[i].size);
		/*
		 * We are rounding up the start address of usable memory
		 * and at the end of the usable range downwards.
		 */
		if (start >= max_low_pfn)
			continue;
		if (start < reserved_end)
			start = reserved_end;
		if (end > max_low_pfn)
			end = max_low_pfn;

		/*
		 * ... finally, is the area going away?
		 */
		if (end <= start)
			continue;
		size = end - start;

		/* Register lowmem ranges */
		free_bootmem(PFN_PHYS(start), size << PAGE_SHIFT);
		memory_present(0, start, end);
#ifdef CONFIG_SPARSEMEM
		sparse_init_region(start, end);
#endif
	}

	/*
	 * Reserve the bootmap memory.
	 */
	reserve_bootmem(PFN_PHYS(mapstart), bootmap_size);

	/*
	 * Reserve initrd memory if needed.
	 */
	finalize_initrd();
}
#endif  /* !CONFIG_NUMA    */
#endif	/* CONFIG_SGI_IP27 */

/*
 * arch_mem_init - initialize memory managment subsystem
 *
 *  o plat_mem_setup() detects the memory configuration and will record detected
 *    memory areas using add_memory_region.
 *
 * At this stage the memory configuration of the system is known to the
 * kernel but generic memory managment system is still entirely uninitialized.
 *
 *  o bootmem_init()
 *  o sparse_init()
 *  o paging_init()
 *
 * At this stage the bootmem allocator is ready to use.
 *
 * NOTE: historically plat_mem_setup did the entire platform initialization.
 *       This was rather impractical because it meant plat_mem_setup had to
 * get away without any kind of memory allocator.  To keep old code from
 * breaking plat_setup was just renamed to plat_setup and a second platform
 * initialization hook for anything else was introduced.
 */

static int usermem __initdata = 0;

static int __init early_parse_mem(char *p)
{
	unsigned long start, size;

	/*
	 * If a user specifies memory size, we
	 * blow away any automatically generated
	 * size.
	 */
	if (usermem == 0) {
		boot_mem_map.nr_map = 0;
		usermem = 1;
 	}
	start = 0;
	size = memparse(p, &p);
	if (*p == '@')
		start = memparse(p + 1, &p);
#ifdef CONFIG_NUMA
	{
		int nid;
		if (*p == '@')
			nid = simple_strtoul(p + 1, &p, 0);
		else
			nid = 0;
		printk("parse: nid %d\n\n\n", nid);
		add_memory_region_node(start, size, nid, BOOT_MEM_RAM);
	}
#else
	add_memory_region(start, size, BOOT_MEM_RAM);
#endif
	return 0;
}
early_param("mem", early_parse_mem);

static void __init arch_mem_init(char **cmdline_p)
{
	extern void plat_mem_setup(void);
#ifdef CONFIG_SNSC_BOOTINFO
	unsigned long kernelbase = (unsigned long)&_text;
	unsigned long offset = (unsigned long)fw_arg3;

	parse_bootinfo_early((struct bi_record *)(kernelbase + offset));
#endif
	/* call board setup routine */
	plat_mem_setup();

#ifdef CONFIG_SNSC_BOOTINFO
	parse_bootinfo((struct bi_record *)(kernelbase + offset));
#endif
	printk("Determined physical RAM map:\n");
	print_memory_map();

	strlcpy(command_line, arcs_cmdline, sizeof(command_line));
#ifdef CONFIG_SNSC_USE_ADDITIONAL_KERNEL_CMDLINE
	strcat(command_line, " ");
	strncat(command_line,
		additional_boot_command_line,
		SNSC_ADDITIONAL_COMMAND_LINE_SIZE);
	strlcpy(boot_command_line,
		command_line,
		COMMAND_LINE_SIZE + SNSC_ADDITIONAL_COMMAND_LINE_SIZE);
#else
	strlcpy(boot_command_line, command_line, COMMAND_LINE_SIZE);
#endif

	*cmdline_p = command_line;

	parse_early_param();

	if (usermem) {
		printk("User-defined physical RAM map:\n");
		print_memory_map();
	}

	bootmem_init();
#ifdef CONFIG_SNSC_UMA
	snsc_uma_init();
#endif
#ifdef CONFIG_SNSC_NBLARGS
	printk("NBLArgs: added %d entry.\n", nblargs_init());
#endif
#ifdef CONFIG_SNSC_BOOT_TIME
	boot_time_init();
	BOOT_TIME_ADD();
#endif
	paging_init();
}

static void __init resource_init(void)
{
	int i;

	if (UNCAC_BASE != IO_BASE)
		return;

	code_resource.start = __pa_symbol(&_text);
	code_resource.end = __pa_symbol(&_etext) - 1;
	data_resource.start = __pa_symbol(&_etext);
	data_resource.end = __pa_symbol(&_edata) - 1;

	/*
	 * Request address space for all standard RAM.
	 */
	for (i = 0; i < boot_mem_map.nr_map; i++) {
		struct resource *res;
		unsigned long start, end;

		start = boot_mem_map.map[i].addr;
		end = boot_mem_map.map[i].addr + boot_mem_map.map[i].size - 1;
		if (start >= HIGHMEM_START)
			continue;
		if (end >= HIGHMEM_START)
			end = HIGHMEM_START - 1;

		res = alloc_bootmem(sizeof(struct resource));
		switch (boot_mem_map.map[i].type) {
		case BOOT_MEM_RAM:
		case BOOT_MEM_ROM_DATA:
			res->name = "System RAM";
			break;
		case BOOT_MEM_RESERVED:
		default:
			res->name = "reserved";
		}

		res->start = start;
		res->end = end;

		res->flags = IORESOURCE_MEM | IORESOURCE_BUSY;
		request_resource(&iomem_resource, res);

		/*
		 *  We don't know which RAM region contains kernel data,
		 *  so we try it repeatedly and let the resource manager
		 *  test it.
		 */
		request_resource(res, &code_resource);
		request_resource(res, &data_resource);
	}
}

void __init setup_arch(char **cmdline_p)
{
	cpu_probe();
	prom_init();

#ifdef CONFIG_EARLY_PRINTK
	{
		extern void setup_early_printk(void);

		setup_early_printk();
	}
#endif
	cpu_report();

#if defined(CONFIG_VT)
#if defined(CONFIG_VGA_CONSOLE)
	conswitchp = &vga_con;
#elif defined(CONFIG_DUMMY_CONSOLE)
	conswitchp = &dummy_con;
#endif
#endif

	arch_mem_init(cmdline_p);

	resource_init();
#ifdef CONFIG_SMP
	plat_smp_setup();
#endif
}

static int __init fpu_disable(char *s)
{
	int i;

	for (i = 0; i < NR_CPUS; i++)
		cpu_data[i].options &= ~MIPS_CPU_FPU;

	return 1;
}

__setup("nofpu", fpu_disable);

static int __init dsp_disable(char *s)
{
	cpu_data[0].ases &= ~MIPS_ASE_DSP;

	return 1;
}

__setup("nodsp", dsp_disable);

unsigned long kernelsp[NR_CPUS];
unsigned long fw_arg0, fw_arg1, fw_arg2, fw_arg3;

#ifdef CONFIG_DEBUG_FS
struct dentry *mips_debugfs_dir;
static int __init debugfs_mips(void)
{
	struct dentry *d;

	d = debugfs_create_dir("mips", NULL);
	if (IS_ERR(d))
		return PTR_ERR(d);
	mips_debugfs_dir = d;
	return 0;
}
arch_initcall(debugfs_mips);
#endif

#ifdef CONFIG_EXCEPTION_MONITOR
int exception_check_mode = 3;
static int __init set_exception_check(char *str)
{
	get_option(&str, &exception_check_mode);
	return 1;
}
__setup("em=", set_exception_check);
void (*exception_check)(int mode, struct pt_regs *regs) = NULL;
EXPORT_SYMBOL(exception_check);
#endif

#ifdef CONFIG_SNSC_BOOTINFO
void __init parse_bootinfo_early(struct bi_record *rec)
{
	if (rec == NULL || rec->tag != BI_FIRST)
		return;
	while (rec->tag != BI_LAST) {
		ulong *data;
		data = rec->data;
		switch (rec->tag) {
#ifdef CONFIG_SNSC_USE_TARGETID_FROM_NBL
		case BI_MACHTYPE:
			snsc_set_mips_machtype(data);
			break;
#endif
		}
		rec = (struct bi_record *)((ulong)rec + rec->size);
	}
}

void __init parse_bootinfo(struct bi_record *rec)
{
#ifdef CONFIG_BLK_DEV_INITRD
	initrd_start = 0;
	initrd_end = 0;
#endif
	if (rec == NULL || rec->tag != BI_FIRST)
		return;
	while (rec->tag != BI_LAST) {
		ulong *data = rec->data;
		switch (rec->tag) {
		case BI_CMD_LINE:
			strlcpy(arcs_cmdline, (void *)data, CL_SIZE);
			break;
#ifdef CONFIG_BLK_DEV_INITRD
		case BI_INITRD:
			initrd_start = data[0];
			initrd_end = data[0] + data[1];
			break;
#endif
		case BI_MEMSIZE:
			/* remove all memory region */
			boot_mem_map.nr_map = 0;
			/* add new memory region */
			add_memory_region(0, data[0], BOOT_MEM_RAM);
			break;
#ifdef CONFIG_SNSC_MACADDR
		case BI_MACADDR:
			snsc_macaddr_init((u8 *)data,
					  rec->size - sizeof(struct bi_record));
			break;
#endif
		}
		rec = (struct bi_record *)((ulong)rec + rec->size);
	}
}
#endif	/* CONFIG_SNSC_BOOTINFO */
