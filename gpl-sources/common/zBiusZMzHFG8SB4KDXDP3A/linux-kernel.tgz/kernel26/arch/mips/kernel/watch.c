/* 2010-11-04: File changed by Sony Corporation */
/*
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 *
 * Copyright (C) 2008 David Daney
 */

#include <linux/sched.h>

#include <asm/processor.h>
#include <asm/watch.h>

#ifdef CONFIG_SNSC_MIPS_WATCHPOINT_DEBUG
#include <linux/smp_lock.h>
#include <linux/mm.h>
#include <linux/highmem.h>
#include <linux/pagemap.h>
#include <asm/uaccess.h>

/*
 * Watchpoint operations
 */
#define WATCHPOINT_PHYSADDR_NONE	-1UL

static int (*get_watchpoint)(struct task_struct *task, int idx,
			     unsigned long *virt, unsigned long *phys,
			     unsigned int *mode);
static int (*set_watchpoint)(struct task_struct *task, int idx,
			     unsigned long virt, unsigned long phys,
			     unsigned int mode);
static int (*clear_watchpoint)(struct task_struct *task, int idx);

/*
 * Utility functions
 */
static unsigned long
get_physaddr_user(struct task_struct *task, unsigned long virt)
{
	unsigned long phys = WATCHPOINT_PHYSADDR_NONE;
	struct mm_struct *mm;
	struct page *page;
	int off, ret;

	mm = get_task_mm(task);
	if (!mm) {
		return phys;
	}

	/* get physical address with creating mappings */
	down_read(&mm->mmap_sem);
	ret = get_user_pages(task, mm, virt, 1, 1, 0, &page, NULL);
	if (ret > 0) {
		off = virt & (PAGE_SIZE - 1);
		phys = PFN_PHYS(page_to_pfn(page)) + off;
		put_page(page);
	}
	up_read(&mm->mmap_sem);
	mmput(mm);

	return phys;
}

static unsigned long
get_physaddr_pte(struct task_struct *task, unsigned long virt)
{
	unsigned long phys = WATCHPOINT_PHYSADDR_NONE;
	pgd_t *pgd;
	pud_t *pud;
	pmd_t *pmd;
	pte_t *pte;

	/* get mapped physical address from page table */
	pgd = pgd_offset(task->mm, virt);
	if (pgd_none(*pgd)) {
		return phys;
	}
	pud = pud_offset(pgd, virt);
	if (pud_none(*pud)) {
		return phys;
	}
	pmd = pmd_offset(pud, virt);
	if (!pmd_present(*pmd)) {
		return phys;
	}
	pte = pte_offset(pmd, virt);
	if (!pte) {
		return phys;
	}
	if (pte_none(*pte)) {
		return phys;
	}
	phys = PFN_PHYS(pte_pfn(*pte));

	return phys;
}

/*
 * Watchpoint operations for MIPS32/MIPS64
 */
static int
mips3264_get_watchpoint(struct task_struct *task, int idx, unsigned long *virt,
			unsigned long *phys, unsigned int *mode)
{
	unsigned long watchlo;

	watchlo = task->thread.watch.mips3264.watchlo[idx];

	/* return watchpoint settings */
	*virt = watchlo & ~0x7;
	*phys = WATCHPOINT_PHYSADDR_NONE;
	*mode = ((!!(watchlo & (1 << 0)) ? WATCHPOINT_MODE_WRITE : 0) |
		 (!!(watchlo & (1 << 1)) ? WATCHPOINT_MODE_READ  : 0) |
		 (!!(watchlo & (1 << 2)) ? WATCHPOINT_MODE_EXEC  : 0));

	return 0;
}

static int
mips3264_set_watchpoint(struct task_struct *task, int idx, unsigned long virt,
			unsigned long phys, unsigned int mode)
{
	int enable;

	/* set watchpoint */
	enable = (((mode & WATCHPOINT_MODE_WRITE) ? (1 << 0) : 0) |
		  ((mode & WATCHPOINT_MODE_READ)  ? (1 << 1) : 0) |
		  ((mode & WATCHPOINT_MODE_EXEC)  ? (1 << 2) : 0));
	task->thread.watch.mips3264.watchlo[idx] = (virt & ~0x7) | enable;
	task->thread.watch.mips3264.watchhi[idx] = 0;

	return 0;
}

static int
mips3264_clear_watchpoint(struct task_struct *task, int idx)
{
	int i;

	/* clear watchpoint */
	task->thread.watch.mips3264.watchlo[idx] = 0;
	task->thread.watch.mips3264.watchhi[idx] = 0;

	/* check if other watchpoints are set */
	for (i = 0; i < current_cpu_data.watch_reg_use_cnt; i++) {
		if (task->thread.watch.mips3264.watchlo[i] & 0x7) {
			return 1;
		}
	}
	return 0;
}

/*
 * Watchpoint operations for r9721
 */
static int
r9721_get_watchpoint(struct task_struct *task, int idx, unsigned long *virt,
		     unsigned long *phys, unsigned int *mode)
{
	u32 watchlo;

	/* return watchpoint settings */
	watchlo = task->thread.watch.r9721.watchlo;
	*virt = task->thread.watch.r9721.watchvirt;
	*phys = watchlo & ~0x7;
	*mode = ((!!(watchlo & (1 << 0)) ? WATCHPOINT_MODE_WRITE : 0) |
		 (!!(watchlo & (1 << 1)) ? WATCHPOINT_MODE_READ  : 0));

	return 0;
}

static int
r9721_set_watchpoint(struct task_struct *task, int idx, unsigned long virt,
		     unsigned long phys, unsigned int mode)
{
	int enable;

	/* get physical address if not given */
	if (phys == WATCHPOINT_PHYSADDR_NONE) {
		phys = get_physaddr_user(task, virt);
		if (phys == WATCHPOINT_PHYSADDR_NONE) {
			phys = get_physaddr_pte(task, virt);
			if (phys == WATCHPOINT_PHYSADDR_NONE) {
				return -EFAULT;
			}
		}
	}

	/* set watchpoint */
	enable = (((mode & WATCHPOINT_MODE_WRITE) ? (1 << 0) : 0) |
		  ((mode & WATCHPOINT_MODE_READ)  ? (1 << 1) : 0));
	task->thread.watch.r9721.watchvirt = virt;
	task->thread.watch.r9721.watchlo = (phys & ~0x7) | enable;
	task->thread.watch.r9721.watchhi = 0;

	return 0;
}

static int
r9721_clear_watchpoint(struct task_struct *task, int idx)
{
	/* clear watchpoint */
	task->thread.watch.r9721.watchvirt = 0;
	task->thread.watch.r9721.watchlo = 0;
	task->thread.watch.r9721.watchhi = 0;

	return 0;
}

/*
 * Exported watchpoint operations
 */
int
mips_get_watchpoint(struct task_struct *task, int idx, unsigned long *virt,
		    unsigned int *mode)
{
	unsigned long phys;
	int ret;

	/* sanity check */
	if (idx >= current_cpu_data.watch_reg_use_cnt) {
		return -EINVAL;
	}

	/* check if installed */
	if (!test_tsk_thread_flag(task, TIF_LOAD_WATCH)) {
		return -ENOENT;
	}

	/* get watchpoint */
	lock_kernel();
	ret = get_watchpoint(task, idx, virt, &phys, mode);
	unlock_kernel();

	return ret;
}

int
mips_set_watchpoint(struct task_struct *task, int idx, unsigned long virt,
		    unsigned int mode)
{
	int ret;

	/* sanity check */
	if (idx >= current_cpu_data.watch_reg_use_cnt) {
		return -EINVAL;
	}
	if (!mode) {
		return 0;
	}

	/* check address */
#ifdef CONFIG_32BIT
	if (virt & __UA_LIMIT) {
		return -EFAULT;
	}
#else
	if (test_tsk_thread_flag(task, TIF_32BIT_ADDR)) {
		if (virt & 0xffffffff80000000UL)
			return -EFAULT;
	} else {
		if (virt & __UA_LIMIT)
			return -EFAULT;
	}
#endif
	/* set watchpoint */
	lock_kernel();
	ret = set_watchpoint(task, idx, virt, WATCHPOINT_PHYSADDR_NONE, mode);
	if (!ret) {
		set_tsk_thread_flag(task, TIF_LOAD_WATCH);
		mips_install_watch_registers();
	}
	unlock_kernel();

	return ret;
}

int
mips_clear_watchpoint(struct task_struct *task, int idx)
{
	int active;

	/* sanity check */
	if (idx >= current_cpu_data.watch_reg_use_cnt) {
		return -EINVAL;
	}

	/* clear watchpoint */
	lock_kernel();
	active = clear_watchpoint(task, idx);
	if (!active) {
		clear_tsk_thread_flag(task, TIF_LOAD_WATCH);
	}
	mips_install_watch_registers();
	unlock_kernel();

	return 0;
}

void
mips_dump_watchpoint(struct task_struct *task)
{
	unsigned long virt, phys;
	unsigned int mode;
	int idx, ret = 0;

	/* show all watchpoints */
	lock_kernel();
	printk("Watchpoints:\n");
	for (idx = 0; idx < current_cpu_data.watch_reg_use_cnt; idx++) {
		ret = get_watchpoint(task, idx, &virt, &phys, &mode);
		if (ret < 0) {
			break;
		}
		if (mode) {
			char str[32] = " ";
			if (phys != WATCHPOINT_PHYSADDR_NONE) {
				sprintf(str, ", phys=0x%08lx ", phys);
			}
			printk("  #%d: virt=0x%08lx%s%s%s%s\n", idx, virt, str,
			       (mode & WATCHPOINT_MODE_READ)  ? "[read]"  : "",
			       (mode & WATCHPOINT_MODE_WRITE) ? "[write]" : "",
			       (mode & WATCHPOINT_MODE_EXEC)  ? "[exec]"  : "");
		} else {
			printk("  #%d: disabled\n", idx);
		}
	}
	unlock_kernel();
}

void
mips_disable_watchpoint(void)
{
	/* disable watchpoint */
	lock_kernel();
	mips_clear_watch_registers();
	unlock_kernel();
}

void
mips_update_watchpoint(unsigned long curr_virt)
{
	struct task_struct *g, *p;
	unsigned long curr_phys, watch_virt, watch_phys;
	unsigned int mode;
	int eq_virt, eq_phys;
	int idx, ret = 0;

	/* check if watchpoint is enabled */
	if (!test_tsk_thread_flag(current, TIF_LOAD_WATCH)) {
		return;
	}

	/* get mapped physical address */
	curr_phys = get_physaddr_pte(current, curr_virt);
	if (curr_phys == WATCHPOINT_PHYSADDR_NONE) {
		return;
	}

	/* update watchpoints */
	lock_kernel();
	read_lock(&tasklist_lock);
	do_each_thread(g, p) {
		if (p->mm != current->mm) {
			continue;
		}
		for (idx = 0; idx < current_cpu_data.watch_reg_use_cnt; idx++) {
			/* get current watchpoint */
			ret = get_watchpoint(p, idx, &watch_virt, &watch_phys,
					     &mode);
			if (ret < 0) {
				break;
			}
			/* check if mapping is changed */
			eq_virt = PFN_DOWN(watch_virt) == PFN_DOWN(curr_virt);
			eq_phys = PFN_DOWN(watch_phys) == PFN_DOWN(curr_phys);
			if (eq_virt && !eq_phys) {
				/* update watchpoint with new mapping */
				set_watchpoint(p, idx, watch_virt, curr_phys,
					       mode);
			} else if (!eq_virt && eq_phys) {
				/* disable watchpoint */
				clear_watchpoint(p, idx);
			}
		}
	} while_each_thread(g, p);
	read_unlock(&tasklist_lock);
	mips_install_watch_registers();
	unlock_kernel();

	return;
}
#endif

/*
 * Watch register operations
 */
void (*mips_install_watch_registers)(void);
void (*mips_read_watch_registers)(void);
void (*mips_clear_watch_registers)(void);

/*
 * Watch register operations for MIPS32/MIPS64
 */
/*
 * Install the watch registers for the current thread.  A maximum of
 * four registers are installed although the machine may have more.
 */
static void
mips3264_install_watch_registers(void)
{
	struct mips3264_watch_reg_state *watches =
		&current->thread.watch.mips3264;
	switch (current_cpu_data.watch_reg_use_cnt) {
	default:
		BUG();
	case 4:
		write_c0_watchlo3(watches->watchlo[3]);
		/* Write 1 to the I, R, and W bits to clear them, and
		   1 to G so all ASIDs are trapped. */
		write_c0_watchhi3(0x40000007 | watches->watchhi[3]);
	case 3:
		write_c0_watchlo2(watches->watchlo[2]);
		write_c0_watchhi2(0x40000007 | watches->watchhi[2]);
	case 2:
		write_c0_watchlo1(watches->watchlo[1]);
		write_c0_watchhi1(0x40000007 | watches->watchhi[1]);
	case 1:
		write_c0_watchlo0(watches->watchlo[0]);
		write_c0_watchhi0(0x40000007 | watches->watchhi[0]);
	}
}

/*
 * Read back the watchhi registers so the user space debugger has
 * access to the I, R, and W bits.  A maximum of four registers are
 * read although the machine may have more.
 */
static void
mips3264_read_watch_registers(void)
{
	struct mips3264_watch_reg_state *watches =
		&current->thread.watch.mips3264;
	switch (current_cpu_data.watch_reg_use_cnt) {
	default:
		BUG();
	case 4:
		watches->watchhi[3] = (read_c0_watchhi3() & 0x0fff);
	case 3:
		watches->watchhi[2] = (read_c0_watchhi2() & 0x0fff);
	case 2:
		watches->watchhi[1] = (read_c0_watchhi1() & 0x0fff);
	case 1:
		watches->watchhi[0] = (read_c0_watchhi0() & 0x0fff);
	}
	if (current_cpu_data.watch_reg_use_cnt == 1 &&
	    (watches->watchhi[0] & 7) == 0) {
		/* Pathological case of release 1 architecture that
		 * doesn't set the condition bits.  We assume that
		 * since we got here, the watch condition was met and
		 * signal that the conditions requested in watchlo
		 * were met.  */
		watches->watchhi[0] |= (watches->watchlo[0] & 7);
	}
 }

/*
 * Disable all watch registers.  Although only four registers are
 * installed, all are cleared to eliminate the possibility of endless
 * looping in the watch handler.
 */
static void
mips3264_clear_watch_registers(void)
{
	switch (current_cpu_data.watch_reg_count) {
	default:
		BUG();
	case 8:
		write_c0_watchlo7(0);
	case 7:
		write_c0_watchlo6(0);
	case 6:
		write_c0_watchlo5(0);
	case 5:
		write_c0_watchlo4(0);
	case 4:
		write_c0_watchlo3(0);
	case 3:
		write_c0_watchlo2(0);
	case 2:
		write_c0_watchlo1(0);
	case 1:
		write_c0_watchlo0(0);
	}
}

/*
 * Watch register probe routine for MIPS32/MIPS64
 */
__cpuinit void
watch_probe_mips3264(struct cpuinfo_mips *c)
{
	unsigned int t;

	if ((c->options & MIPS_CPU_WATCH) == 0)
		return;

	/* Setup watch register operations */
	mips_install_watch_registers = mips3264_install_watch_registers;
	mips_read_watch_registers    = mips3264_read_watch_registers;
	mips_clear_watch_registers   = mips3264_clear_watch_registers;

#ifdef CONFIG_SNSC_MIPS_WATCHPOINT_DEBUG
	/* Setup watchpoint operations */
	get_watchpoint   = mips3264_get_watchpoint;
	set_watchpoint   = mips3264_set_watchpoint;
	clear_watchpoint = mips3264_clear_watchpoint;
#endif
	/*
	 * Check which of the I,R and W bits are supported, then
	 * disable the register.
	 */
	write_c0_watchlo0(7);
	t = read_c0_watchlo0();
	write_c0_watchlo0(0);
	c->watch_reg_masks[0] = t & 7;

	/* Write the mask bits and read them back to determine which
	 * can be used. */
	c->watch_reg_count = 1;
	c->watch_reg_use_cnt = 1;
	t = read_c0_watchhi0();
	write_c0_watchhi0(t | 0xff8);
	t = read_c0_watchhi0();
	c->watch_reg_masks[0] |= (t & 0xff8);
	if ((t & 0x80000000) == 0)
		return;

	write_c0_watchlo1(7);
	t = read_c0_watchlo1();
	write_c0_watchlo1(0);
	c->watch_reg_masks[1] = t & 7;

	c->watch_reg_count = 2;
	c->watch_reg_use_cnt = 2;
	t = read_c0_watchhi1();
	write_c0_watchhi1(t | 0xff8);
	t = read_c0_watchhi1();
	c->watch_reg_masks[1] |= (t & 0xff8);
	if ((t & 0x80000000) == 0)
		return;

	write_c0_watchlo2(7);
	t = read_c0_watchlo2();
	write_c0_watchlo2(0);
	c->watch_reg_masks[2] = t & 7;

	c->watch_reg_count = 3;
	c->watch_reg_use_cnt = 3;
	t = read_c0_watchhi2();
	write_c0_watchhi2(t | 0xff8);
	t = read_c0_watchhi2();
	c->watch_reg_masks[2] |= (t & 0xff8);
	if ((t & 0x80000000) == 0)
		return;

	write_c0_watchlo3(7);
	t = read_c0_watchlo3();
	write_c0_watchlo3(0);
	c->watch_reg_masks[3] = t & 7;

	c->watch_reg_count = 4;
	c->watch_reg_use_cnt = 4;
	t = read_c0_watchhi3();
	write_c0_watchhi3(t | 0xff8);
	t = read_c0_watchhi3();
	c->watch_reg_masks[3] |= (t & 0xff8);
	if ((t & 0x80000000) == 0)
		return;

	/* We use at most 4, but probe and report up to 8. */
	c->watch_reg_count = 5;
	t = read_c0_watchhi4();
	if ((t & 0x80000000) == 0)
		return;

	c->watch_reg_count = 6;
	t = read_c0_watchhi5();
	if ((t & 0x80000000) == 0)
		return;

	c->watch_reg_count = 7;
	t = read_c0_watchhi6();
	if ((t & 0x80000000) == 0)
		return;

	c->watch_reg_count = 8;
}

/*
 * Watch register operations for r9721
 */
static void
r9721_install_watch_registers(void)
{
	struct r9721_watch_reg_state *watches =
		&current->thread.watch.r9721;

	write_c0_watchlo0(watches->watchlo);
	write_c0_watchhi0(watches->watchhi);
}

static void
r9721_read_watch_registers(void)
{
	struct r9721_watch_reg_state *watches =
		&current->thread.watch.r9721;

	watches->watchhi = read_c0_watchhi0();
 }

static void
r9721_clear_watch_registers(void)
{
	write_c0_watchlo0(0);
}

/*
 * Watch register probe routine for r9721
 */
__cpuinit void
watch_probe_r9721(struct cpuinfo_mips *c)
{
	if ((c->options & MIPS_CPU_WATCH) == 0)
		return;

	c->watch_reg_count = 1;
	c->watch_reg_use_cnt = 1;
	c->options |= MIPS_CPU_WATCH_PHYS;

	mips_install_watch_registers = r9721_install_watch_registers;
	mips_read_watch_registers    = r9721_read_watch_registers;
	mips_clear_watch_registers   = r9721_clear_watch_registers;

#ifdef CONFIG_SNSC_MIPS_WATCHPOINT_DEBUG
	get_watchpoint   = r9721_get_watchpoint;
	set_watchpoint   = r9721_set_watchpoint;
	clear_watchpoint = r9721_clear_watchpoint;
#endif
}
