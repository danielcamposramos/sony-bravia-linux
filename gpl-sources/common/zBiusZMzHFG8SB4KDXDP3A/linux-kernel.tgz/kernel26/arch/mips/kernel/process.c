/* 2010-12-14: File changed by Sony Corporation */
/*
 * This file is subject to the terms and conditions of the GNU General Public
 * License.  See the file "COPYING" in the main directory of this archive
 * for more details.
 *
 * Copyright (C) 1994 - 1999, 2000 by Ralf Baechle and others.
 * Copyright (C) 2005, 2006 by Ralf Baechle (ralf@linux-mips.org)
 * Copyright (C) 1999, 2000 Silicon Graphics, Inc.
 * Copyright (C) 2004 Thiemo Seufer
 */
#include <linux/errno.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/tick.h>
#include <linux/kernel.h>
#include <linux/mm.h>
#include <linux/stddef.h>
#include <linux/unistd.h>
#include <linux/ptrace.h>
#include <linux/slab.h>
#include <linux/mman.h>
#include <linux/personality.h>
#include <linux/sys.h>
#include <linux/user.h>
#include <linux/a.out.h>
#include <linux/init.h>
#include <linux/completion.h>
#include <linux/kallsyms.h>
#include <linux/random.h>

#include <asm/asm.h>
#include <asm/bootinfo.h>
#include <asm/cpu.h>
#include <asm/dsp.h>
#include <asm/fpu.h>
#include <asm/pgtable.h>
#include <asm/system.h>
#include <asm/mipsregs.h>
#include <asm/processor.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <asm/elf.h>
#include <asm/isadep.h>
#include <asm/inst.h>
#include <asm/stacktrace.h>

#ifdef CONFIG_SNSC_LED_DEBUG
#include <asm/snsc/leds.h>
#endif
#ifdef CONFIG_SNSC_ALT_BACKTRACE
#include <linux/fs.h>
#include <linux/file.h>
#include <linux/snsc_backtrace.h>
#include <asm/unaligned.h>
#endif

/*
 * The idle thread. There's no useful work to be done, so just try to conserve
 * power and have a low exit latency (ie sit in a loop waiting for somebody to
 * say that they'd like to reschedule)
 */
void __noreturn cpu_idle(void)
{
	/* endless idle loop with no priority at all */
	while (1) {
		tick_nohz_stop_sched_tick();
#ifdef CONFIG_SNSC_LED_DEBUG
		leds_event(led_idle_start);
#endif
		while (!need_resched()) {
#ifdef CONFIG_SMTC_IDLE_HOOK_DEBUG
			extern void smtc_idle_loop_hook(void);

			smtc_idle_loop_hook();
#endif
			if (cpu_wait)
				(*cpu_wait)();
		}
#ifdef CONFIG_SNSC_LED_DEBUG
		leds_event(led_idle_end);
#endif
		tick_nohz_restart_sched_tick();
		preempt_enable_no_resched();
		schedule();
		preempt_disable();
	}
}

asmlinkage void ret_from_fork(void);

void start_thread(struct pt_regs * regs, unsigned long pc, unsigned long sp)
{
	unsigned long status;

	/* New thread loses kernel privileges. */
	status = regs->cp0_status & ~(ST0_CU0|ST0_CU1|KU_MASK);
#ifdef CONFIG_64BIT
	status &= ~ST0_FR;
	status |= test_thread_flag(TIF_32BIT_REGS) ? 0 : ST0_FR;
#endif
#ifdef CONFIG_CP0_FROM_USER
	status |= ST0_CU0 ;
#endif
	status |= KU_USER;
	regs->cp0_status = status;
	clear_used_math();
	clear_fpu_owner();
	if (cpu_has_dsp)
		__init_dsp();
	regs->cp0_epc = pc;
	regs->regs[29] = sp;
	current_thread_info()->addr_limit = USER_DS;
}

void exit_thread(void)
{
}

void flush_thread(void)
{
}

int copy_thread(int nr, unsigned long clone_flags, unsigned long usp,
	unsigned long unused, struct task_struct *p, struct pt_regs *regs)
{
	struct thread_info *ti = task_thread_info(p);
	struct pt_regs *childregs;
	long childksp;
	p->set_child_tid = p->clear_child_tid = NULL;

	childksp = (unsigned long)task_stack_page(p) + THREAD_SIZE - 32;

	preempt_disable();

	if (is_fpu_owner())
		save_fp(p);

	if (cpu_has_dsp)
		save_dsp(p);

	preempt_enable();

	/* set up new TSS. */
	childregs = (struct pt_regs *) childksp - 1;
	*childregs = *regs;
	childregs->regs[7] = 0;	/* Clear error flag */

#if defined(CONFIG_BINFMT_IRIX)
	if (current->personality != PER_LINUX) {
		/* Under IRIX things are a little different. */
		childregs->regs[3] = 1;
		regs->regs[3] = 0;
	}
#endif
	childregs->regs[2] = 0;	/* Child gets zero as return value */
	regs->regs[2] = p->pid;

#ifdef CONFIG_CP0_FROM_USER
	if (! (childregs->cp0_status & KU_USER)) {
#else
	if (childregs->cp0_status & ST0_CU0) {
#endif
		childregs->regs[28] = (unsigned long) ti;
		childregs->regs[29] = childksp;
		ti->addr_limit = KERNEL_DS;
	} else {
		childregs->regs[29] = usp;
		ti->addr_limit = USER_DS;
	}
	p->thread.reg29 = (unsigned long) childregs;
	p->thread.reg31 = (unsigned long) ret_from_fork;

	/*
	 * New tasks lose permission to use the fpu. This accelerates context
	 * switching for most programs since they don't use the fpu.
	 */
	p->thread.cp0_status = read_c0_status() & ~(ST0_CU2|ST0_CU1);
	childregs->cp0_status &= ~(ST0_CU2|ST0_CU1);
	clear_tsk_thread_flag(p, TIF_USEDFPU);

#ifdef CONFIG_MIPS_MT_FPAFF
	/*
	 * FPU affinity support is cleaner if we track the
	 * user-visible CPU affinity from the very beginning.
	 * The generic cpus_allowed mask will already have
	 * been copied from the parent before copy_thread
	 * is invoked.
	 */
	p->thread.user_cpus_allowed = p->cpus_allowed;
#endif /* CONFIG_MIPS_MT_FPAFF */

	if (clone_flags & CLONE_SETTLS)
		ti->tp_value = regs->regs[7];

#ifdef CONFIG_HARDWARE_WATCHPOINTS
	/* clear watchpoints if VM is not shared between processes */
	if (!(clone_flags & CLONE_VM)) {
		memset(&p->thread.watch, 0, sizeof(union mips_watch_reg_state));
		clear_tsk_thread_flag(p, TIF_LOAD_WATCH);
	}
#endif

	return 0;
}

/* Fill in the fpu structure for a core dump.. */
int dump_fpu(struct pt_regs *regs, elf_fpregset_t *r)
{
	memcpy(r, &current->thread.fpu, sizeof(current->thread.fpu));

	return 1;
}

void elf_dump_regs(elf_greg_t *gp, struct pt_regs *regs)
{
	int i;

	for (i = 0; i < EF_R0; i++)
		gp[i] = 0;
	gp[EF_R0] = 0;
	for (i = 1; i <= 31; i++)
		gp[EF_R0 + i] = regs->regs[i];
	gp[EF_R26] = 0;
	gp[EF_R27] = 0;
	gp[EF_LO] = regs->lo;
	gp[EF_HI] = regs->hi;
	gp[EF_CP0_EPC] = regs->cp0_epc;
	gp[EF_CP0_BADVADDR] = regs->cp0_badvaddr;
	gp[EF_CP0_STATUS] = regs->cp0_status;
	gp[EF_CP0_CAUSE] = regs->cp0_cause;
#ifdef EF_UNUSED0
	gp[EF_UNUSED0] = 0;
#endif
}

int dump_task_regs (struct task_struct *tsk, elf_gregset_t *regs)
{
	elf_dump_regs(*regs, task_pt_regs(tsk));
	return 1;
}

int dump_task_fpu (struct task_struct *t, elf_fpregset_t *fpr)
{
	memcpy(fpr, &t->thread.fpu, sizeof(current->thread.fpu));

	return 1;
}

/*
 * Create a kernel thread
 */
static void __noreturn __noinstrument kernel_thread_helper(void *arg, int (*fn)(void *))
{
	do_exit(fn(arg));
}

long kernel_thread(int (*fn)(void *), void *arg, unsigned long flags)
{
	struct pt_regs regs;
	long pid;

	memset(&regs, 0, sizeof(regs));

	regs.regs[4] = (unsigned long) arg;
	regs.regs[5] = (unsigned long) fn;
	regs.cp0_epc = (unsigned long) kernel_thread_helper;
	regs.cp0_status = read_c0_status();
#if defined(CONFIG_CPU_R3000) || defined(CONFIG_CPU_TX39XX)
	regs.cp0_status &= ~(ST0_KUP | ST0_IEC);
	regs.cp0_status |= ST0_IEP;
#else
	regs.cp0_status |= ST0_EXL;
#endif

	/* Ok, create the new process.. */
	pid = do_fork(flags | CLONE_VM | CLONE_UNTRACED,
			0, &regs, 0, NULL, NULL);
	trace_mark(kernel_arch_kthread_create, "pid %ld fn %p", pid, fn);
	return pid;
}

/*
 *
 */
struct mips_frame_info {
	void		*func;
	unsigned long	func_size;
	int		frame_size;
	int		pc_offset;
};

static inline int is_ra_save_ins(union mips_instruction *ip)
{
	/* sw / sd $ra, offset($sp) */
	return (ip->i_format.opcode == sw_op || ip->i_format.opcode == sd_op) &&
		ip->i_format.rs == 29 &&
		ip->i_format.rt == 31;
}

static inline int is_jal_jalr_jr_ins(union mips_instruction *ip)
{
	if (ip->j_format.opcode == jal_op)
		return 1;
	if (ip->r_format.opcode != spec_op)
		return 0;
	return ip->r_format.func == jalr_op || ip->r_format.func == jr_op;
}

static inline int is_sp_move_ins(union mips_instruction *ip)
{
	/* addiu/daddiu sp,sp,-imm */
	if (ip->i_format.rs != 29 || ip->i_format.rt != 29)
		return 0;
	if (ip->i_format.opcode == addiu_op || ip->i_format.opcode == daddiu_op)
		return 1;
	return 0;
}

static int get_frame_info(struct mips_frame_info *info)
{
	union mips_instruction *ip = info->func;
	unsigned max_insns = info->func_size / sizeof(union mips_instruction);
	unsigned i;

	info->pc_offset = -1;
	info->frame_size = 0;

	if (!ip)
		goto err;

	if (max_insns == 0)
		max_insns = 128U;	/* unknown function size */
	max_insns = min(128U, max_insns);

	for (i = 0; i < max_insns; i++, ip++) {

		if (is_jal_jalr_jr_ins(ip))
			break;
		if (!info->frame_size) {
			if (is_sp_move_ins(ip))
				info->frame_size = - ip->i_format.simmediate;
			continue;
		}
		if (info->pc_offset == -1 && is_ra_save_ins(ip)) {
			info->pc_offset =
				ip->i_format.simmediate / sizeof(long);
			break;
		}
	}
	if (info->frame_size && info->pc_offset >= 0) /* nested */
		return 0;
	if (info->pc_offset < 0) /* leaf */
		return 1;
	/* prologue seems boggus... */
err:
	return -1;
}

#ifdef CONFIG_SNSC_ALT_BACKTRACE
#define bt_get_user_aligned(dest, ptr) \
   (((unsigned long)(ptr) & (sizeof(int) - 1)) ? -1 : get_user(dest, ptr))

static int get_frame_info_alt(struct mips_frame_info *info)
{
	union mips_instruction *ip = info->func;
	unsigned max_insns = info->func_size / sizeof(union mips_instruction);
	unsigned i;
	union mips_instruction l_ip;
	union mips_instruction *pl_ip;

	info->pc_offset = -1;
	info->frame_size = 0;

	if (!ip)
		goto err;

	if (max_insns == 0)
		max_insns = 128U;	/* unknown function size */
	max_insns = min(128U, max_insns);

	for (i = 0; i < max_insns; i++, ip++) {

		if (bt_get_user_aligned(l_ip.word, ((unsigned long*)ip))) {
			goto err;
		}
		pl_ip = &l_ip;

		/*
		 * is_jal_jalr_jr_ins() is used with assumption that
		 * info->frame_size is already obtained from is_sp_move_ins().
		 * However, this is not the case for userland backtrace ustack
		 * for API like nanosleep(), where it is written in ASM and
		 * sp modification is set after jr. Below adds assumption
		 * explicitly.
		 */
		if (info->frame_size && is_jal_jalr_jr_ins(pl_ip))
			break;
		if (!info->frame_size) {
			if (is_sp_move_ins(pl_ip))
				info->frame_size = - ip->i_format.simmediate;
			continue;
		}
		if (info->pc_offset == -1 && is_ra_save_ins(pl_ip)) {
			info->pc_offset =
				ip->i_format.simmediate / sizeof(long);
			break;
		}
	}
	if (info->frame_size && info->pc_offset >= 0) /* nested */
		return 0;
	if (info->pc_offset < 0) /* leaf */
		return 1;
	/* prologue seems boggus... */
err:
	return -1;
}
#endif

static struct mips_frame_info schedule_mfi __read_mostly;

static int __init frame_info_init(void)
{
	unsigned long size = 0;
#ifdef CONFIG_KALLSYMS
	unsigned long ofs;

	kallsyms_lookup_size_offset((unsigned long)schedule, &size, &ofs);
#endif
	schedule_mfi.func = schedule;
	schedule_mfi.func_size = size;

	get_frame_info(&schedule_mfi);

	/*
	 * Without schedule() frame info, result given by
	 * thread_saved_pc() and get_wchan() are not reliable.
	 */
	if (schedule_mfi.pc_offset < 0)
		printk("Can't analyze schedule() prologue at %p\n", schedule);

	return 0;
}

arch_initcall(frame_info_init);

/*
 * Return saved PC of a blocked thread.
 */
unsigned long thread_saved_pc(struct task_struct *tsk)
{
	struct thread_struct *t = &tsk->thread;

	/* New born processes are a special case */
	if (t->reg31 == (unsigned long) ret_from_fork)
		return t->reg31;
	if (schedule_mfi.pc_offset < 0)
		return 0;
	return ((unsigned long *)t->reg29)[schedule_mfi.pc_offset];
}


#ifdef CONFIG_KALLSYMS
/* used by show_backtrace() */
#ifdef CONFIG_SNSC_ALT_BACKTRACE
unsigned long unwind_stack_ex(struct task_struct *task, unsigned long *sp,
			      unsigned long pc, unsigned long *ra,
			      int funtop_possible);
unsigned long unwind_stack(struct task_struct *task, unsigned long *sp,
			   unsigned long pc, unsigned long *ra)
{
	/* use conservative value for funtop_possible */
	return unwind_stack_ex(task, sp, pc, ra, 1);
}

unsigned long unwind_stack_ex(struct task_struct *task, unsigned long *sp,
			      unsigned long pc, unsigned long *ra,
			      int funtop_possible)
#else
unsigned long unwind_stack(struct task_struct *task, unsigned long *sp,
			   unsigned long pc, unsigned long *ra)
#endif
{
	unsigned long stack_page;
	struct mips_frame_info info;
	unsigned long size, ofs;
	int leaf;
#ifdef CONFIG_SNSC_ALT_BACKTRACE
	int decrement;
#endif

	extern void ret_from_irq(void);
	extern void ret_from_exception(void);

	stack_page = (unsigned long)task_stack_page(task);
	if (!stack_page)
		return 0;

	/*
	 * If we reached the bottom of interrupt context,
	 * return saved pc in pt_regs.
	 */
	if (pc == (unsigned long)ret_from_irq ||
	    pc == (unsigned long)ret_from_exception) {
		struct pt_regs *regs;
		if (*sp >= stack_page &&
		    *sp + sizeof(*regs) <= stack_page + THREAD_SIZE - 32) {
			regs = (struct pt_regs *)*sp;
			pc = regs->cp0_epc;
			if (__kernel_text_address(pc)) {
				*sp = regs->regs[29];
				*ra = regs->regs[31];
				return pc;
			}
		}
		return 0;
	}
#ifdef CONFIG_SNSC_ALT_BACKTRACE
	if (pc && !funtop_possible)
		/*
		 * !funtop_possible means that pc designates a return
		 * address from a function.  If the function is
		 * specified as noreturn, its caller may not have an
		 * epilogue and pc may point to the top of the next
		 * function.  Search symbol with decremented pc.
		 */
		decrement = 1;
	else
		decrement = 0;
	if (!kallsyms_lookup_size_offset(pc - decrement, &size, &ofs))
		return 0;
	ofs += decrement;
#else
	if (!kallsyms_lookup_size_offset(pc, &size, &ofs))
		return 0;
#endif
	/*
	 * Return ra if an exception occured at the first instruction
	 */
	if (unlikely(ofs == 0)) {
		pc = *ra;
		*ra = 0;
		return pc;
	}

	info.func = (void *)(pc - ofs);
	info.func_size = ofs;	/* analyze from start to ofs */
	leaf = get_frame_info(&info);
	if (leaf < 0)
		return 0;

	if (*sp < stack_page ||
	    *sp + info.frame_size > stack_page + THREAD_SIZE - 32)
		return 0;

	if (leaf)
		/*
		 * For some extreme cases, get_frame_info() can
		 * consider wrongly a nested function as a leaf
		 * one. In that cases avoid to return always the
		 * same value.
		 */
		pc = pc != *ra ? *ra : 0;
	else
		pc = ((unsigned long *)(*sp))[info.pc_offset];

	*sp += info.frame_size;
	*ra = 0;
	return __kernel_text_address(pc) ? pc : 0;
}
#endif

/*
 * get_wchan - a maintenance nightmare^W^Wpain in the ass ...
 */
unsigned long get_wchan(struct task_struct *task)
{
	unsigned long pc = 0;
#ifdef CONFIG_KALLSYMS
	unsigned long sp;
	unsigned long ra = 0;
#endif

	if (!task || task == current || task->state == TASK_RUNNING)
		goto out;
	if (!task_stack_page(task))
		goto out;

	pc = thread_saved_pc(task);

#ifdef CONFIG_KALLSYMS
	sp = task->thread.reg29 + schedule_mfi.frame_size;

	while (in_sched_functions(pc))
		pc = unwind_stack(task, &sp, pc, &ra);
#endif

out:
	return pc;
}

/*
 * Don't forget that the stack pointer must be aligned on a 8 bytes
 * boundary for 32-bits ABI and 16 bytes for 64-bits ABI.
 */
unsigned long arch_align_stack(unsigned long sp)
{
	if (!(current->personality & ADDR_NO_RANDOMIZE) && randomize_va_space)
		sp -= get_random_int() & ~PAGE_MASK;

	return sp & ALMASK;
}

#ifdef CONFIG_SNSC_ALT_BACKTRACE
/* find a backing file for specified addr */
/* caller need to do fput() for returned file */
struct file *bt_get_mapped_file(unsigned long addr, unsigned long *base)
{
	struct vm_area_struct *vma;

	down_read(&current->mm->mmap_sem);
	vma = find_vma(current->mm, addr);
	if (!vma
	    || addr < vma->vm_start
	    || (vma->vm_flags & (VM_READ | VM_EXEC)) != (VM_READ | VM_EXEC)
	    || vma->vm_file == NULL) {
		up_read(&current->mm->mmap_sem);
		return NULL;
	}
	*base = vma->vm_start;
	get_file(vma->vm_file);
	up_read(&current->mm->mmap_sem);
	return vma->vm_file;
}

const char *bt_file_name(struct file *filp)
{
	if (filp && filp->f_path.dentry)
		return filp->f_path.dentry->d_name.name;
	else
		return "<noname>";
}
EXPORT_SYMBOL(bt_file_name);

/*
 * mmap with non-page-aligned offset.  Return similarly unaligned
 * address.
 *
 * Need down_write(&current->mm->mmap_sem).
 */
void *bt_mmap(struct file *filp, unsigned long offset, unsigned long len)
{
	unsigned long offset_in_page = offset & ~PAGE_MASK;
	unsigned long paged_offset = offset & PAGE_MASK;
	unsigned long ret;

	down_write(&current->mm->mmap_sem);
	/* len alignup will be done by do_mmap() */
	ret = do_mmap(filp, 0, len + offset_in_page,
		      PROT_READ, MAP_PRIVATE, paged_offset);
	up_write(&current->mm->mmap_sem);
	if (IS_ERR_VALUE(ret))
		return (void *)ret;
	return (void *)(ret + offset_in_page);
}

int bt_munmap(const void *addr, unsigned long len)
{
	unsigned long offset_in_page = (unsigned long)addr & ~PAGE_MASK;
	unsigned long paged_addr = (unsigned long)addr & PAGE_MASK;

	return do_munmap(current->mm, paged_addr, len + offset_in_page);
}

struct bt_elf_cache {
	struct file *be_filp;
	struct elfhdr be_ehdr;
	unsigned long be_base;
	unsigned long be_vaddr;
	Elf_Shdr *be_shdr;
	const char *be_shstrtab;
	const char *be_strtab;
	Elf_Sym *be_symtab;
	unsigned long *be_addrlist;
	unsigned long *be_symlist;
	unsigned long be_shdr_size;
	unsigned long be_shstrtab_size;
	unsigned long be_strtab_size;
	unsigned long be_symtab_size;
	unsigned long be_addrlist_size;
	unsigned long be_symlist_size;
	struct list_head be_list;
	unsigned long be_progbits_vaddr;
	long be_adjust;
};

struct addrlist_header {
	unsigned char magic[4];
	unsigned char hash[4];
	unsigned long strtab_len;
};

#define BT_MODE_USE_ADDRLIST (1 << 0)

/*
 * bt_calc_adjust():
 *
 * Code sections may be moved by some post-processing (e.g. prelink's
 * REL->RELA conversion) after addsymlist, obsoleting offsets recorded
 * in addrlist.  This routine computs the amount of the move and store
 * it to ep->be_adjust.
 *
 * This routine assumes that first entry of symbol offsets in
 * .snsc_addrlist section points to the beginning of the first
 * PROGBITS section other than .interp at addsymlist time.  The
 * routine recalculates the value and compare it with the recorded
 * value.
 */
static void bt_calc_adjust(struct bt_elf_cache *ep)
{
	unsigned long first_entry, orig_progbits_vaddr;
	struct addrlist_header *p_header =
		(struct addrlist_header *)ep->be_addrlist;
	unsigned long *addrlist = (unsigned long *)(p_header + 1);
	long len  = (ep->be_addrlist_size
		     - sizeof(struct addrlist_header))
		     / sizeof(unsigned long);
	if (len <= 0)
		return;
	first_entry = get_unaligned(addrlist);
	orig_progbits_vaddr = ep->be_vaddr + first_entry;
	ep->be_adjust = ep->be_progbits_vaddr - orig_progbits_vaddr;
}

void bt_release_elf_cache(struct bt_elf_cache *ep)
{
	if (ep->be_shdr)
		bt_munmap(ep->be_shdr, sizeof(Elf_Shdr) * ep->be_ehdr.e_shnum);
	if (ep->be_shstrtab)
		bt_munmap(ep->be_shstrtab, ep->be_shstrtab_size);
	if (ep->be_strtab)
		bt_munmap(ep->be_strtab, ep->be_strtab_size);
	if (ep->be_symtab)
		bt_munmap(ep->be_symtab, ep->be_symtab_size);
	if (ep->be_addrlist)
		bt_munmap(ep->be_addrlist, ep->be_addrlist_size);
	if (ep->be_symlist)
		bt_munmap(ep->be_symlist, ep->be_symlist_size);
	fput(ep->be_filp);
}

int bt_map_section(struct bt_elf_cache *ep, int idx, void **paddr,
		   unsigned long *psize)
{
	unsigned long size;
	void *addr;
	Elf_Shdr *shdr;

	shdr = ep->be_shdr + idx;
	size = shdr->sh_size;
	addr = bt_mmap(ep->be_filp, shdr->sh_offset, size);
	if (IS_ERR(addr)) {
		pr_debug("backtrace: mmap fail(%ld): %s\n",
		       PTR_ERR(addr), bt_file_name(ep->be_filp));
		return PTR_ERR(addr);
	}
	*paddr = addr;
	*psize = size;
	return 0;
}

int bt_init_elf_cache(struct bt_session *session,
		      struct bt_elf_cache *ep, struct file *filp,
		      unsigned long base)
{
	int ret;
	struct elfhdr *ehdr = &ep->be_ehdr;
	struct elf_phdr phdr;
	int i, idx_strtab, idx_symtab, idx_symlist, idx_addrlist;
	unsigned long offset;
	int progbits_found = 0;

	memset(ep, 0, sizeof(*ep));
	/* checking elf header */
	ep->be_filp = filp;
	ret = kernel_read(filp, 0, (char *)ehdr, sizeof(*ehdr));
	if (ret != sizeof(*ehdr)) {
		pr_debug("backtrace: too small elf: %s\n",
		       bt_file_name(filp));
		return -EINVAL;
	}
	if (memcmp(ehdr->e_ident, ELFMAG, SELFMAG) != 0) {
		pr_debug("backtrace: not elf: %s\n",
		       bt_file_name(filp));
		return -EINVAL;
	}
	if (ehdr->e_shoff == 0 || ehdr->e_shstrndx == 0) {
		pr_debug("backtrace: no section info in elf: %s\n",
		       bt_file_name(filp));
		return -EINVAL;
	}
	offset = ehdr->e_phoff;
	for (i = 0; i < ehdr->e_phnum; ++i, offset += sizeof(phdr)) {
		ret = kernel_read(filp, offset, (char *)&phdr, sizeof(phdr));
		if (ret != sizeof(phdr)) {
			pr_debug("backtrace: too small elf: %s\n",
				 bt_file_name(filp));
			return -EINVAL;
		}
		if (phdr.p_type == PT_LOAD) { /* first PT_LOAD segment */
			ep->be_vaddr = phdr.p_vaddr;
			break;
		}
	}
	ep->be_base = base;

	/* reading section header */
	ep->be_shdr = (Elf_Shdr *)bt_mmap(filp, ehdr->e_shoff,
					  sizeof(Elf_Shdr) * ehdr->e_shnum);
	if (IS_ERR(ep->be_shdr)) {
		pr_debug("backtrace: mmap fail: %p\n", ep->be_shdr);
		return PTR_ERR(ep->be_shdr);
	}
	ret = bt_map_section(ep, ehdr->e_shstrndx, (void **)&ep->be_shstrtab,
			     &ep->be_shstrtab_size);
	if (ret < 0)
		goto err_out;

	/* checking section names */
	idx_strtab = SHN_UNDEF;
	idx_symtab = SHN_UNDEF;
	idx_symlist = SHN_UNDEF;
	idx_addrlist = SHN_UNDEF;
	for (i = 1; i < ehdr->e_shnum; ++i) { /* skip 0 (SHN_UNDEF) */
		Elf_Shdr *shdr = ep->be_shdr + i;
		const char *name;
		if (shdr->sh_name == 0)
			continue;
		name = ep->be_shstrtab + shdr->sh_name;
		if (strcmp(name, ".symtab") == 0)
			idx_symtab = i;
		else if (strcmp(name, ".strtab") == 0)
			idx_strtab = i;
		else if (strcmp(name, ".debug.snsc_sym") == 0)
			idx_symlist = i;
		else if (strcmp(name, ".snsc_addrlist") == 0)
			idx_addrlist = i;
		if (shdr->sh_type == SHT_PROGBITS
		    && !progbits_found
		    && strcmp(name, ".interp")) {
			/* first non-.interp progbits section */
			progbits_found = 1;
			ep->be_progbits_vaddr = shdr->sh_addr;
		}
	}

	/* read symbols */
	if ((session->bs_mode & BT_MODE_USE_ADDRLIST)
	    && idx_addrlist != SHN_UNDEF) {
		/* using .snsc_addrlist section */
		ret = bt_map_section(ep, idx_addrlist, (void **)&ep->be_addrlist,
				     &ep->be_addrlist_size);
		if (ret < 0)
			goto err_out;
		bt_calc_adjust(ep);

		if (idx_symlist == SHN_UNDEF || idx_strtab == SHN_UNDEF)
			/* partially stripped */
			return 0;
		ret = bt_map_section(ep, idx_symlist, (void **)&ep->be_symlist,
				     &ep->be_symlist_size);
		if (ret < 0)
			goto err_out;
		ret = bt_map_section(ep, idx_strtab, (void **)&ep->be_strtab,
				     &ep->be_strtab_size);
		if (ret < 0)
			goto err_out;
		return 0;
	}
	/* using .symtab section */
	if (idx_symtab == SHN_UNDEF || idx_strtab == SHN_UNDEF)
		return 0;
	ret = bt_map_section(ep, idx_symtab, (void **)&ep->be_symtab,
			     &ep->be_symtab_size);
	if (ret < 0)
		goto err_out;
	ret = bt_map_section(ep, idx_strtab, (void **)&ep->be_strtab,
			     &ep->be_strtab_size);
	if (ret < 0)
		goto err_out;
	return 0;
err_out:
	bt_release_elf_cache(ep);
	return ret;
}

/* search session's bs_elfs using filp as a key */
static struct bt_elf_cache *bt_find_elf_cache(struct bt_session *session,
					      struct file *filp)
{
	struct bt_elf_cache *ep;
	list_for_each_entry(ep, &session->bs_elfs, be_list) {
		if (ep->be_filp == filp)
			return ep;
	}
	return 0;
}

/*
 * Return previously created elf_cache.  If none, create new one.
 *
 * Upon succeeded, filp's refcount (which is assumed to be
 * inceremented by the caller) is automatically decremented when
 * session is destoroyed, Upon failure, caller need to decrement the
 * refcount.
 */
static struct bt_elf_cache *
bt_find_or_new_elf_cache(struct bt_session *session, struct file *filp,
			 unsigned long base)
{
	int ret;
	struct bt_elf_cache *ep;

	ep = bt_find_elf_cache(session, filp);
	if (ep) {
		/* filp's refcount is doubly incremented, one when ep
		   is registered to the session and one by me.  undo
		   mine. */
		fput(filp);
		return ep;
	}
	ep = kmalloc(sizeof(struct bt_elf_cache), session->bs_memflag);
	if (!ep)
		return ERR_PTR(-ENOMEM);
	ret = bt_init_elf_cache(session, ep, filp, base);
	if (ret < 0) {
		kfree(ep);
		return ERR_PTR(ret);
	}
	/* ret == 0 */
	list_add(&ep->be_list, &session->bs_elfs);
	return ep;
}

void bt_init_session(struct bt_session *session, const char *mode,
			    int memflag)
{
	INIT_LIST_HEAD(&session->bs_elfs);
	session->bs_memflag = memflag;
	session->bs_mode = BT_MODE_USE_ADDRLIST;
	if (mode) {
		if (bt_param_match(mode, "noaddrlist")) {
			session->bs_mode &= ~BT_MODE_USE_ADDRLIST;
		}
	}
}

void bt_release_session(struct bt_session *session)
{
	struct bt_elf_cache *ep, *n;
	list_for_each_entry_safe(ep, n, &session->bs_elfs, be_list) {
		bt_release_elf_cache(ep);
		kfree(ep);
	}
}

/*
 * 0: symbol found
 * other: symbol not found
 */
int bt_addrlist_search(struct bt_elf_cache *ep, unsigned long addr,
		       char *buf, unsigned long buflen,
		       struct bt_arch_callback_arg *cbarg)
{
	struct addrlist_header *p_header =
		(struct addrlist_header *)ep->be_addrlist;
	unsigned long str, symaddr, ofs, mid;
	unsigned long strtab_len;
	unsigned long *addrlist = (unsigned long *)(p_header + 1);
	unsigned long low = 0;
	unsigned long high = (ep->be_addrlist_size -
			      sizeof(struct addrlist_header)) /
		             sizeof(unsigned long);

	strtab_len = get_unaligned(&p_header->strtab_len);

	ofs = addr - ep->be_base - ep->be_adjust;
	while (low < high) {
		mid = (low + high) / 2;
		if (ofs < get_unaligned(&addrlist[mid]))
			high = mid;
		else
			low = mid + 1;
	}
	if (low == 0)
		return -1;
	low--;
	symaddr = get_unaligned(&addrlist[low]) + ep->be_base + ep->be_adjust;

	if (buf) {
		if (!ep->be_symlist) {
			snprintf(buf, buflen, "(stripped)");
		}
		else if (strtab_len != ep->be_strtab_size) {
			snprintf(buf, buflen, ".strtab changed (%ld->%ld)",
				strtab_len, ep->be_strtab_size);
		}
		else {
			str = get_unaligned(&ep->be_symlist[low]);
			strncpy(buf, ep->be_strtab + str, buflen - 1);
			buf[buflen - 1] = '\0';
		}
	}

	cbarg->ba_sym_start = symaddr;
	cbarg->ba_sym_size = 0;
	cbarg->ba_file = ep->be_filp;
	memcpy(&cbarg->ba_hash, &p_header->hash, sizeof(p_header->hash));
	cbarg->ba_adjust = ep->be_adjust;
	return 0;
}

/*
 * 0: symbol found
 * < 0: symbol not found
 */
int bt_symtab_search(struct bt_elf_cache *ep, unsigned long addr,
		     char *buf, unsigned long buflen,
		     struct bt_arch_callback_arg *cbarg)
{
	Elf_Sym *symtab = ep->be_symtab;
	Elf_Sym *max_ent = NULL;
	unsigned long sym_num = ep->be_symtab_size / sizeof(Elf_Sym);
	unsigned long max = 0;
	unsigned long i, sym_addr;

	if (!ep->be_symtab) {
		if (buf)
			snprintf(buf, buflen, "stripped");
		return -1;
	}
	for (i = 0; i < sym_num; ++i) {
		Elf_Sym *ent = symtab + i;
		if (ELF_ST_TYPE(ent->st_info) != STT_FUNC)
			continue;
		sym_addr = ent->st_value - ep->be_vaddr + ep->be_base;
		if (sym_addr <= addr && sym_addr > max) {
			max = sym_addr;
			max_ent = ent;
		}
	}
	if (!max)
		return -1;
	cbarg->ba_sym_start = max;
	cbarg->ba_sym_size = max_ent->st_size;
	cbarg->ba_file = ep->be_filp;
	memset(&cbarg->ba_hash, 0, sizeof(cbarg->ba_hash));
	if (ep->be_strtab && buf) {
		strncpy(buf, ep->be_strtab + max_ent->st_name, buflen - 1);
		buf[buflen - 1] = '\0';
	}
	cbarg->ba_adjust = 0;
	return 0;
}

/*
 *   0: success, symbol name (or '\0' if unavailable) set to buf)
 * < 0: error, description (or '\0' if unavailable) set to buf)
 * It is OK to pass NULL as buf.
 */
int bt_find_symbol(unsigned long addr, struct bt_session *session,
		   char *buf, unsigned long buflen,
		   struct bt_arch_callback_arg *cbarg)
{
	int ret;
	struct file *filp;
	struct bt_elf_cache *ep;
	unsigned long base;

	if (buf)
		buf[0] = '\0';
	filp = bt_get_mapped_file(addr, &base);
	if (!filp) {
		if (buf)
			snprintf(buf, buflen, "no file associated to addr");
		return -1;
	}
	ep = bt_find_or_new_elf_cache(session, filp, base);

	if (IS_ERR(ep)) {
		if (buf)
			snprintf(buf, buflen, "reading elf failed (%s)",
				 bt_file_name(filp));
		fput(filp);
		return PTR_ERR(ep);
	}
	if (ep->be_addrlist
	    && (session->bs_mode & BT_MODE_USE_ADDRLIST)) {
		/* using .snsc_addrlist section */
		ret = bt_addrlist_search(ep, addr, buf, buflen, cbarg);
	}
	else {
		/* using .symtab section */
		ret = bt_symtab_search(ep, addr, buf, buflen, cbarg);
	}
	return ret;
}

unsigned long bt_ustack_unwind(struct bt_session *session, unsigned long *sp,
			       unsigned long pc, unsigned long *ra,
			       bt_callback_t *cb, void *uarg,
			       int funtop_possible)
{
	struct mips_frame_info info;
	unsigned long start, ofs;
	int leaf, ret, cbret, decrement;
	char buf[256];
	int buflen = 256;
	struct bt_arch_callback_arg cbarg;

	buf[0] = '\0';
	cbarg.ba_extra = 0;
	cbarg.ba_str = buf;
	cbarg.ba_addr = pc;
	if (pc && !funtop_possible)
		/*
		 * !funtop_possible means that pc designates a return
		 * address from a function.  If the function is
		 * specified as noret, its caller may not have an
		 * epilogue and pc may point to the top of the next
		 * function.  Search symbol with decremented pc.
		 * (Printed address is unchanged because already saved
		 * to cbarg.ba_addr)
		 */
		decrement = 1;
	else
		decrement = 0;
	ret = bt_find_symbol(pc - decrement, session, buf, buflen, &cbarg);
	if (ret < 0) {
		cbarg.ba_status = BT_STATUS_ERROR;
		cb(&cbarg, uarg);
		return 0;
	}
	cbarg.ba_status = BT_STATUS_SUCCESS;
	cbret = cb(&cbarg, uarg);
	/*
	 * Return ra if an exception occured at the first instruction
	 */
	start = cbarg.ba_sym_start;
	ofs = pc - start;
	if (unlikely(ofs == 0)) {
		pc = *ra;
		*ra = 0;
		return pc;
	}

	info.func = (void *)start;
	info.func_size = ofs;	/* analyze from start to ofs */

	leaf = get_frame_info_alt(&info);
	if (leaf < 0) {
		snprintf(buf, buflen,
			 "can't get frame info from function at 0x%08lx\n", start);
		cbarg.ba_status = BT_STATUS_ERROR;
		cb(&cbarg, uarg);
		return 0;
	}

	if (leaf)
		/*
		 * For some extreme cases, get_frame_info() can
		 * consider wrongly a nested function as a leaf
		 * one. In that cases avoid to return always the
		 * same value.
		 */
		pc = pc != *ra ? *ra : 0;
	else {
		if (bt_get_user_aligned(pc,
			      &((unsigned long *)(*sp))[info.pc_offset])) {
			snprintf(buf, buflen,
				 "get pc offset(%x) from sp(%08lx) failed\n",
				 info.pc_offset, *sp);
			cbarg.ba_status = BT_STATUS_ERROR;
			cb(&cbarg, uarg);
			return 0;
		}
	}

	*sp += info.frame_size;
	*ra = 0;
	return pc;
}

int bt_ustack_user_callback(struct bt_arch_callback_arg *cbarg, void *uarg)
{
	return 0;
}

int bt_ustack_user(struct bt_session *session, struct bt_ioctl_addrs *arg)
{
	struct pt_regs *regs = task_pt_regs(current);
	unsigned long sp = regs->regs[29];
	unsigned long ra = regs->regs[31];
	unsigned long pc = regs->cp0_epc;
	int count = 0;
	int skipping = 1;

	if (arg->ba_skip_addr == NULL)
		skipping = 0;
	while (count < arg->ba_size) {
		pc = bt_ustack_unwind(session, &sp, pc, &ra,
				      bt_ustack_user_callback, NULL,
				      0 /* assumption: syscall cannot
					   be function top */);
		if (!pc)
			break;
		if (skipping)
			skipping = ((void *)pc != arg->ba_skip_addr);
		if (!skipping) {
			put_user((void *)pc, arg->ba_buf + count);
			count++;
		}
	}
	return count;
}

void bt_ustack(const char *mode, int is_atomic,
	       struct pt_regs *regs, bt_callback_t *cb, void *uarg)
{
	unsigned long sp = regs->regs[29];
	unsigned long ra = regs->regs[31];
	unsigned long pc = regs->cp0_epc;
	int cause = (regs->cp0_cause >> 2) & 0x1f;
	struct bt_session session;
	int first_time;

	if (is_atomic) {
		struct bt_arch_callback_arg cbarg;
		cbarg.ba_status = BT_STATUS_ERROR;
		cbarg.ba_extra = 0;
		cbarg.ba_addr = pc;
		cbarg.ba_str = "ustack disabled in atomic";
		cb(&cbarg, uarg);
		return;
	}

	if ((cause == 2 /* TLB load */
	     || cause == 4) /* Address load error */
	    && pc == regs->cp0_badvaddr) {
		/* likely to be a jump to illegal address */
		pc = ra;
	}
#define CP0_CAUSE_BD			0x80000000
	if (regs->cp0_cause & CP0_CAUSE_BD)
		pc += 4;

	first_time = 1;
	bt_init_session(&session, mode, GFP_KERNEL);
	do {
		pc = bt_ustack_unwind(&session, &sp, pc, &ra, cb, uarg,
				      first_time);
		first_time = 0;
	} while (pc);
	bt_release_session(&session);
}
EXPORT_SYMBOL(bt_ustack);

int bt_special_fun(unsigned long pc)
{
	extern void ret_from_irq(void);
	extern void ret_from_exception(void);
	return (pc == (unsigned long)ret_from_irq ||
		pc == (unsigned long)ret_from_exception);

}
void bt_fill_kstack_cbarg(char *namebuf, size_t buflen,
			  struct bt_arch_callback_arg *cbarg,
			  unsigned long address, int funtop_possible)
{
	char *modname;
	const char *name;
	unsigned long offset, size;
	int dec;

	address = (unsigned long)__builtin_extract_return_addr((void *)address);
	if (address && !funtop_possible && !bt_special_fun(address))
		/*
		 * See the comment in unwind_stack() for the meaning
		 * of funtop_possible
		 */
		dec = 1;
	else
		dec = 0;
	name = kallsyms_lookup(address - dec, &size, &offset, &modname, namebuf);
	offset += dec;
	cbarg->ba_extra = 0;
	cbarg->ba_addr = address;
	cbarg->ba_str = name;
	if (!cbarg->ba_str)
		return;
	cbarg->ba_sym_start = address - offset;
	cbarg->ba_sym_size = size;
	cbarg->ba_modname = modname;
}

void bt_kstack_regs(struct task_struct *task, struct pt_regs *regs,
		    bt_callback_t *cb, void *uarg, int funtop_possible)
{
	struct bt_arch_callback_arg cbarg;
	unsigned long sp;
	unsigned long ra;
	unsigned long pc, next_pc;
	char namebuf[KSYM_NAME_LEN];
	int prev_is_special = 0;

	sp = regs->regs[29];
	ra = regs->regs[31];
	pc = regs->cp0_epc;
	do {
		bt_fill_kstack_cbarg(namebuf, KSYM_NAME_LEN, &cbarg, pc,
				     prev_is_special || funtop_possible);
		cb(&cbarg, uarg);
		next_pc = unwind_stack_ex(task, &sp, pc, &ra,
					  prev_is_special || funtop_possible);
		funtop_possible = 0;
		prev_is_special = bt_special_fun(pc);
		pc = next_pc;
	} while (pc);
}
EXPORT_SYMBOL(bt_kstack_regs);

void bt_kstack_current(const char *mode,
		       bt_callback_t *cb, void *uarg)
{
	struct pt_regs regs;
	struct task_struct *task = current;

	prepare_frametrace(&regs);
	bt_kstack_regs(task, &regs, cb, uarg, 0);
}
EXPORT_SYMBOL(bt_kstack_current);
#endif
