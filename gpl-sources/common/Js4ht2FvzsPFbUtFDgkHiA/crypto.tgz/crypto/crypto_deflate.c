/*
 *  Copyright 2012 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/signal.h>
#include <linux/zlib.h>
#include <crypto/internal/compress.h>
#include <net/netlink.h>

#include "lzd_ioctl.h"

#ifdef CONFIG_DEFLATE_DEVNAME
#define DEFLATE_DEVNAME		CONFIG_DEFLATE_DEVNAME
#else
#define DEFLATE_DEVNAME		"/dev/nanda"
#endif

#ifdef CONFIG_DEFLATE_MAX_SRC_SG_NUM
#define MAX_SRC_SG_NUM		CONFIG_DEFLATE_MAX_SRC_SG_NUM
#else
#define MAX_SRC_SG_NUM		16
#endif


#ifdef CONFIG_DEFLATE_MAX_DST_SG_NUM
#define MAX_DST_SG_NUM		CONFIG_DEFLATE_MAX_DST_SG_NUM
#else
#define MAX_DST_SG_NUM		32
#endif

typedef enum deflate_state {
	DEFLATE_STATE_INIT = 0,
	DEFLATE_STATE_INPUT_SRCLEN,
	DEFLATE_STATE_INPUT_DST,
	DEFLATE_STATE_DECOMPRESSING,
	DEFLATE_STATE_DECOMPRESSED,
	DEFLATE_STATE_ERROR,
} deflate_state_t;

struct deflate_ctx {
	struct file *filp;

	deflate_state_t state;

	struct lzd_ioc_arg ioc;
	int                decomp_len;
};

static unsigned long g_max_src = MAX_SRC_SG_NUM;
static unsigned long g_max_dst = MAX_DST_SG_NUM;

module_param_named(max_src, g_max_src, ulong, 0);
module_param_named(max_dst, g_max_dst, ulong, 0);

static inline void
deflate_ioctl_by_bdev_begin(sigset_t *oldsigs)
{
	sigset_t allsigs;

	/* block all signals */
	sigfillset(&allsigs);
	sigprocmask(SIG_SETMASK, &allsigs, oldsigs);
}

static inline void
deflate_ioctl_by_bdev_end(sigset_t *oldsigs)
{
	/* restore signal mask */
	sigprocmask(SIG_SETMASK, oldsigs, NULL);
}

static int
deflate_do_ioc(struct deflate_ctx *dctx, int ioc)
{
	int ret;
	struct file *filp = dctx->filp;
	struct block_device *bdev = filp->f_path.dentry->d_inode->i_bdev;
	sigset_t oldsigs;

	deflate_ioctl_by_bdev_begin(&oldsigs);
	ret = ioctl_by_bdev(bdev, ioc, (unsigned long)&dctx->ioc);
	deflate_ioctl_by_bdev_end(&oldsigs);

	return ret;
}

static int
deflate_alloc_handle(struct deflate_ctx *dctx)
{
	return deflate_do_ioc(dctx, LZD_IOC_ALLOC_HANDLE);
}

static int
deflate_prepare(struct deflate_ctx *dctx)
{
	return deflate_do_ioc(dctx, LZD_IOC_PREPARE);
}

static int
deflate_transfer(struct deflate_ctx *dctx)
{
	return deflate_do_ioc(dctx, LZD_IOC_TRANSFER);
}

static int
deflate_finalize(struct deflate_ctx *dctx)
{
	dctx->ioc.result = -1;
	return deflate_do_ioc(dctx, LZD_IOC_FINALIZE);
}

void
deflate_free_handle(struct deflate_ctx *dctx)
{
	int ret;

	ret = deflate_do_ioc(dctx, LZD_IOC_FREE_HANDLE);

	if (ret < 0)
		pr_warn("[crypto]failed in deflate_free_handle().\n");
}

static int
deflate_init(struct crypto_tfm *tfm)
{
	int ret;
	struct deflate_ctx *dctx = crypto_tfm_ctx(tfm);

	dctx->filp = filp_open(DEFLATE_DEVNAME, O_RDWR, 0);
	if (IS_ERR(dctx->filp)) {
		pr_debug("[crypto]failed to open the device.\n");
		ret = PTR_ERR(dctx->filp);
		goto err0;
	}

	dctx->ioc.alg = LZD_DECOMP_ALG_DEFLATE;
	dctx->ioc.max_src = (u_int32_t)g_max_src;
	dctx->ioc.max_dst = (u_int32_t)g_max_dst;

	dctx->ioc.src_list = kmalloc(sizeof(struct lzd_decomp_list) *
				     dctx->ioc.max_src,
				     GFP_KERNEL);
	if (dctx->ioc.src_list == NULL) {
		ret = -ENOMEM;
		goto err1;
	}

	dctx->ioc.dst_list = kmalloc(sizeof(struct lzd_decomp_list) *
				     dctx->ioc.max_dst,
				     GFP_KERNEL);
	if (dctx->ioc.dst_list == NULL) {
		ret = -ENOMEM;
		goto err2;
	}

	ret = deflate_alloc_handle(dctx);
	if (ret < 0) {
		goto err3;
	}

	return 0;

 err3:
	if (dctx->ioc.dst_list != NULL) {
		kfree(dctx->ioc.dst_list);
		dctx->ioc.dst_list = NULL;
	}
 err2:
	if (dctx->ioc.src_list != NULL) {
		kfree(dctx->ioc.src_list);
		dctx->ioc.src_list = NULL;
	}
 err1:
	if (filp_close(dctx->filp, current->files) < 0)
		pr_warn("[crypto]failed to close the device.\n");
	dctx->filp = NULL;
 err0:
	return ret;
}

static void
deflate_exit(struct crypto_tfm *tfm)
{
	struct deflate_ctx *dctx = crypto_tfm_ctx(tfm);

	deflate_free_handle(dctx);

	if (dctx->ioc.src_list != NULL) {
		kfree(dctx->ioc.src_list);
		dctx->ioc.src_list = NULL;
	}

	if (dctx->ioc.dst_list != NULL) {
		kfree(dctx->ioc.dst_list);
		dctx->ioc.dst_list = NULL;
	}

	if (filp_close(dctx->filp, current->files) < 0)
		pr_warn("[crypto]failed to close the device.\n");
	dctx->filp = NULL;
}

static int
deflate_compress_setup(struct crypto_pcomp *tfm, void *params,
		    unsigned int len)
{
	/* not supported */
	return -EINVAL;
}

static int
deflate_compress_init(struct crypto_pcomp *tfm)
{
	/* not supported */
	return -EINVAL;
}

static int
deflate_compress_update(struct crypto_pcomp *tfm,
		     struct comp_request *req)
{
	/* not supported */
	return -EINVAL;
}

static int
deflate_compress_final(struct crypto_pcomp *tfm,
		    struct comp_request *req)
{
	/* not supported */
	return -EINVAL;
}

static int
deflate_decompress_setup(struct crypto_pcomp *tfm, void *params,
		         unsigned int len)
{
	/* nothing to do */
	return 0;
}

static int
deflate_decompress_init(struct crypto_pcomp *tfm)
{
	struct deflate_ctx *dctx = crypto_tfm_ctx(crypto_pcomp_tfm(tfm));

	dctx->state = DEFLATE_STATE_INIT;
	dctx->ioc.num_src = 0;
	dctx->ioc.num_dst = 0;
	dctx->ioc.src_total_size = 0;
	dctx->decomp_len = 0;

	return 0;
}

static int
deflate_decompress(struct crypto_pcomp *tfm, struct comp_request *req)
{
	int output_len = 0, ret;
	struct deflate_ctx *dctx = crypto_tfm_ctx(crypto_pcomp_tfm(tfm));

	pr_debug("[crypto]next_in = %lx, next_out = %lx, avail_in = %u, "
		 "avail_out = %u\n", (unsigned long)req->next_in,
		 (unsigned long)req->next_out, req->avail_in, req->avail_out);
	pr_debug("[crypto]current state is %d\n", dctx->state);

	switch (dctx->state) {
	case DEFLATE_STATE_INIT:
		pr_debug("[crypto]DEFLATE_STATE_INIT\n");

		/* next state */
		dctx->state = DEFLATE_STATE_INPUT_SRCLEN;

		/* fall through */

	case DEFLATE_STATE_INPUT_SRCLEN:
		pr_debug("[crypto]DEFLATE_STATE_INPUT_SRCLEN\n");

		if (req->avail_in == 0 || req->next_in  != NULL ||
		    req->avail_out > 0 || req->next_out != NULL) {
			ret = -EINVAL;
			goto err;
		}

		/* register src (compression) buffer size from avail_in */
		dctx->ioc.src_total_size = req->avail_in;

		/* next state */
		dctx->state = DEFLATE_STATE_INPUT_DST;

		output_len = 0;

		break;

	case DEFLATE_STATE_INPUT_DST:
		pr_debug("[crypto]DEFLATE_STATE_INPUT_DST\n");

		if (req->avail_in == 0) {
			if (dctx->ioc.num_dst >= dctx->ioc.max_dst) {
				/* too many dst list */
				ret = -EINVAL;
				goto err;
			}

			/* add dst list item */
			dctx->ioc.dst_list[dctx->ioc.num_dst].addr =
				req->next_out;
			dctx->ioc.dst_list[dctx->ioc.num_dst].size =
				req->avail_out;
			dctx->ioc.num_dst++;

			output_len = 0;

			/* break switch */
			break;
		}

		/* all dst have been input */
		pr_debug("[crypto]deflate_prepare()\n");
		ret = deflate_prepare(dctx);
		if (ret < 0) {
			goto err;
		}

		/* next state */
		dctx->state = DEFLATE_STATE_DECOMPRESSING;
		dctx->ioc.num_src = 0;

		/* fall through */

	case DEFLATE_STATE_DECOMPRESSING:
		pr_debug("[crypto]DEFLATE_STATE_DECOMPRESSING\n");

		if (req->avail_in > 0) {
			/* add src list item */
			dctx->ioc.src_list[dctx->ioc.num_src].addr =
				(void *)req->next_in;
			dctx->ioc.src_list[dctx->ioc.num_src].size =
				req->avail_in;
			dctx->ioc.num_src++;

			req->next_in += req->avail_in;
			req->avail_in = 0;
			ret = 0;

			if (dctx->ioc.num_src == dctx->ioc.max_src) {
				/* transfer src */
				pr_debug("[crypto]deflate_transfer()\n");
				ret = deflate_transfer(dctx);
				if (ret < 0) {
					deflate_finalize(dctx);
					goto err;
				}
				dctx->ioc.num_src = 0;
			}

			output_len = 0;

			/* break switch */
			break;
		}

		/* all src have been input */
		if (dctx->ioc.num_src > 0) {
			ret = deflate_transfer(dctx);
			if (ret < 0) {
				deflate_finalize(dctx);
				goto err;
			}
			dctx->ioc.num_src = 0;
		}

		/* get decompressed result */
		pr_debug("[crypto]deflate_finalize()\n");
		ret = deflate_finalize(dctx);
		if (ret < 0) {
			goto err;
		}
		if (dctx->ioc.result < 0) {
			ret = dctx->ioc.result;
			goto err;
		}
		dctx->decomp_len = dctx->ioc.result;

		pr_debug("[crypto]deflate_finalize() resut = %d\n",
			 dctx->ioc.result);

		/* next state */
		dctx->state = DEFLATE_STATE_DECOMPRESSED;

		/* fall through */

	case DEFLATE_STATE_DECOMPRESSED:
		pr_debug("[crypto]DEFLATE_STATE_DECOMPRESSED\n");

		output_len = min_t(int, req->avail_out, dctx->decomp_len);
		dctx->decomp_len -= output_len;
		req->avail_out -= output_len;
		req->next_out += output_len;

		pr_debug("[crypto]output_len %d\n", output_len);

		break;

	case DEFLATE_STATE_ERROR:
		output_len = 0;
		break;

	default:
		BUG();
	}

	return output_len;

 err:
	dctx->state = DEFLATE_STATE_ERROR;
	return ret;
}

static int
deflate_decompress_update(struct crypto_pcomp *tfm,
			  struct comp_request *req)
{
	return deflate_decompress(tfm, req);
}

static int
deflate_decompress_final(struct crypto_pcomp *tfm,
			 struct comp_request *req)
{
	deflate_decompress_init(tfm);

	return 0;
}

static struct pcomp_alg deflate_alg = {
	.compress_setup         = deflate_compress_setup,
	.compress_init          = deflate_compress_init,
	.compress_update        = deflate_compress_update,
	.compress_final         = deflate_compress_final,
	.decompress_setup       = deflate_decompress_setup,
	.decompress_init        = deflate_decompress_init,
	.decompress_update      = deflate_decompress_update,
	.decompress_final       = deflate_decompress_final,

	.base                   = {
		.cra_name       = "deflate-w12",
		.cra_flags      = CRYPTO_ALG_TYPE_PCOMPRESS,
		.cra_ctxsize    = sizeof(struct deflate_ctx),
		.cra_module     = THIS_MODULE,
		.cra_init       = deflate_init,
		.cra_exit       = deflate_exit,
	}
};

static int __init
deflate_mod_init(void)
{
	return crypto_register_pcomp(&deflate_alg);
}

static void __exit
deflate_mod_fini(void)
{
	crypto_unregister_pcomp(&deflate_alg);
}

module_init(deflate_mod_init);
module_exit(deflate_mod_fini);

MODULE_LICENSE("GPL v2");
MODULE_DESCRIPTION("DEFLATE Compression Algorithm");
MODULE_AUTHOR("Sony Corporation");
