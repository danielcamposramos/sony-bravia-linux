/* With non GPL files, use following license */
/*
 * Copyright 2012 Sony Corporation
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions, and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */
/* Otherwise with GPL files, use following license */
/*
 *  Copyright 2012 Sony Corporation
 *
 *  This program is free software; you can redistribute  it and/or modify it
 *  under  the terms of  the GNU General  Public License as published by the
 *  Free Software Foundation;  version 2 of the  License.
 *
 *  THIS  SOFTWARE  IS PROVIDED   ``AS  IS'' AND   ANY  EXPRESS OR IMPLIED
 *  WARRANTIES,   INCLUDING, BUT NOT  LIMITED  TO, THE IMPLIED WARRANTIES OF
 *  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN
 *  NO  EVENT  SHALL   THE AUTHOR  BE    LIABLE FOR ANY   DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED   TO, PROCUREMENT OF  SUBSTITUTE GOODS  OR SERVICES; LOSS OF
 *  USE, DATA,  OR PROFITS; OR  BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *  ANY THEORY OF LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  You should have received a copy of the  GNU General Public License along
 *  with this program; if not, write  to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef __LZD_IOCTL_H__
#define __LZD_IOCTL_H__

#include <linux/types.h>

typedef u_int32_t lzd_handle_t;

struct lzd_decomp_list {
	void *addr;
	size_t size;
};

typedef enum lzd_decomp_alg {
	LZD_DECOMP_ALG_LZ77 = 0,
	LZD_DECOMP_ALG_GZIP = 1,
	LZD_DECOMP_ALG_DEFLATE = 2,
} lzd_decomp_alg_t;

struct lzd_ioc_arg {
	/*
	 * AH : LZD_IOC_ALLOC_HANDLE
	 * PR : LZD_IOC_PREPARE
	 * TR : LZD_IOC_TRANSFER
	 * FI : LZD_IOC_FINALIZE
	 * FH : LZD_IOC_FREE_HANDLE
	 *
	 * "in" means input parameter from caller.
	 * "out" means output parameter to caller.
	 * other parameters must NOT be changed.
	 */

						/* AH  PR  TR  FI  FH */
	lzd_handle_t		handle;		/* -   -   -   -   -  */

	lzd_decomp_alg_t	alg;		/* -   in  -   -   -  */

	/* number of records for LZ77 */
	u_int32_t		lz77_num_records;/*-   in  -   -   -  */

	u_int32_t		max_src;	/* in  -   -   -   -  */
	u_int32_t		num_src;	/* -   -   in  -   -  */
	struct lzd_decomp_list  *src_list;	/* -   -   in  -   -  */
	u_int32_t		src_total_size;	/* -   in  -   -   -  */

	u_int32_t		max_dst;	/* in  -   -   -   -  */
	u_int32_t		num_dst;	/* -   in  -   -   -  */
	struct lzd_decomp_list	*dst_list;	/* -   in  -   -   -  */

	/* positive value means decompressed size */
	/* negative value means error */
	int			result;		/* -   -   -   out -  */
};

#define LZD_IOC_MAGIC		165

#define LZD_IOC_ALLOC_HANDLE	_IOWR(LZD_IOC_MAGIC, 0x90, struct lzd_ioc_arg)
#define LZD_IOC_PREPARE		_IOWR(LZD_IOC_MAGIC, 0x91, struct lzd_ioc_arg)
#define LZD_IOC_TRANSFER	_IOWR(LZD_IOC_MAGIC, 0x92, struct lzd_ioc_arg)
#define LZD_IOC_FINALIZE	_IOWR(LZD_IOC_MAGIC, 0x93, struct lzd_ioc_arg)
#define LZD_IOC_FREE_HANDLE	_IOWR(LZD_IOC_MAGIC, 0x94, struct lzd_ioc_arg)

#endif /* __LZD_IOCTL_H__ */
