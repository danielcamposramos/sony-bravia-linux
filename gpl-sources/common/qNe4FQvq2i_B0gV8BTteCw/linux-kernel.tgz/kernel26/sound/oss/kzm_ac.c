/* 2006-11-02: File added and changed by Sony Corporation */
/*
 * linux/sound/oss/kzm_ac.c
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/init.h>
#include <linux/poll.h>
#include <linux/mm.h>
#include <linux/ioport.h>
#include <linux/interrupt.h>
#include <linux/dma-mapping.h>

#include <linux/slab.h>

#include <linux/sound.h>
#include <linux/soundcard.h>

#include <asm/system.h>
#include <asm/io.h>
#include <asm/irq.h>
#include <asm/dma.h>
#include <asm/uaccess.h>

#include <asm/arch/dma.h>

#include <linux/delay.h>
#if 1
#include "../../drivers/mxc/dam/dam.h"
#include "../../drivers/mxc/ssi/ssi.h"
#include "../../drivers/mxc/ssi/registers.h"
#else
#include <../drivers/mxc/dam/dam.h>
#include <../drivers/mxc/ssi/ssi.h>
#include <../drivers/mxc/ssi/registers.h>
#endif
#include "ac97.h"

#define AC97_MISC_CONTROL	0x76
#define MISC_DAM_ON		0x0800
#define SNDCTRL_DSP_DAM_CTL	0x7f00

#define USE_DMA		0

volatile unsigned long getreg_value(unsigned int offset, unsigned int ssi);
void set_register(unsigned int data, unsigned int offset, unsigned int ssi);

/* ioctl SNDCTL_DSP_STEREO */
#define CHANNEL_MONO   0
#define CHANNEL_STEREO 1

/* SSI recive data ready 0 */
#define SSI_IST_RDR0	0x4000
/* SSI transmit empty 0 */
#define SSI_IST_TDE0	0x1000

#define AC97_SNDBUF_TOTALSIZE	(512 * sizeof(int) * 4)



#if USE_DMA /* { */
#define SDMA_TXFIFO_WATERMARK				0x4
#define SDMA_RXFIFO_WATERMARK				0x6
#endif

//#define DEBUG
#ifdef DEBUG
#  define DPRINTK(fmt, args...) printk("%s: " fmt, __FUNCTION__ , ## args)
#else
#  define DPRINTK(fmt, args...)
#endif

#define KERNEL_MSG(fmt, args...) printk("%s: " fmt, __FUNCTION__ , ## args)

/*
 * Configration
 */
/* AC97(/dev/dsp) default setting */
#define DEFAULT_CHANNEL		CHANNEL_STEREO
#define DEFAULT_RATE		44100

struct device_data{
	/* SSI port to be used. */
        int ssi;

        /* DAM port where audio will be redirected to. */
        int dam_port;

        /* FIFO used to receive/send samples from/to SSI. */
        int ssi_fifo;

        /* ID of this device assigned by OSS framework */
        int device_index;

        /* write DMA channel number. */
	int dma_wchannel;

	/* read DMA channel number.*/
	int dma_rchannel;

	/* This variable holds number of bits
	 * per sample. Only 16 bits mode is supportted.
	 */
	int bits_per_sample;

        /* Semaphore used to control access to this structure. */
        struct semaphore sem;

        /* This variable tells use whether device has been opened. */
        int busy;

        /* This variable tells use whether device is currently playing/recording. */
        int transferring;

        /* Open mode requested by user. Can be write, read or write-read. */
        int open_mode;

        /* Frequency at which samples will be sent to MC13783. */
        int sample_rate;

        /* Number of channels (1 = MONO, 2 = STEREO) */
        int num_channels;

        /* This variable holds the address of a non-cacheable buffer.
         * This is needed to avoid memory corruption when doing DMA
         * transfers.
         */
        dma_addr_t raw_buffer;

        /* Size of raw buffer being transferred. */
        int raw_count;

        /* This variable tells whether this device us being used
         * as output or input.
         */
        int direction;
};

/****************************************************************************
 * Sound buffer
 ****************************************************************************/
typedef	struct	fifodata {
	unsigned int	*bufPtr;
	long		bufSize;
	unsigned int	*wtPtr;
	unsigned int	*rdPtr;
} st_snd_buff;

static void init_snd_buff(st_snd_buff *rb, unsigned int *buf, int size)
{
	rb->bufPtr = buf;
	rb->bufSize = size/sizeof(int);
	rb->wtPtr = buf;
	rb->rdPtr = buf;
}

static void reset_snd_buff(st_snd_buff *rb)
{
	rb->wtPtr = rb->bufPtr;
	rb->rdPtr = rb->bufPtr;
}

static int snd_buff_num(st_snd_buff *rb)
{
	if(rb->wtPtr >= rb->rdPtr) {
		return rb->wtPtr - rb->rdPtr;
	} else {
		return rb->bufSize - (rb->rdPtr - rb->wtPtr);
	}
}

/****************************************************************************
 * Driver work
 ****************************************************************************/

struct ac97_card {

	wait_queue_head_t wfq;
	wait_queue_head_t rfq;
	wait_queue_head_t syncq;

	int dev_audio;		/* soundcore stuff */

	unsigned long ac97_iobase;

	unsigned int smp_rate;
	unsigned int channel;

	st_snd_buff wt_buff;
	st_snd_buff rd_buff;

	unsigned int w_openCnt;
	unsigned int r_openCnt;

	int subdiv;
};

static struct ac97_card *ac97_devs = NULL;

static void ac97_write_command(int cmd,int data)
{
	struct ac97_card *card = ac97_devs;

	msleep(1);
	ssi_ac97_set_command_address_register(0,cmd << 12);			/* command 12-18 */
	ssi_ac97_set_command_data_register(0,data << 4);			/* data 4-19 */

	ssi_set_data(0,ssi_fifo_0,0xe000);					/* valid data & valid address */

	ssi_ac97_set_tag_register(0,card->w_openCnt? 0xf800:0xe000);		/* valid data & valid address (SATAG write) */
	ssi_ac97_write_command(0, true);
}

static int read_command(int cmd)
{
	int data;
	struct ac97_card *card = ac97_devs;

	ssi_ac97_set_command_address_register(0,cmd << 12);		/* command 12-18 */

	ssi_set_data(0,ssi_fifo_0,0xc000);				/* valid address */
	ssi_ac97_set_tag_register(0,card->w_openCnt? 0xd800:0xc000);	/* valid address (SATAG write) */
	ssi_ac97_read_command(0, true);
	msleep(1);
	data = ssi_ac97_get_command_data_register(0);

	return data >> 4;
}


#if USE_DMA /* { */
static void sdma_tx_callback(void* arg)
{
        struct device_data* dev;
        int index;

        dev = (struct device_data*)arg;
        index = dev->device_index;

        dma_unmap_single(NULL, dev->raw_buffer, dev->raw_count, DMA_TO_DEVICE);
        DMAbuf_outputintr(index, 1);
}

int configure_write_channel(struct device_data* dev, void (*callback)(void*))
{
        dma_channel_params params;
        int channel = 0;
        int result = 0;

        result = mxc_request_dma(&channel, "OSS TX SDMA");
       	if (result < 0){
       		KERNEL_MSG("error requesting a dma channel for writing\n");
       		return -1;
       	}

	memset(&params, 0, sizeof(dma_channel_params));

	params.bd_number = 1;
        params.arg = dev;
        params.callback = callback;
       	params.transfer_type = emi_2_per;
       	params.watermark_level = SDMA_TXFIFO_WATERMARK;

        params.word_size = TRANSFER_16BIT;

        if (dev->ssi == SSI1){
        	DPRINTK("activating connection SSI1 - SDMA\n");
        	params.per_address = SSI1_BASE_ADDR;
        	params.event_id = DMA_REQ_SSI1_TX1;
       		params.peripheral_type = SSI;
       	}else{
       		DPRINTK("activating connection SSI2 - SDMA\n");
       		params.per_address = SSI2_BASE_ADDR;
        	params.event_id = DMA_REQ_SSI2_TX1;
       		params.peripheral_type = SSI_SP;
       	}

        mxc_dma_setup_channel(channel, &params);
        dev->dma_wchannel = channel;

        return 0;
}
#else /* }{ */
#endif /* } */

static int check_com_buffer(st_snd_buff * bp)
{
	if(bp->wtPtr == (bp->bufPtr + bp->bufSize - 1)){
	    if(bp->rdPtr == bp->bufPtr){		/* buffer buff */
		return 1;			/* full */
	    }
	}else{
	    if((bp->wtPtr + 1) == bp->rdPtr){
		return 1;		/* buffer full */
	    }
	}
	return 0;
}

static int get_tx_data(struct ac97_card * card,unsigned char *buf,unsigned long *lp)
{
	if(card->channel == CHANNEL_STEREO){
	    *lp = *buf + (*(buf + 1) << 8) + (*(buf + 2) << 16) + (*(buf + 3) << 24);
	    return 4;
	}else{
	    *lp = *buf + (*(buf + 1) << 8) * (*buf << 16) + (*(buf + 1) << 24);
	    return 2;
	}
}

static void write_snd_data(st_snd_buff *sb,unsigned long *lp)
{

	if(sb->wtPtr == (sb->bufPtr + sb->bufSize - 1)){
	    *sb->wtPtr = *lp;
	    sb->wtPtr = sb->bufPtr;
	}else{
	    *sb->wtPtr = *lp;
	    sb->wtPtr = sb->wtPtr + 1;
	}
}

/*
static int kzm_rx_lost_count;
static int kzm_rec_count;
*/
static irqreturn_t
ssi_int_handler(int irq,void *dev_id,struct pt_regs *regs)
{
	struct ac97_card *card = ac97_devs;
	int ct,cnt,i;
	unsigned char *cp;
	unsigned long dt1,dt2;

	DPRINTK("SSI1=%08x\n");
	if(card->r_openCnt > 0)
	if(getreg_value(MXC_SSISISR,0) & SSI_IST_RDR0){
	    cnt =  ssi_rx_fifo_counter(0,ssi_fifo_0);
	    cnt &= 0xfffffffe;
	    cp = (unsigned char *)card->rd_buff.wtPtr;
	    for(i=0;i < cnt/2;i++){
		dt1 = getreg_value(MXC_SSISRX0,0);
		dt2 = getreg_value(MXC_SSISRX0,0);
		if(check_com_buffer(&card->rd_buff)){
//		    kzm_rx_lost_count++;
		}else{
//		    kzm_rec_count++;
		    *cp++ = ((dt1>>4) & 0xff);
		    *cp++ = ((dt1 >> 12) & 0xff);
		    *cp++ = ((dt2>>4) & 0xff);
		    *cp++ = ((dt2 >> 12) & 0xff);
		    if(cp == (unsigned char *)(card->rd_buff.bufPtr + card->rd_buff.bufSize)){
			cp = (unsigned char *)card->rd_buff.bufPtr;
		    }
		    card->rd_buff.wtPtr = (unsigned int *)cp;
		}
	    }
	    wake_up_interruptible(&card->rfq);
	}
	if(card->w_openCnt > 0)
	if(getreg_value(MXC_SSISISR,0) & SSI_IST_TDE0){
	    if(card->wt_buff.wtPtr >= card->wt_buff.rdPtr){
		ct = card->wt_buff.wtPtr - card->wt_buff.rdPtr;
	    }else{
		ct = (card->wt_buff.bufPtr + card->wt_buff.bufSize) - card->wt_buff.rdPtr;
		ct += (card->wt_buff.wtPtr - card->wt_buff.bufPtr);
	    }
	    if(ct == 0){
		ssi_interrupt_disable(0, ssi_tx_fifo_0_empty);
		wake_up_interruptible(&card->syncq);
	    }else{
		cnt =  8 - ssi_tx_fifo_counter(0,ssi_fifo_0);
		cnt &=0xfffffffe;
		cnt = min(cnt,ct * 2);
		cp = (unsigned char *)card->wt_buff.rdPtr;
		for(i=0;i < cnt;i++){
		    set_register((*cp + (*(cp+1)<<8)) << 4   ,MXC_SSISTX0,0);
		    i++;
		    cp += 2;
		    set_register((*cp + (*(cp+1)<<8)) << 4   ,MXC_SSISTX0,0);
		    cp += 2;
		    if(cp >= (unsigned char *)(card->wt_buff.bufPtr + card->wt_buff.bufSize)) cp = (unsigned char *)card->wt_buff.bufPtr;
		}
		card->wt_buff.rdPtr = (unsigned int *)cp;
	    }
	}

	wake_up_interruptible(&card->wfq);

	return IRQ_HANDLED;

}

static inline void stop_transmit(void)
{
        ssi_interrupt_disable(0, ssi_tx_interrupt_enable);
}

//stera
static inline void start_transmit(void)
{
        ssi_interrupt_enable(0, ssi_tx_interrupt_enable);
}


static inline void stop_receive(void)
{
        ssi_interrupt_disable(0, ssi_rx_interrupt_enable);
}

static inline void start_receive(void)
{
        ssi_interrupt_enable(0, ssi_rx_interrupt_enable);
}

static ssize_t
ac97_read(struct file *file, char *buf, size_t count, loff_t * ppos)
{
	struct ac97_card *card = ac97_devs;
	int read_cnt,ct;
	unsigned int data;

	read_cnt = count;

	while(read_cnt > 0){
	    if(card->rd_buff.wtPtr != card->rd_buff.rdPtr){
		data = *card->rd_buff.rdPtr;
		put_user(data,buf);
		put_user((data>>8),buf + 1);
		if(card->channel == CHANNEL_STEREO){
		    put_user(data>>16,buf + 2);
		    put_user((data>>24),buf + 3);
		    ct = 4;
		}else{
		    ct = 2;
		}
		buf += ct;
		read_cnt -= ct;
		if((card->rd_buff.rdPtr + 1) == (card->rd_buff.bufPtr + card->rd_buff.bufSize)){
		    card->rd_buff.rdPtr = card->rd_buff.bufPtr;
		}else{
		    card->rd_buff.rdPtr++;
		}
	    }else{
		interruptible_sleep_on(&card->rfq);
		if (signal_pending(current)) {
		    break;
		}
	    }
	}

	return count - read_cnt;
}

int kmc_count_test;
static ssize_t
ac97_write(struct file *file, const char *buf, size_t count, loff_t * ppos)
{
	struct ac97_card *card = ac97_devs;
	unsigned char *sp;
	int size;
	int ct = count;
	unsigned long data;

	if (!access_ok(VERIFY_READ, buf, count)) {
		return -EFAULT;
	}
	sp = (unsigned char *)buf;

	while(ct){
	    if(check_com_buffer(&card->wt_buff) == 0){
		size = get_tx_data(card,(unsigned char *)buf,&data);
		write_snd_data(&card->wt_buff,&data);
		ct -= size;
		buf += size;
		continue;
	    }

	    ssi_interrupt_enable(0, ssi_tx_fifo_0_empty);
	    interruptible_sleep_on_timeout(&card->wfq,(HZ*12)/44100);
	    if (signal_pending(current)) {
		break;
	    }

	}
	return count - ct;
}

static inline int set_smp_rate(unsigned long rate)
{
	if(rate == 44100) return 0;	/* 44.1 KHz */
	return -1;
}

static int
ac97_ioctl(struct inode *inode, struct file *file, unsigned int cmd,
	   unsigned long arg)
{
	struct ac97_card *card = ac97_devs;
	volatile int val = 0;

	DPRINTK("%08x %08x\n", cmd, (int)arg);

	switch (cmd) {
	case OSS_GETVERSION:
		return put_user(SOUND_VERSION, (int *) arg);

	case SNDCTL_DSP_RESET:
		if (file->f_mode & FMODE_WRITE) {
			stop_transmit();
			reset_snd_buff(&card->wt_buff);
			start_transmit(); //stera
		}

		if (file->f_mode & FMODE_READ) {
			stop_receive();
			reset_snd_buff(&card->rd_buff);
			start_receive();
		}

		return 0;

	case SNDCTL_DSP_SYNC:
		if (file->f_mode & FMODE_WRITE) {
			if(getreg_value(MXC_SSISIER,0) & ssi_tx_fifo_0_empty){
				interruptible_sleep_on(&card->syncq);
			}
		}
		return 0;

	case SNDCTL_DSP_SPEED:	/* set smaple rate */
		DPRINTK("SNDCTL_DSP_SPEED\n");
		if (get_user(val, (int *) arg)) {
			return -EFAULT;
		}

		if (set_smp_rate(val) != 0) {
			DPRINTK("not support this sampling rate %d\n", val);
			return -EINVAL;
		} else {
			card->smp_rate = val;
		}
		return put_user(card->smp_rate, (int *) arg);

	case SNDCTL_DSP_STEREO:	/* set stereo or mono channel */
		DPRINTK("SNDCTL_DSP_STEREO\n");
		if (get_user(val, (int *) arg)) {
			return -EFAULT;
		}

		if (file->f_mode & FMODE_WRITE) {
			stop_transmit();
			if (val) {
				DPRINTK("Stereo.\n");
				card->channel = CHANNEL_STEREO;
			} else {
				DPRINTK("Nomo.\n");
				card->channel = CHANNEL_MONO;
			}
			start_transmit(); //stera
		}

		if (file->f_mode & FMODE_READ) {
			stop_receive();
			if (val) {
				DPRINTK("Stereo.\n");
				card->channel = CHANNEL_STEREO;
			} else {
				DPRINTK("Nomo.\n");
				card->channel = CHANNEL_MONO;
			}
			start_receive();
		}
		return 0;

	case SNDCTL_DSP_GETBLKSIZE:
		if(card->channel == CHANNEL_STEREO) {
			val = (AC97_SNDBUF_TOTALSIZE * 4) / card->subdiv;
		} else {
			val = (AC97_SNDBUF_TOTALSIZE * 2) / card->subdiv;
		}
		DPRINTK("SNDCTL_DSP_GETBLKSIZE = %d\n", val);
		return put_user(val, (int *) arg);

	case SNDCTL_DSP_GETFMTS:	/* Returns a mask of supported
					 * sample format */
		return put_user(AFMT_S16_LE, (int *) arg);

	case SNDCTL_DSP_SETFMT:	/* Select sample format */
		DPRINTK("SNDCTL_DSP_SETFMT\n");
		if (get_user(val, (int *) arg)) {
			return -EFAULT;
		}

		if (val != AFMT_QUERY) {
			if (file->f_mode & FMODE_WRITE) {
				stop_transmit();
				start_transmit(); //stera
			}
			if (file->f_mode & FMODE_READ) {
				stop_receive();
				start_receive();
			}
		}

		return put_user(AFMT_S16_LE, (int *) arg);

	case SNDCTL_DSP_CHANNELS:
		DPRINTK("SNDCTL_DSP_CHANNELS\n");
		if (get_user(val, (int *) arg)) {
			return -EFAULT;
		}
		DPRINTK("ch=%d\n", val);

		if (val != 0) {
			if (file->f_mode & FMODE_WRITE) {
				stop_transmit();
			}

			if (file->f_mode & FMODE_READ) {
				stop_receive();
			}

			switch(val) {
			case 1:
				card->channel = CHANNEL_MONO;
				DPRINTK("Mono.\n");
				break;

			case 2:
				card->channel = CHANNEL_STEREO;
				DPRINTK("Stereo.\n");
				break;

			default:
				/* Not suport */
				switch(card->channel) {
				case CHANNEL_STEREO:
					val = 2;
					break;

				case CHANNEL_MONO:
					val = 1;
					break;
				}
				break;
			}

			if (file->f_mode & FMODE_READ) {
				start_receive();
			}
			//stera
			if (file->f_mode & FMODE_WRITE) {
				start_transmit();
			}
		}
		return put_user(val, (int *) arg);

	case SNDCTL_DSP_POST:
		/* FIXME: the same as RESET ?? */
		return 0;

	case SNDCTL_DSP_SUBDIVIDE:
		return -EFAULT;//!!!
		if (get_user(val, (int *) arg)) {
			return -EFAULT;
		}
		DPRINTK("SNDCTL_DSP_SUBDIVIDE arg=%d\n", val);
		if((val != 1) && (val != 2) && (val != 4)) {
			return -EINVAL;
		} else if(val != 1) {
			card->subdiv = val;
			return 0;
		}

	case SNDCTL_DSP_SETFRAGMENT:
		return 0;

	case SNDCTL_DSP_NONBLOCK:
		DPRINTK("SNDCTL_DSP_NONBLOCK\n");
		file->f_flags |= O_NONBLOCK;
		return 0;

	case SNDCTL_DSP_GETCAPS:
		return 0;

	case SNDCTL_DSP_SETDUPLEX:
		return -EINVAL;

	case SOUND_PCM_READ_RATE:
		DPRINTK("SOUND_PCM_READ_RATE\n");
		return put_user(card->smp_rate, (int *) arg);

	case SOUND_PCM_READ_CHANNELS:
		DPRINTK("SOUND_PCM_READ_CHANNELS\n");
		return put_user((card->channel & CHANNEL_STEREO) ? 2 : 1,
				(int *) arg);

	case SOUND_PCM_READ_BITS:
		DPRINTK("SOUND_PCM_READ_BITS\n");
		return put_user(AFMT_S16_LE, (int *) arg);

	case SNDCTL_DSP_GETISPACE:
		DPRINTK("SNDCTL_DSP_GETISPACE\n");
		{
			audio_buf_info abinfo;

			abinfo.fragments = 1;

			DPRINTK("if=%d\n", abinfo.fragments);
			abinfo.fragstotal = AC97_SNDBUF_TOTALSIZE;
			if(card->channel == CHANNEL_STEREO) {
				abinfo.fragsize = AC97_SNDBUF_TOTALSIZE;
			} else {
				abinfo.fragsize = AC97_SNDBUF_TOTALSIZE/2;
			}
			abinfo.bytes = abinfo.fragsize;
			return copy_to_user((void *) arg, &abinfo,
					    sizeof (abinfo)) ? -EFAULT : 0;
		}
		break;

	case SNDCTL_DSP_GETOSPACE:
		DPRINTK("SNDCTL_DSP_GETOSPACE\n");
		{
			audio_buf_info abinfo;

			abinfo.fragments = 1;

			DPRINTK("of=%d\n", abinfo.fragments);
			abinfo.fragstotal = 1;
			if(card->channel == CHANNEL_STEREO) {
				abinfo.fragsize = AC97_SNDBUF_TOTALSIZE;
			} else {
				abinfo.fragsize = AC97_SNDBUF_TOTALSIZE/2;
			}
			abinfo.bytes = abinfo.fragsize;
			return copy_to_user((void *) arg, &abinfo,
					    sizeof (abinfo)) ? -EFAULT : 0;
		}
		break;

	case SNDCTRL_DSP_DAM_CTL:
		if(arg == 0){
			ac97_write_command(AC97_MISC_CONTROL,MISC_DAM_ON);	/* DAM ON */
		}else{
			ac97_write_command(AC97_MISC_CONTROL,0);		/* DAM OFF */
		}
		break;
	default:
		DPRINTK("unknown ioctl 0x%x\n", cmd);
		return -EINVAL;
	}

	DPRINTK("unimplemented ioctl 0x%x\n", cmd);

	return -EINVAL;
}

static int ac97_open(struct inode *inode, struct file *file)
{
	struct ac97_card *card = ac97_devs;

	DPRINTK("open\n");

	if (file->f_mode & FMODE_READ) {
		if (card->r_openCnt > 0) {
			return -EBUSY;
		}
	}

	if (file->f_mode & FMODE_WRITE) {
		if (card->w_openCnt > 0) {
			return -EBUSY;
		}
	}

	if (file->f_mode & FMODE_READ) {
		card->r_openCnt++;
//		init_dma_buff(&card->rx_buff);
//		start_receive();
#if USE_DMA /* { */
#else /* }{ */
		ssi_rx_fifo_enable(0, ssi_fifo_0, true);
#endif /* } */
//		ssi_receive_enable(0,true);
	        ssi_interrupt_enable(0, ssi_rx_interrupt_enable);
		ssi_interrupt_enable(0,ssi_rx_fifo_0_full);
	}

	if (file->f_mode & FMODE_WRITE) {
		card->w_openCnt++;
//		init_dma_buff(&card->tx_buff);
#if USE_DMA /* { */
#else /* }{ */
		ssi_tx_fifo_enable(0, ssi_fifo_0, true);
#endif /* } */
//		ssi_transmit_enable(0,true);
//		ssi_enable(0,true);
	        ssi_interrupt_enable(0, ssi_tx_interrupt_enable);
		ssi_ac97_set_tag_register(0,0x9800);			/* lift/right data send */
	}

	return 0;
}

static unsigned int
ac97_poll(struct file *file, poll_table * wait)
{
	struct ac97_card *card = ac97_devs;
	unsigned int mask;

	DPRINTK("select\n");

	mask = 0;

	if (file->f_mode & FMODE_READ) {
		poll_wait(file, &(card->rfq), wait);
		if(snd_buff_num(&card->rd_buff)) {
			mask |= POLLIN | POLLRDNORM;
		}
	}

	if (file->f_mode & FMODE_WRITE) {
		poll_wait(file, &(card->wfq), wait);
		if(snd_buff_num(&card->rd_buff)) {
			mask |= POLLIN | POLLRDNORM;
		}
		if((AC97_SNDBUF_TOTALSIZE - snd_buff_num(&card->wt_buff)) >
		   (AC97_SNDBUF_TOTALSIZE/3)) {
			mask |= POLLOUT | POLLWRNORM;
		}
	}

	DPRINTK("mask = %08x\n", mask);

	return mask;
}

static int
ac97_release(struct inode *inode, struct file *file)
{
	struct ac97_card *card = ac97_devs;

	DPRINTK("release\n");

	if (file->f_mode & FMODE_READ) {
//		stop_receive();
//		init_dma_buff(&card->rx_buff);
		reset_snd_buff(&card->rd_buff);

		ssi_rx_fifo_enable(0, ssi_fifo_0, false);
//		ssi_receive_enable(0,false);
	        ssi_interrupt_disable(0, ssi_rx_interrupt_enable);
		ssi_interrupt_disable(0,ssi_rx_fifo_0_full);
		card->r_openCnt--;
		if (card->r_openCnt < 0) {
			card->r_openCnt = 0;
		}
	}

	if (file->f_mode & FMODE_WRITE) {
		stop_transmit();
		reset_snd_buff(&card->wt_buff);

		ssi_tx_fifo_enable(0, ssi_fifo_0, false);
//		ssi_transmit_enable(0,true);
	        ssi_interrupt_disable(0, ssi_tx_interrupt_enable);
		card->w_openCnt--;
		if (card->w_openCnt < 0) {
			card->w_openCnt = 0;
		}
	}

	return 0;
}



static struct file_operations ac97_fops = {
	read:ac97_read,
	write:ac97_write,
	ioctl:ac97_ioctl,
	open:ac97_open,
	poll:ac97_poll,
	release:ac97_release,
};


static inline void
free_ac97_buff(void)
{
	struct ac97_card *card = ac97_devs;

	DPRINTK("free siof buff.\n");

	if (card->wt_buff.bufPtr != 0) {
		kfree(card->wt_buff.bufPtr);
	}

	if (card->rd_buff.bufPtr != 0) {
		kfree(card->rd_buff.bufPtr);
	}
}

/****************************************************************************
	Mixer
****************************************************************************/
static int clip(int min, int max, int val)
{
	if(val < min) {
		val = min;
	} else if(val > max) {
		val = max;
	}

	return val;
}

/*
 * Mastor volume
 */
static int mvol_l, mvol_r;

static int set_volume(int val_l, int val_r)
{
	mvol_l = clip(0, 100, val_l);
	mvol_r = clip(0, 100, val_r);

	ac97_write_command(AC97_MASTER_VOL_STEREO,(((100-mvol_l)*0x1f/100)<<8) +
		  (((100-mvol_r)*0x1f/100)));
	ac97_write_command(AC97_HEADPHONE_VOL,(((100-mvol_l)*0x1f/100)<<8) +
		  (((100-mvol_r)*0x1f/100)));

	return (mvol_r << 8) + mvol_l;
}

static int get_volume(void)
{
	return (mvol_r << 8) + mvol_l;
}

/*
 * PCM volume
 */
static int pcm_vol_l, pcm_vol_r;

static int set_pcm_volume(int val_l, int val_r)
{
	pcm_vol_l = clip(0, 100, val_l);
	pcm_vol_r = clip(0, 100, val_r);

	ac97_write_command(AC97_PCMOUT_VOL,(((100-pcm_vol_l)*0x1f/100)<<8) +
		  (((100-pcm_vol_r)*0x1f/100)));

	return (pcm_vol_r << 8) + pcm_vol_l;
}

static int get_pcm_volume(void)
{
	return (mvol_r << 8) + mvol_l;
}

/*
 * Line volume
 */
static int line_vol_l, line_vol_r;

static int set_line_volume(int val_l, int val_r)
{
	line_vol_l = clip(0, 100, val_l);
	line_vol_r = clip(0, 100, val_r);

	ac97_write_command(AC97_LINEIN_VOL,(((100-line_vol_l)*0x1f/100)<<8) +
		  (((100-line_vol_r)*0x1f/100)));

	return (line_vol_r << 8) + line_vol_l;
}

static int get_line_volume(void)
{
	return (line_vol_r << 8) + line_vol_l;
}

/*
 * MIC volume
 */
static int mic_vol;
static int mic_boost = 1;

static int set_mic_volume(int val)
{
	mic_vol = clip(0, 100, val);

	ac97_write_command(AC97_MIC_VOL,(((100-mic_vol)*0x1f/100)) | (mic_boost ? AC97_MICBOOST:0));

	return (mic_vol <<8) + mic_vol;
}

static int get_mic_volume(void)
{
	return (mic_vol <<8) + mic_vol;
}


/************************************************************************/
static int ad1981_mixer_ioctl(struct inode * inode, struct file * file,
			      unsigned int cmd, unsigned long arg)
{
	int val;
	int ret = 0;

	if (cmd == SOUND_MIXER_INFO) {
		mixer_info info;
		DPRINTK("SOUND_MIXER_INFO\n");
		memset(&info, 0, sizeof(info));
                strncpy(info.id, "AD1981", sizeof(info.id)-1);
                strncpy(info.name, "AD8191 audio", sizeof(info.name)-1);
                info.modify_counter = 1; /* ? */
                if (copy_to_user((void *)arg, &info, sizeof(info)))
                        return -EFAULT;
		return 0;
	}

	if (cmd == OSS_GETVERSION)
		return put_user(SOUND_VERSION, (int *)arg);

	/* read */
	val = 0;
	if (_SIOC_DIR(cmd) & _SIOC_WRITE)
		if (get_user(val, (int *)arg))
			return -EFAULT;

	switch (cmd) {
	case MIXER_READ(SOUND_MIXER_CAPS):
		DPRINTK("SOUND_MIXER_CAPS\n");
		ret =	SOUND_CAP_EXCL_INPUT;
		break;
	case MIXER_READ(SOUND_MIXER_STEREODEVS):
		DPRINTK("SOUND_MIXER_STEREODEVS\n");
		ret =	SOUND_MASK_VOLUME |
			SOUND_MASK_PCM |
			SOUND_MASK_LINE;
		break;

	case MIXER_READ(SOUND_MIXER_RECMASK):
		DPRINTK("SOUND_MIXER_RECMASK\n");
		ret =	SOUND_MASK_LINE |
			SOUND_MASK_MIC;
		break;
	case MIXER_READ(SOUND_MIXER_DEVMASK):
		DPRINTK("SOUND_MIXER_DEVMASK\n");
		ret =	SOUND_MASK_VOLUME |
			SOUND_MASK_PCM |
			SOUND_MASK_LINE |
			SOUND_MASK_MIC;
		break;
	case MIXER_READ(SOUND_MIXER_OUTMASK):
		DPRINTK("SOUND_MIXER_OUTMASK\n");
		ret =	SOUND_MASK_VOLUME |
			SOUND_MASK_PCM;
		break;

	case MIXER_WRITE(SOUND_MIXER_RECSRC):
		DPRINTK("WRITE:SOUND_MIXER_RECSRC(%08x)\n", val);
		ret =	SOUND_MASK_LINE |
			SOUND_MASK_MIC;
		break;
	case MIXER_READ(SOUND_MIXER_RECSRC):
		DPRINTK("READ:SOUND_MIXER_RECSRC\n");
		ret =	SOUND_MASK_LINE |
			SOUND_MASK_MIC;
		break;

	case MIXER_WRITE(SOUND_MIXER_OUTSRC):
		DPRINTK("MIXER_WRITE-SOUND_MIXER_OUTSRC\n");
		ret =	SOUND_MASK_PCM;
		break;
	case MIXER_READ(SOUND_MIXER_OUTSRC):
		DPRINTK("MIXER_READ-SOUND_MIXER_OUTSRC\n");
		ret =	SOUND_MASK_PCM;
		break;

	case MIXER_WRITE(SOUND_MIXER_VOLUME):
		DPRINTK("WRITE:VOLUME\n");
		ret = set_volume(val & 0xff, (val >> 8) & 0xff);
		break;
	case MIXER_READ(SOUND_MIXER_VOLUME):
		DPRINTK("READ:VOLUME\n");
		ret = get_volume();
		break;

	case MIXER_WRITE(SOUND_MIXER_PCM):
		DPRINTK("WRITE:PCM_VOLUME\n");
		ret = set_pcm_volume(val & 0xff, (val >> 8) & 0xff);
		break;
	case MIXER_READ(SOUND_MIXER_PCM):
		DPRINTK("READ:PCM_VOLUME\n");
		ret = get_pcm_volume();
		break;

	case MIXER_WRITE(SOUND_MIXER_LINE):
		DPRINTK("WRITE:LINE_VOLUME\n");
		ret = set_line_volume(val & 0xff, (val >> 8) & 0xff);
		break;
	case MIXER_READ(SOUND_MIXER_LINE):
		DPRINTK("READ:LINE_VOLUME\n");
		ret = get_line_volume();
		break;

	case MIXER_WRITE(SOUND_MIXER_MIC):
		DPRINTK("WRITE:MIC_VOLUME(%08x)\n", val);
		ret = set_mic_volume(val & 0xff);
		break;
	case MIXER_READ(SOUND_MIXER_MIC):
		DPRINTK("READ:MIC_VOLUME(%08x)\n", val);
		ret = get_mic_volume();
		break;

	default:
		DPRINTK("Undifined ioctl(%08x,%08x).\n", cmd, val);
		return -EINVAL;
	}

	if (put_user(ret, (int *)arg))
		return -EFAULT;
	return 0;
}

static int ad1981_mixer_open(struct inode *inode, struct file *file)
{
	return 0;
}

static int ad1981_mixer_release(struct inode *inode, struct file *file)
{
	return 0;
}


/****************************************************************************/

static struct file_operations ad1981_mixer_fops = {
	owner:		THIS_MODULE,
	llseek:		no_llseek,
	open:		ad1981_mixer_open,
	release:	ad1981_mixer_release,
	ioctl:		ad1981_mixer_ioctl
};

static int dev_mixer;


static int ad1891_init(void)
{
	ac97_write_command(AC97_RESET,0x0000);			/* Reset register */

	msleep(1);
/**/#if 0 /* { TEST */
	ac97_write_command(AC97_MASTER_VOL_STEREO,0x0808);	/* Master Vol 0db and Mute off and r-mute off */
	ac97_write_command(AC97_HEADPHONE_VOL,0x0000);		/* Headphone(AUX) Vol 0db and Mute off and r-mute off */

	ac97_write_command(AC97_MASTER_VOL_MONO,0x0000);	/* Mono Vol 0db and Mute off and r-mute off */
	ac97_write_command(AC97_PHONE_VOL,0x0000);		/* phone Vol 0db and Mute off and r-mute off */
	ac97_write_command(AC97_MIC_VOL,0x0000);		/* mic Vol 0db and Mute off and r-mute off */

	ac97_write_command(AC97_LINEIN_VOL,0x0000);		/* Line-in Vol Mute off */
	ac97_write_command(AC97_CD_VOL,0x0000);			/* CD Vol Mute off */

	ac97_write_command(AC97_AUX_VOL,0x0000);		/* AUX Vol Mute off */
	ac97_write_command(AC97_RECORD_SELECT,0x404);		/* Rec sel Line-in  */

	ac97_write_command(AC97_RECORD_GAIN,0x0808);		/* Rec Gain */
	ac97_write_command(AC97_PCMOUT_VOL,0x0);		/* PCM_VOL ON */

	ac97_write_command(0x64,0x808);				/* MIXER ADC */

	ac97_write_command(AC97_MISC_CONTROL,MISC_DAM_ON);	/* DAM ON */
/**/#endif /* } */

	ac97_write_command(0x64,0x808);				/* MIXER ADC */

	ac97_write_command(AC97_MISC_CONTROL,MISC_DAM_ON);	/* DAM ON */
	ac97_write_command(AC97_RECORD_SELECT,0x505);		/* Rec sel Line-in and Mic */
	ac97_write_command(AC97_RECORD_GAIN,0x0808);		/* Rec Gain */

//	ac97_write_command(AC97_GENERAL_PURPOSE,0x80);			/* Loop Back */

	set_smp_rate(DEFAULT_RATE);

	set_volume(75, 75);
	set_pcm_volume(75, 75);
	set_line_volume(75, 75);
	set_mic_volume(75);

        if(request_irq(INT_SSI1, ssi_int_handler, SA_SHIRQ, "mxcssi1", ac97_devs)){
		printk(KERN_ERR "Cannot allocate SSI_IRQ\n");
		kfree(ac97_devs);
		return -ENODEV;

	}
	dev_mixer = register_sound_mixer (&ad1981_mixer_fops, -1);
	if (dev_mixer < 0) {
		printk(KERN_ERR "unable to register AD1981 mixer, aborting\n");
		DPRINTK ("EXIT, returning -EIO\n");
		return -EIO;
	}
	return 0;
}


static int kzm_ac97_init(void)
{
	struct ac97_card *card;
	unsigned int *tmp_buf;
	int source_port = port_1;
	int target_port = port_4;

	DPRINTK("init\n");

	if ((card = kmalloc(sizeof (struct ac97_card), GFP_KERNEL)) == NULL) {
		return -ENOMEM;
	}

	memset(card, 0, sizeof (*card));
	card->smp_rate = DEFAULT_RATE;
	card->channel = DEFAULT_CHANNEL;
	card->subdiv = 1;
	ac97_devs = card;



	/* TX MSB trans  STCR[4]=0 */
	/* RX MSB Recv   SRCR[4]=0 */
	/* TX rising edge STCR[3]=0 */
	/* RX latched faillig edge SRCR[3]=0 */
	/* TX frame sync active high STCR[2]=0 */
	/* RX frame sync active high SRCR[2]=0 */

	ssi_rx_word_length(0, 9);		/* ���Ĺ 9:20bit 7:16bit */
	ssi_rx_frame_rate(0, 13);		/* 13�ļ��� ���åȤ�12 */
	ssi_tx_word_length(0, 9);		/* ���Ĺ 9:20bit 7:16bit */
	ssi_tx_frame_rate(0, 13);		/* 13������ ���åȤ�12 */

	dam_reset_register(source_port);
        dam_reset_register(target_port);

        dam_select_mode(source_port, normal_mode);
        dam_select_mode(target_port, normal_mode);

        dam_set_synchronous(source_port, true);
        dam_set_synchronous(target_port, true);

        dam_select_RxD_source(source_port, target_port);
        dam_select_RxD_source(target_port, source_port);

        dam_select_TxFS_direction(source_port, signal_in);
        dam_select_TxFS_direction(target_port, signal_out);
	dam_select_TxFS_source(source_port, false, target_port);
//	dam_select_TxFS_direction(source_port, signal_out);
//	dam_select_TxFS_source(source_port, false, target_port);

	dam_select_TxClk_direction(source_port, signal_out);
	dam_select_TxClk_source(source_port, false, target_port);

	ssi_tx_frame_direction(0, ssi_tx_rx_internally);

	ssi_transmit_enable(0,true);
	ssi_receive_enable(0,true);

	ssi_enable(0,true);

	ssi_ac97_mode_enable(0,true);

	msleep(1);

//	card->rd_buff.bufPtr = 0;

	/* write buffer */
	if ((tmp_buf = kmalloc(AC97_SNDBUF_TOTALSIZE, GFP_KERNEL))
	    != NULL) {
		init_snd_buff(&card->wt_buff,tmp_buf,AC97_SNDBUF_TOTALSIZE);
	} else {
		free_ac97_buff();
		printk("kzm-mx31 buffer:no memory(wt)\n");
		return -ENOMEM;
	}
	/* read buffer */
	if ((tmp_buf = kmalloc(AC97_SNDBUF_TOTALSIZE, GFP_KERNEL))
	    != NULL) {
		init_snd_buff(&card->rd_buff,tmp_buf,AC97_SNDBUF_TOTALSIZE);
	} else {
		free_ac97_buff();
		printk("kzm-mx31 buffer:no memory(rd)\n");
		return -ENOMEM;
	}

	/* initialize queue */
	init_waitqueue_head(&card->wfq);
	init_waitqueue_head(&card->rfq);
	init_waitqueue_head(&card->syncq);

	/* Register /dev/dsp */
	if ((card->dev_audio = register_sound_dsp(&ac97_fops, -1)) < 0) {
		printk(KERN_ERR "couldn't register DSP device!\n");
		free_ac97_buff();
		free_irq(INT_SSI1, card);
		kfree(card);
		return -ENODEV;
	}


        ssi_interrupt_disable(0, ssi_tx_data_reg_empty_0);
        ssi_interrupt_disable(0, ssi_tx_data_reg_empty_1);
        ssi_interrupt_disable(0, ssi_tx_fifo_1_empty);
        ssi_interrupt_disable(0, ssi_tx_fifo_0_empty);
        ssi_interrupt_disable(0, ssi_tx_interrupt_enable);
        ssi_interrupt_disable(0, ssi_rx_interrupt_enable);
	return 0;
}


static int __init
kzm_ac97_audio_init(void)
{
	int rt;

	printk(KERN_INFO "KZM AC97 & AD1981 Audio Driver\n");

	if((rt = kzm_ac97_init()) != 0) {
		return rt;
	}

	if((rt = ad1891_init()) != 0) {
		return rt;
	}

	return 0;
}

static inline void
ac97_exit(void)
{
	struct ac97_card *card = ac97_devs;

	DPRINTK("exit\n");

	free_irq(INT_SSI1, card);

	unregister_sound_dsp(card->dev_audio);
	kfree(card->wt_buff.bufPtr);
	kfree(card->rd_buff.bufPtr);
	kfree(card);
}

static void kzm_ac97_exit(void)
{
	unregister_sound_mixer (dev_mixer);
}

static void __exit
kzm_ac97_audio_exit(void)
{
	kzm_ac97_exit();
	ac97_exit();
}



MODULE_LICENSE("GPL");

module_init(kzm_ac97_audio_init);
module_exit(kzm_ac97_audio_exit);
