/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrjala <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.
*/

/*
  This was initially based on the systems/x11 implementation.

  ChangeLog:

    - 2009/09/16
        * Ported on Sony DTV products.
 */

#ifndef __DTV_SURFACE_POOL_H__
#define __DTV_SURFACE_POOL_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct dfb_dtv_vram_funcs {
	void *(*alloc)(size_t size);
	void (*free)(void *ptr);
	void *(*get_addr)(void *);
	int (*lock)(void *ptr);
	int (*unlock)(void *ptr);
} dfb_dtv_vram_funcs_t;

int dfb_dtv_set_vram_funcs(const dfb_dtv_vram_funcs_t *);

#ifdef __cplusplus
}
#endif

#endif /* __DTV_SURFACE_POOL_H__ */
