/* ========================================================================= *

				 Surface Pool

 * ========================================================================= */
/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrjala <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/

/*
  This was initially based on the systems/x11 implementation.

  ChangeLog:

    - 2009/09/16
        * Ported on Sony DTV products.
 */

#include <direct/debug.h>
#include <direct/mem.h>
#include <core/surface_pool.h>
#include <gfx/convert.h>
#include <directfb_util.h>

#include "dtv_surface_pool.h"
#include "dfb_dtv.h"

#ifdef CONFIG_DIRECTFB_USE_UXGFX_VRAM_ALLOCATOR
#include <UxgTypes.h>
#include <UxgSysForC.h>
#endif /* CONFIG_DIRECTFB_USE_UXGFX_VRAM_ALLOCATOR */

D_DEBUG_DOMAIN(UXGfx_Pool, "UXGfx/Pool", "UXGfx Memory");

/* ========================================================================= */

typedef enum {
	DFB_DTV_ALLOCATOR_VRAM,
	DFB_DTV_ALLOCATOR_ALLOCATOR
} dfb_dtv_allocator_type_t;

typedef struct dtv_pool_data {
	int magic;
	dfb_dtv_allocator_type_t alloc_type;
	dfb_dtv_vram_funcs_t vram;
	dfb_dtv_vram_allocator_t allocator;
} dtv_pool_data_t;

typedef struct dtv_pool_local_data {
	int magic;
	CoreDFB *core;
} dtv_pool_local_data_t;

typedef struct dtv_allocation_data {
	int magic;
	void *hdl;
} dtv_allocation_data_t;

/* ------------------------------------------------------------------------ */
#ifdef CONFIG_DIRECTFB_USE_UXGFX_VRAM_ALLOCATOR
/*
 * UXGfx heap manager
 */
static void *
uxgfx_alloc(size_t size)
{

	return UXGfxHeapManager_heapNew(size);
}

static void
uxgfx_free(void *ptr)
{

	UXGfxHeapManager_heapDelete((UxgMemHdl_t *)ptr);
}

static void *
uxgfx_get_addr(void *ptr)
{

	return ((UxgMemHdl_t *)(ptr))->addr;
}

static int
uxgfx_lock(void *ptr)
{

	return UXGfxHeapManager_lock((UxgMemHdl_t *)ptr);
}

static int
uxgfx_unlock(void *ptr)
{

	return UXGfxHeapManager_unlock((UxgMemHdl_t *)ptr);
}

static dfb_dtv_vram_funcs_t vram_funcs_default = {
	.alloc    = uxgfx_alloc,
	.free     = uxgfx_free,
	.get_addr = uxgfx_get_addr,
	.lock     = uxgfx_lock,
	.unlock   = uxgfx_unlock,
};

#else /* CONFIG_DIRECTFB_USE_UXGFX_VRAM_ALLOCATOR */

/*
 * NULL heap manager
 */
static void *
null_alloc(size_t size)
{

	return NULL;
}

static void
null_free(void *ptr)
{

	return;
}

static void *
null_get_addr(void *ptr)
{

	return NULL;
}

static int
null_lock(void *ptr)
{

	return 1;
}

static int
null_unlock(void *ptr)
{

	return 1;
}

static dfb_dtv_vram_funcs_t vram_funcs_default = {
	.alloc    = null_alloc,
	.free     = null_free,
	.get_addr = null_get_addr,
	.lock     = null_lock,
	.unlock   = null_unlock,
};

#endif /* CONFIG_DIRECTFB_USE_UXGFX_VRAM_ALLOCATOR */

/* ------------------------------------------------------------------------ */

static dfb_dtv_vram_funcs_t vram_funcs;
#define VRAM_FUNCS_IS_SET (vram_funcs.alloc != NULL)

static dfb_dtv_vram_allocator_t vram_allocator;
#define VRAM_ALLOCATOR_IS_SET (vram_allocator.alloc != NULL)

#if 0
static int
check_vram_funcs(dfb_dtv_vram_funcs_t *funcs)
{

	if (!(funcs->alloc && funcs->free)) {
		return 1;
	}

	if (!((funcs->get_addr && funcs->lock && funcs->unlock)
	      || (!funcs->get_addr && !funcs->lock && !funcs->unlock))) {
		return 1;
	}

	return 0;
}
#endif

int
dfb_dtv_set_vram_funcs(const dfb_dtv_vram_funcs_t *funcs)
{

	if (VRAM_FUNCS_IS_SET || VRAM_ALLOCATOR_IS_SET) {
		/* already set */
		return 1;
	} else {
		vram_funcs = *funcs;
		return 0;
	}
}

int
dfb_dtv_set_vram_allocator(const dfb_dtv_vram_allocator_t *allocator)
{

	if (VRAM_ALLOCATOR_IS_SET || VRAM_FUNCS_IS_SET) {
		/* already set */
		return 1;
	} else {
		vram_allocator = *allocator;
		return 0;
	}
}

/* ========================================================================= */

static int
dtv_pool_data_size()
{

	return sizeof(dtv_pool_data_t);
}

static int
dtv_pool_local_data_size()
{

	return sizeof(dtv_pool_local_data_t);
}

static int
dtv_allocation_data_size()
{

	return sizeof(dtv_allocation_data_t);
}

static DFBResult
dtv_init_pool(CoreDFB *core,
              CoreSurfacePool *pool,
              void *pool_data,
              void *pool_local,
              void *system_data,
              CoreSurfacePoolDescription *ret_desc)
{
	dtv_pool_data_t *dtv_pool;

	ret_desc->caps = CSPCAPS_NONE;
	ret_desc->access[CSAID_CPU] = CSAF_READ | CSAF_WRITE;
	ret_desc->access[CSAID_GPU] = CSAF_READ | CSAF_WRITE;
	ret_desc->types = CSTF_SHARED | CSTF_EXTERNAL;
	ret_desc->priority = CSPP_DEFAULT;

	ret_desc->access[CSAID_LAYER0] = CSAF_READ;
	ret_desc->access[CSAID_LAYER1] = CSAF_READ;
	ret_desc->access[CSAID_LAYER2] = CSAF_READ;
	ret_desc->access[CSAID_LAYER3] = CSAF_READ;
	ret_desc->access[CSAID_LAYER4] = CSAF_READ;
	ret_desc->access[CSAID_LAYER5] = CSAF_READ;
	ret_desc->access[CSAID_LAYER6] = CSAF_READ;
	ret_desc->access[CSAID_LAYER7] = CSAF_READ;

	dtv_pool = pool_data;
	if (VRAM_FUNCS_IS_SET) {
		dtv_pool->alloc_type = DFB_DTV_ALLOCATOR_VRAM;
		dtv_pool->vram = vram_funcs;
		snprintf(ret_desc->name,
			 DFB_SURFACE_POOL_DESC_NAME_LENGTH,
			 "user_allocator (vram)");
	} else if (VRAM_ALLOCATOR_IS_SET) {
		dtv_pool->alloc_type = DFB_DTV_ALLOCATOR_ALLOCATOR;
		dtv_pool->allocator = vram_allocator;
		snprintf(ret_desc->name,
			 DFB_SURFACE_POOL_DESC_NAME_LENGTH,
			 "user_allocator (allocator)");
	} else {
		dtv_pool->alloc_type = DFB_DTV_ALLOCATOR_VRAM;
		dtv_pool->vram = vram_funcs_default;

#ifdef CONFIG_DIRECTFB_USE_UXGFX_VRAM_ALLOCATOR
		snprintf(ret_desc->name,
			 DFB_SURFACE_POOL_DESC_NAME_LENGTH,
			 "UXGfx");
#else
		snprintf(ret_desc->name,
			 DFB_SURFACE_POOL_DESC_NAME_LENGTH,
			 "null_allocator");
		D_WARN("Allocator is null. "
		       "Please use dfb_dtv_set_vram_funcs()");
		return DFB_OK;
#endif
	}

	return DFB_OK;
}

static DFBResult
dtv_destroy_pool(CoreSurfacePool *pool,
                 void *pool_data,
                 void *pool_local)
{

	return DFB_OK;
}

static DFBResult
dtv_test_config(CoreSurfacePool *pool,
                void *pool_data,
                void *pool_local,
                CoreSurfaceBuffer *buffer,
                const CoreSurfaceConfig *config)
{

	if (config->caps & DSCAPS_VIDEOONLY) {
		return DFB_OK;
	} else {
		return DFB_FAILURE;
	}
}

static DFBResult
dtv_allocate_buffer(CoreSurfacePool *pool,
                    void *pool_data,
                    void *pool_local,
                    CoreSurfaceBuffer *buffer,
                    CoreSurfaceAllocation *allocation,
                    void *alloc_data)
{
	dtv_allocation_data_t *data;
	dtv_pool_data_t *dtv_pool;
	CoreSurface *surface;
	size_t size;
	void *hdl;

	dtv_pool = (dtv_pool_data_t *)pool_data;
	data = (dtv_allocation_data_t *)alloc_data;
	surface = buffer->surface;

	/*
	 * This should be fixed to use dfb_gfxcard_calc_buffer_size()
	 */
	if (DFB_PLANAR_PIXELFORMAT(surface->config.format)) {
		int bpl;

		bpl = DFB_BYTES_PER_LINE(surface->config.format,
					 surface->config.size.w);
		/* Y component */
		size = surface->config.size.h * bpl;
		size = (size + 31) / 32 * 32;
		/* C component */
		if (surface->config.format == DSPF_NV16) {
			size += surface->config.size.h * bpl;
		} else if (surface->config.format == DSPF_NV12) {
			size += surface->config.size.h * bpl / 2;
		} else {
			D_ERROR("unsupported pixel format\n");
			return DFB_FAILURE;
		}
	} else {
		size = surface->config.size.h
			* DFB_BYTES_PER_LINE(surface->config.format,
					     surface->config.size.w);
	}

	switch (dtv_pool->alloc_type) {
	case DFB_DTV_ALLOCATOR_VRAM:
		hdl = dtv_pool->vram.alloc(size);
		break;
	case DFB_DTV_ALLOCATOR_ALLOCATOR:
		hdl = dtv_pool->allocator.alloc(size, surface->resource_id);
		break;
	default:
		hdl = NULL;
		D_BUG("not reached!\n");
	}
	if (!hdl) {
		return DFB_FAILURE;
	}

	allocation->size = (int)size;
	allocation->offset = 0;

	data->hdl = hdl;

	return DFB_OK;
}

static DFBResult
dtv_deallocate_buffer(CoreSurfacePool *pool,
                      void *pool_data,
                      void *pool_local,
                      CoreSurfaceBuffer *buffer,
                      CoreSurfaceAllocation *allocation,
                      void *alloc_data)
{
	dtv_pool_data_t *dtv_pool;
	dtv_allocation_data_t *data;

	dtv_pool = (dtv_pool_data_t *)pool_data;
	data = (dtv_allocation_data_t *)alloc_data;

	switch (dtv_pool->alloc_type) {
	case DFB_DTV_ALLOCATOR_VRAM:
		dtv_pool->vram.free(data->hdl);
		break;
	case DFB_DTV_ALLOCATOR_ALLOCATOR:
		dtv_pool->allocator.free(data->hdl,
					 buffer->surface->resource_id);
		break;
	default:
		D_BUG("not reached!\n");
		return DFB_FAILURE;
	}

	return DFB_OK;
}

static DFBResult
dtv_lock(CoreSurfacePool *pool,
         void *pool_data,
         void *pool_local,
         CoreSurfaceAllocation *allocation,
         void *alloc_data,
         CoreSurfaceBufferLock *lock)
{
	dtv_pool_data_t *dtv_pool;
	dtv_allocation_data_t *data;
	CoreSurfaceConfig *config;
	void *addr;
	int err;

	config = &allocation->surface->config;
	dtv_pool = (dtv_pool_data_t *)pool_data;
	data = (dtv_allocation_data_t *)alloc_data;

	switch (dtv_pool->alloc_type) {
	case DFB_DTV_ALLOCATOR_VRAM:
		err = dtv_pool->vram.lock(data->hdl);
		addr = dtv_pool->vram.get_addr(data->hdl);
		break;
	case DFB_DTV_ALLOCATOR_ALLOCATOR:
		err = dtv_pool->allocator.lock(data->hdl);
		addr = dtv_pool->allocator.get_addr(data->hdl);
		break;
	default:
		err = 1;
		D_BUG("not reached!\n");
	}
	if (err) {
		D_ERROR("lock(%p) failed! [%d]\n", data->hdl, err);
		return DFB_FAILURE;
	}

	/*
	 * This should be fixed to use local data saved when
	 * dtv_allocate_buffer()
	 */
	lock->pitch  = DFB_BYTES_PER_LINE(config->format, config->size.w);
	lock->addr   = addr;
	lock->offset = 0;
	lock->phys   = 0;

	return DFB_OK;
}

static DFBResult
dtv_unlock(CoreSurfacePool *pool,
           void *pool_data,
           void *pool_local,
           CoreSurfaceAllocation *allocation,
           void *alloc_data,
           CoreSurfaceBufferLock *lock)
{
	dtv_pool_data_t *dtv_pool;
	dtv_allocation_data_t *data;
	int err;

	dtv_pool = (dtv_pool_data_t *)pool_data;
	data = (dtv_allocation_data_t *)alloc_data;

	switch (dtv_pool->alloc_type) {
	case DFB_DTV_ALLOCATOR_VRAM:
		err = dtv_pool->vram.unlock(data->hdl);
		break;
	case DFB_DTV_ALLOCATOR_ALLOCATOR:
		err = dtv_pool->allocator.unlock(data->hdl);
		break;
	default:
		err = 1;
		D_BUG("not reached!");
	}
	if (err) {
		D_ERROR("unlock(%p) failed! [%d]\n", data->hdl, err);
		return DFB_FAILURE;
	}

	return DFB_OK;
}

const SurfacePoolFuncs dtv_surface_pool_funcs = {
	.PoolDataSize       = dtv_pool_data_size,
	.PoolLocalDataSize  = dtv_pool_local_data_size,
	.AllocationDataSize = dtv_allocation_data_size,
	.InitPool           = dtv_init_pool,
	.DestroyPool        = dtv_destroy_pool,

	.TestConfig         = dtv_test_config,

	.AllocateBuffer     = dtv_allocate_buffer,
	.DeallocateBuffer   = dtv_deallocate_buffer,

	.Lock               = dtv_lock,
	.Unlock             = dtv_unlock,
};

/* ===================================================================== EOF */
