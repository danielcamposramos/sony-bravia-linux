/* ========================================================================= *

 * ========================================================================= */
/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrjala <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/

/*
  This was initially based on the systems/x11 implementation.

  ChangeLog:

    - 2009/09/16
        * Ported on Sony DTV products.
 */

#include <stdio.h>

#include <directfb.h>
#include <core/palette.h>
#include <core/system.h>
#include <core/screens.h>
#include <core/layers.h>
#include <misc/conf.h>

#include "dtv.h"

#define ARRAY_LEN(a) (sizeof(a) / sizeof((a)[0]))

/* ----------------------------------------------------------------------------
 * helper funcs
 */

/* ----------------------------------------------------------------------------
 * DisplayLayerFuncs
 */

static int
dtv_layer_data_size()
{

	return 0;
}

static DFBResult
dtv_init_layer(CoreLayer                  *layer,
	       void                       *driver_data,
	       void                       *layer_data,
	       DFBDisplayLayerDescription *description,
	       DFBDisplayLayerConfig      *config,
	       DFBColorAdjustment         *adjustment)
{
	int mode_w, mode_h;
	dtv_t *dtv;

	/* data */

	dtv = driver_data;

	/* config */

	mode_w = dfb_config->mode.width;
	mode_h = dfb_config->mode.height;

	description->caps = DLCAPS_SURFACE | DLCAPS_SCREEN_POSITION;
	description->type = DLTF_GRAPHICS;
	snprintf(description->name, DFB_DISPLAY_LAYER_DESC_NAME_LENGTH,
		 "DTV11 dummy plane");

	config->flags	    =	DLCONF_WIDTH	   | DLCONF_HEIGHT
		| DLCONF_PIXELFORMAT | DLCONF_BUFFERMODE;
	config->width	    = mode_w ? mode_w : 640;
	config->height	    = mode_h ? mode_h : 480;
	config->pixelformat = DSPF_ARGB;
	config->buffermode  = DLBM_FRONTONLY;

	return DFB_OK;
}

static DFBResult
dtv_test_region(CoreLayer		   *layer,
		void			   *driver_data,
		void			   *layer_data,
		CoreLayerRegionConfig	   *config,
		CoreLayerRegionConfigFlags *failed)
{

	return DFB_OK;
}

static DFBResult
dtv_add_regon(CoreLayer	            *layer,
	      void		    *driver_data,
	      void		    *layer_data,
	      void		    *region_data,
	      CoreLayerRegionConfig *config)
{

	return DFB_OK;
}

static DFBResult
dtv_set_region(CoreLayer		  *layer,
	       void			  *driver_data,
	       void			  *layer_data,
	       void			  *region_data,
	       CoreLayerRegionConfig	  *config,
	       CoreLayerRegionConfigFlags updated,
	       CoreSurface		  *surface,
	       CorePalette		  *palette,
	       CoreSurfaceBufferLock      *lock)
{

	return DFB_OK;
}

static DFBResult
dtv_remove_region(CoreLayer *layer,
		  void      *driver_data,
		  void      *layer_data,
		  void      *region_data)
{

	return DFB_OK;
}

static DFBResult
dtv_flip_region(CoreLayer             *layer,
		void                  *driver_data,
		void                  *layer_data,
		void                  *region_data,
		CoreSurface           *surface,
		DFBSurfaceFlipFlags   flags,
		CoreSurfaceBufferLock *lock)
{

	dfb_surface_flip(surface, false);

	return DFB_OK;
}

/* ----------------------------------------------------------------------------
 * public functions
 */

static DisplayLayerFuncs dtv_layer_funcs = {
	.LayerDataSize     = dtv_layer_data_size,
	.InitLayer         = dtv_init_layer,
	.TestRegion        = dtv_test_region,
	.AddRegion         = dtv_add_regon,
	.SetRegion         = dtv_set_region,
	.RemoveRegion      = dtv_remove_region,
	.FlipRegion        = dtv_flip_region,
};

void
dtv_layer_register(CoreScreen *screen)
{

	dfb_layers_register(screen, dtv, &dtv_layer_funcs);
}

/* ===================================================================== EOF */
