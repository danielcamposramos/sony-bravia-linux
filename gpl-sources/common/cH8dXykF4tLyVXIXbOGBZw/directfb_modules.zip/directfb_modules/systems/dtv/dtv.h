/* ========================================================================= *

 * ========================================================================= */
/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrjala <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/

/*
  This was initially based on the systems/x11 implementation.

  ChangeLog:

    - 2009/09/16
        * Ported on Sony DTV products.
 */

#ifndef __DTV_H__
#define __DTV_H__

#include <stdint.h>

#include <core/coretypes.h>

typedef struct dtv_shared {
	CoreSurfacePool *pool;
} dtv_shared_t;

typedef struct dtv {
	dtv_shared_t *shared;
	CoreDFB *core;

	int fd;
} dtv_t;

#define CLEAR_DTV(dtv) do {			\
	(dtv)->shared = NULL;			\
	(dtv)->core   = NULL;			\
	(dtv)->fd     = 0;			\
} while (0)

/*
 * global data
 */
extern dtv_t *dtv;

#endif /* __DTV_H__ */

/* ===================================================================== EOF */
