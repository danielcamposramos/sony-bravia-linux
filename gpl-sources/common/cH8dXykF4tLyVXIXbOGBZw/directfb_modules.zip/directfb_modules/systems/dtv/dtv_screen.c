/* ========================================================================= *

 * ========================================================================= */
/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrjala <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/

/*
  This was initially based on the systems/x11 implementation.

  ChangeLog:

    - 2009/09/16
        * Ported on Sony DTV products.
 */

#include <stdio.h>

#include <directfb.h>
#include <core/screens.h>

/* ----------------------------------------------------------------------------
 * ScreenFuncs
 */

static DFBResult
dtv_init_screen(CoreScreen           *screen,
		CoreGraphicsDevice   *device,
		void                 *driver_data,
		void                 *screen_data,
		DFBScreenDescription *description)
{

	description->caps = DSCCAPS_NONE;
	snprintf(description->name, DFB_SCREEN_DESC_NAME_LENGTH,
		 "DTV09 Primary Screen");

	return DFB_OK;
}

static DFBResult
dtv_get_screen_size(CoreScreen *screen,
		    void       *driver_data,
		    void       *screen_data,
		    int        *ret_width,
		    int        *ret_height)
{

	*ret_width  = 1920;	// TBD
	*ret_height = 1080;	// TBD

	return DFB_OK;
}

/* ----------------------------------------------------------------------------
 * public functions
 */

static ScreenFuncs dtv_screen_funcs = {
	.InitScreen    = dtv_init_screen,
	.GetScreenSize = dtv_get_screen_size,
};

CoreScreen *
dtv_screen_register(void)
{

	return dfb_screens_register(NULL, NULL, &dtv_screen_funcs);
}

/* ===================================================================== EOF */
