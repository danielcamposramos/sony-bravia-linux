/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrj�Cl�C <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/


/*
   Copyright 2009-2010 Sony Corporation.
   
   This is IDirectFBImageProvider implementation based decoder to support devided decoding mode.
   
   ChangeLog:
      2010/01/21 Applying IDirectFBImageProvider to devided decoding mode on Sony products
*/

/*
   Notice:
      This decoder is a sample implementation for modified IDirectFBImageProvider.
      This implementation can support only simple-format gif images. 
      Complicated-format images, like interlace, can not be supported.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdarg.h>

#include <directfb.h>

#include <display/idirectfbsurface.h>

#include <media/idirectfbimageprovider.h>

#include <core/coredefs.h>
#include <core/coretypes.h>

#include <core/layers.h>
#include <core/surface.h>

#include <misc/gfx_util.h>
#include <direct/interface.h>
#include <direct/mem.h>
#include <direct/memcpy.h>
#include <misc/util.h>
#include "SonyDirectFB.h"
#include "SonyDFBGifDecoder.h"

#ifndef NODEBUG
#define GIFERRORMSG(x...)     { fprintf( stderr, "(GIFLOADER) "x ); \
                                fprintf( stderr, "\n" ); }
#else
#define GIFERRORMSG(x...)
#endif


#define MAXCOLORMAPSIZE 256

#define CM_RED   0
#define CM_GREEN 1
#define CM_BLUE  2

#define MAX_LWZ_BITS 12

#define INTERLACE     0x40
#define LOCALCOLORMAP 0x80

#define BitSet(byte, bit) (((byte) & (bit)) == (bit))

#define LM_to_uint(a,b) (((b)<<8)|(a))


#define RET_OK 0
#define RET_NG 1
#define GIF_DEC_BUF_SIZE 4096+2
#define GIF_DEC_MAX_SRC_SIZE 2*1024*1024

typedef struct {
	int                  image_width;
	int                  image_height;
	bool                 image_transparency;
	u32                  image_colorkey;

	unsigned int  Width;
	unsigned int  Height;
	u8            ColorMap[3][MAXCOLORMAPSIZE];
	unsigned int  BitPixel;
	unsigned int  ColorResolution;
	u32           Background;
	unsigned int  AspectRatio;

	int GrayScale;
	int transparent;
	int delayTime;
	int inputFlag;
	int disposal;

	u8 buf[280];
	int curbit, lastbit, done, last_byte;

	int fresh;
	int code_size, set_code_size;
	int max_code, max_code_size;
	int firstcode, oldcode;
	int clear_code, end_code;
	int table[2][(1<< MAX_LWZ_BITS)];
	int stack[(1<<(MAX_LWZ_BITS))*2], *sp;

	unsigned char *srcData;
	unsigned int srcEndPoint;
	unsigned int seekPoint;
	SonyDFBDecoderStatus status;		/*< decoder status */
	SonyDFBGifRenderCallback renderCB;	/*< callback function for rendering*/
	SonyDFBImageData* userData1;		/*< user data*/
	SonyDFBGifCallback callback;		/*< callback function for status notify */
	void* userData2;					/*< user data*/
} GIFDecoder;

static bool verbose       = false;
//static bool showComment   = false;
static bool ZeroDataBlock = false;

static int ReadColorMap( GIFDecoder *data, int number, u8 buf[3][MAXCOLORMAPSIZE] );
static int GetDataBlock(GIFDecoder *data, u8 *buf);
static int GetCode(GIFDecoder *data, int code_size, int flag);
static int DoExtension( GIFDecoder *data, int label );
static int LWZReadByte( GIFDecoder *data, int flag, int input_code_size );
static int SortColors (const void *a, const void *b);
static u32 FindColorKey( int n_colors, u8 cmap[3][MAXCOLORMAPSIZE] );
static u32* ReadImage( GIFDecoder *data, int width, int height, u8 cmap[3][MAXCOLORMAPSIZE], u32 key_rgb, bool interlace, bool ignore );
static bool ReadGIF( GIFDecoder *data, int imageNumber, int *width, int *height, bool *transparency, u32 *key_rgb, bool alpha, bool headeronly);
static bool ReadOK( GIFDecoder *decoder, void *data, unsigned int len );
static bool addSrcData(GIFDecoder *decoder, const unsigned char *data, const unsigned int size);
static bool removeSrcData(GIFDecoder *decoder, unsigned int size);


static bool addSrcData(GIFDecoder *decoder, const unsigned char *data, const unsigned int size)
{
	if (decoder->srcEndPoint + size > GIF_DEC_MAX_SRC_SIZE) {
		return false;
	}
	else {
		memcpy(&decoder->srcData[decoder->srcEndPoint], data, size);
		decoder->srcEndPoint += size;
		return true;
	}
}

static bool removeSrcData(GIFDecoder *decoder, unsigned int size)
{
	if (decoder->srcEndPoint < size) {
		return false;
	}
	else {
		memmove(&decoder->srcData[0], &decoder->srcData[size], sizeof(unsigned char)*(decoder->srcEndPoint - size));
		decoder->srcEndPoint -= size;
		decoder->seekPoint -= size;
		return true;
	}
}

/**********************************
         GIF Loader Code
 **********************************/
static int ReadColorMap( GIFDecoder *data, int number,
                         u8 buf[3][MAXCOLORMAPSIZE] )
{
	int     i;
	u8 rgb[3];

	for (i = 0; i < number; ++i) {
		if (! ReadOK( data, rgb, sizeof(rgb) )) {
			GIFERRORMSG("bad colormap" );
				return true;
		}

		buf[CM_RED][i]   = rgb[0] ;
		buf[CM_GREEN][i] = rgb[1] ;
		buf[CM_BLUE][i]  = rgb[2] ;
	}
	return false;
}

static int GetDataBlock(GIFDecoder *data, u8 *buf)
{
	unsigned char count;

	if (! ReadOK( data, &count, 1 )) {
		GIFERRORMSG("error in getting DataBlock size" );
		return -1;
	}
	ZeroDataBlock = count == 0;

	if ((count != 0) && (! ReadOK( data, buf, count ))) {
//		GIFERRORMSG("error in reading DataBlock" );
		return -1;
	}

	return count;
}

static int GetCode(GIFDecoder *data, int code_size, int flag)
{
	int i, j, ret;
	int count;

	if (flag) {
		data->curbit = 0;
		data->lastbit = 0;
		data->done = false;
		return 0;
	}

	if ( (data->curbit+code_size) >= data->lastbit) {
		if (data->done) {
			if (data->curbit >= data->lastbit) {
				GIFERRORMSG("ran off the end of my bits" );
			}
			return -1;
		}
		data->buf[0] = data->buf[data->last_byte-2];
		data->buf[1] = data->buf[data->last_byte-1];

		if ((count = GetDataBlock( data, &data->buf[2] )) == 0) {
			data->done = true;
		}

		if(count == -1){
			return -1;
		}

		data->last_byte = 2 + count;
		data->curbit = (data->curbit - data->lastbit) + 16;
		data->lastbit = (2+count) * 8;
	}

	ret = 0;
	for (i = data->curbit, j = 0; j < code_size; ++i, ++j) {
		ret |= ((data->buf[ i / 8 ] & (1 << (i % 8))) != 0) << j;
	}
	data->curbit += code_size;

	return ret;
}

static int DoExtension( GIFDecoder *data, int label )
{
	unsigned char buf[256] = { 0 };
	char *str;
	int ret = 0;

	switch (label) {
		case 0x01:              /* Plain Text Extension */
			str = "Plain Text Extension";
			break;
		case 0xff:              /* Application Extension */
			str = "Application Extension";
			break;
		case 0xfe:              /* Comment Extension */
			str = "Comment Extension";
//               if (showComment)
//                   GIFERRORMSG("gif comment: %s", buf );
//               return false;
			   break;
		case 0xf9:              /* Graphic Control Extension */
			str = "Graphic Control Extension";
			ret = GetDataBlock( data, (u8*) buf );
			if(ret == -1) {
				return false;
			}
			data->disposal    = (buf[0] >> 2) & 0x7;
			data->inputFlag   = (buf[0] >> 1) & 0x1;
			data->delayTime   = LM_to_uint( buf[1], buf[2] );
			if ((buf[0] & 0x1) != 0) {
				data->transparent = buf[3];
			}
			   break;
//               return false;
		default:
			str = (char*) buf;
			snprintf(str, 256, "UNKNOWN (0x%02x)", label);
		break;
	}

	if (verbose)
	GIFERRORMSG("got a '%s' extension", str );

	 while (true){
		ret = GetDataBlock( data, (u8*) buf );
		if (ret == -1) {
			return false;
		}
	 	else if (ret == 0) {
			break;
		}
	}

	return true;
}

static int LWZReadByte( GIFDecoder *data, int flag, int input_code_size )
{
	int code, incode;
	int i;

	if (flag) {
		data->set_code_size = input_code_size;
		data->code_size = data->set_code_size+1;
		data->clear_code = 1 << data->set_code_size ;
		data->end_code = data->clear_code + 1;
		data->max_code_size = 2*data->clear_code;
		data->max_code = data->clear_code+2;

		GetCode(data, 0, true);

		data->fresh = true;

		for (i = 0; i < data->clear_code; ++i) {
			data->table[0][i] = 0;
			data->table[1][i] = i;
		}
		for (; i < (1<<MAX_LWZ_BITS); ++i) {
			data->table[0][i] = data->table[1][0] = 0;
		}
		data->sp = data->stack;

		return 0;
	}
	else if (data->fresh) {
		data->fresh = false;
		do {
			data->firstcode = data->oldcode = GetCode( data, data->code_size, false );
			if(data->oldcode == -1){
				return -1;
			}
		} while (data->firstcode == data->clear_code);

		return data->firstcode;
	}

	if (data->sp > data->stack) {
	return *--data->sp;
	}

	while ((code = GetCode( data, data->code_size, false )) >= 0) {
		if (code == data->clear_code) {
			for (i = 0; i < data->clear_code; ++i) {
				data->table[0][i] = 0;
				data->table[1][i] = i;
			}
			for (; i < (1<<MAX_LWZ_BITS); ++i) {
				data->table[0][i] = data->table[1][i] = 0;
			}
			data->code_size = data->set_code_size+1;
			data->max_code_size = 2*data->clear_code;
			data->max_code = data->clear_code+2;
			data->sp = data->stack;
			data->firstcode = data->oldcode = GetCode( data, data->code_size, false );

			return data->firstcode;
		}
		else if (code == data->end_code) {
			int count;
			u8 buf[260];

			if (ZeroDataBlock) {
				return -2;
			}
			while ((count = GetDataBlock( data, buf )) > 0){
				   ;
			}

			if (count != 0)
				GIFERRORMSG("missing EOD in data stream "
							"(common occurence)");

			   if(count == -1){
				   return -1;
			   }

			return -2;
		}

		incode = code;

		if (code >= data->max_code) {
			*data->sp++ = data->firstcode;
			code = data->oldcode;
		}

		while (code >= data->clear_code) {
			*data->sp++ = data->table[1][code];
			if (code == data->table[0][code]) {
				GIFERRORMSG("circular table entry BIG ERROR");
			}
			code = data->table[0][code];
		}

		*data->sp++ = data->firstcode = data->table[1][code];

		if ((code = data->max_code) <(1<<MAX_LWZ_BITS)) {
			data->table[0][code] = data->oldcode;
			data->table[1][code] = data->firstcode;
			++data->max_code;
			if ((data->max_code >= data->max_code_size)
				&& (data->max_code_size < (1<<MAX_LWZ_BITS)))
			{
				data->max_code_size *= 2;
				++data->code_size;
			}
		}

		data->oldcode = incode;

		if (data->sp > data->stack) {
			return *--data->sp;
		}
	}

	if(code == -1){
		return -1;
	}

	return code;
}

static int SortColors (const void *a, const void *b)
{
	return (*((const u8 *) a) - *((const u8 *) b));
}

/*  looks for a color that is not in the colormap and ideally not
    even close to the colors used in the colormap  */
static u32 FindColorKey( int n_colors, u8 cmap[3][MAXCOLORMAPSIZE] )
{
	u32   color = 0xFF000000;
	u8    csort[MAXCOLORMAPSIZE];
	int   i, j, index, d;

	if (n_colors < 1)
		return color;

	D_ASSERT( n_colors <= MAXCOLORMAPSIZE );

	for (i = 0; i < 3; i++) {
		direct_memcpy( csort, cmap[i], n_colors );
		qsort( csort, n_colors, 1, SortColors );

		for (j = 1, index = 0, d = 0; j < n_colors; j++) {
			if (csort[j] - csort[j-1] > d) {
				d = csort[j] - csort[j-1];
				index = j;
			}
		}
		if ((csort[0] - 0x0) > d) {
			d = csort[0] - 0x0;
			index = n_colors;
		}
		if (0xFF - (csort[n_colors - 1]) > d) {
			index = n_colors + 1;
		}

		if (index < n_colors)
			csort[0] = csort[index] - (d/2);
		else if (index == n_colors)
			csort[0] = 0x0;
		else
			csort[0] = 0xFF;

		color |= (csort[0] << (8 * (2 - i)));
	}

	return color;
}

static u32* ReadImage( GIFDecoder *data, int width, int height,
                       u8 cmap[3][MAXCOLORMAPSIZE], u32 key_rgb,
                       bool interlace, bool ignore )
{
	u8 c;
	int v;
	int xpos = 0, ypos = 0, pass = 0;
//     u32 *image;

	/*
	**  Initialize the decompression routines
*/
	if (! ReadOK( data, &c, 1 )){
		GIFERRORMSG("EOF / read error on image data" );
		  return NULL;
	}

	if (LWZReadByte( data, true, c ) < 0){
		GIFERRORMSG("error reading image" );
	}

	/*
	**  If this is an "uninteresting picture" ignore it.
	*/
	if (ignore) {
		if (verbose)
			GIFERRORMSG("skipping image..." );

		while (LWZReadByte( data, false, c ) >= 0)
               ;
		return NULL;
	}
     
	// FIXME: allocates four additional bytes because the scaling functions
	//        in src/misc/gfx_util.c have an off-by-one bug which causes
	//        segfaults on darwin/osx (not on linux)           
//     if ((image = D_MALLOC(width * height * 4 + 4)) == NULL) {
//          GIFERRORMSG("couldn't alloc space for image" );
//     }

	if (verbose) {
		GIFERRORMSG("reading %d by %d%s GIF image", width, height,
					interlace ? " interlaced" : "" );
	}

	while ((v = LWZReadByte( data, false, c )) >= 0 ) {
			data->status = SonyDFBDecoderStatus_Decoding;

//          u32 *dst = image + (ypos * width + xpos);

		// set the pointer of destination
		unsigned char *image = (unsigned char*)((unsigned char*)(data->userData1->pDstData) + ypos * data->userData1->pitch + 4 * xpos);

		if (ypos >= height)
			continue;

		// color format conversion(ARGB -> BGRA)
		if (v == data->transparent) {
//               *dst++ = key_rgb;
				*image = cmap[CM_BLUE][v];		// B
				image++;
				*image = cmap[CM_GREEN][v];		// G
				image++;
				*image = cmap[CM_RED][v];		// R
				image++;
				*image = 0x00;					// A
		}
		else {
//               *dst++ = (0xFF000000              |
//                         cmap[CM_RED][v]   << 16 |
//                         cmap[CM_GREEN][v] << 8  |
//                         cmap[CM_BLUE][v]);
				*image = cmap[CM_BLUE][v];		// B
				image++;
				*image = cmap[CM_GREEN][v];		// G
				image++;
				*image = cmap[CM_RED][v];		// R
				image++;
				*image = 0xff;					// A
		}

		++xpos;
		if (xpos == width) {
			xpos = 0;
			if (interlace) {
				switch (pass) {
					case 0:
					case 1:
						ypos += 8;
						break;
					case 2:
						ypos += 4;
						break;
					case 3:
						ypos += 2;
						break;
				}

				if (ypos >= height) {
					++pass;
					switch (pass) {
						case 1:
							ypos = 4;
							break;
						case 2:
							ypos = 2;
							break;
						case 3:
							ypos = 1;
							break;
						default:
							goto fini;
					}
				}
			}
			else {
				++ypos;
			}
		}
//          if (ypos >= height) {
//               break;
//          }
	}

	if(v == -1){
		 return NULL;
	}
fini:

//     if (LWZReadByte( data, false, c ) >= 0) {
//          GIFERRORMSG("too much input data, ignoring extra...");
//     }

//     return image;
	return data->userData1->pDstData;
}


static bool ReadGIF( GIFDecoder *data, int imageNumber,
                     int *width, int *height, bool *transparency,
                     u32 *key_rgb, bool alpha, bool headeronly)
{
	u8    buf[16];
	u8    c;
	u8    localColorMap[3][MAXCOLORMAPSIZE];
	u32   colorKey = 0;
	bool  useGlobalColormap;
	int   bitPixel;
	int   imageCount = 0;
	char  version[4];
	
	if(data->status < SonyDFBDecoderStatus_Parsed){
		if (! ReadOK( data, buf, 6 )) {
			GIFERRORMSG("error reading magic number" );
			return false;
		}
	    if (strncmp( (char *)buf, "GIF", 3 ) != 0) {
			GIFERRORMSG("not a GIF file" );
			return false;
		}

		direct_snputs( version, (char *)buf + 3, 4 );

		if ((strcmp(version, "87a") != 0) && (strcmp(version, "89a") != 0)) {
			GIFERRORMSG("bad version number, not '87a' or '89a'" );
		}


		if (! ReadOK(data,buf,7)) {
			GIFERRORMSG("failed to read screen descriptor" );
			return false;
		}

		data->Width           = LM_to_uint( buf[0], buf[1] );
		data->Height          = LM_to_uint( buf[2], buf[3] );
		data->BitPixel        = 2 << (buf[4] & 0x07);
		data->ColorResolution = (((buf[4] & 0x70) >> 3) + 1);
		data->Background      = buf[5];
		data->AspectRatio     = buf[6];
		if (BitSet(buf[4], LOCALCOLORMAP)) {    /* Global Colormap */
			if (ReadColorMap( data, data->BitPixel, data->ColorMap )) {
               GIFERRORMSG("error reading global colormap" );
			   return false;
			}
		}

		if (data->AspectRatio != 0 && data->AspectRatio != 49) {
          /* float r = ( (float) data->AspectRatio + 15.0 ) / 64.0; */
			GIFERRORMSG("warning - non-square pixels");
		}

		data->transparent = -1;
		data->delayTime   = -1;
		data->inputFlag   = -1;
		data->disposal    = 0;
	}

	for (;;) {
		if(data->status < SonyDFBDecoderStatus_Parsed || data->status == SonyDFBDecoderStatus_End){
			if (! ReadOK( data, &c, 1)) {
				GIFERRORMSG("EOF / read error on image data" );
				return false;
			}

			if (c == ';') {         /* GIF terminator */
//				if (imageCount < imageNumber) {
//                    GIFERRORMSG("only %d image%s found in file",
//                                imageCount, imageCount>1?"s":"" );
//				}
				data->callback(data->userData2, SonyDFBDecoderStatus_End);
				return true;
			}

			if (c == '!') {         /* Extension */
				if (! ReadOK( data, &c, 1)) {
                    GIFERRORMSG("OF / read error on extention function code");
					return false;
				}
				if(DoExtension( data, c ) == false){
					return false;
				}
				continue;
			}

			if (c != ',') {         /* Not a valid start character */
				GIFERRORMSG("bogus character 0x%02x, ignoring", (int) c );
				continue;
			}

			++imageCount;

			if (! ReadOK( data, buf, 9 )) {
				GIFERRORMSG("couldn't read left/top/width/height");
				return false;
			}

			*width  = LM_to_uint( buf[4], buf[5] );
			*height = LM_to_uint( buf[6], buf[7] );
			*transparency = (data->transparent != -1);

			if (headeronly && !(*transparency && key_rgb))
				return false;

			useGlobalColormap = ! BitSet( buf[8], LOCALCOLORMAP );

			if (useGlobalColormap) {
				if (*transparency && (key_rgb || !headeronly))
					colorKey = FindColorKey( data->BitPixel,
												data->ColorMap );
			}
			else {
				bitPixel = 2 << (buf[8] & 0x07);
				if (ReadColorMap( data, bitPixel, localColorMap )){
					GIFERRORMSG("error reading local colormap" );
					return false;
				}

				if (*transparency && (key_rgb || !headeronly))
					colorKey = FindColorKey( bitPixel, localColorMap );
			}

			if (key_rgb)
				*key_rgb = colorKey;

//            if (headeronly)
//                return false;

			if (alpha)
				colorKey &= 0x00FFFFFF;
			data->callback(data->userData2, SonyDFBDecoderStatus_Parsed);
			data->status = SonyDFBDecoderStatus_Parsed;
			removeSrcData(data, data->seekPoint);
		}

		if (data->status == SonyDFBDecoderStatus_Parsed) {
			++imageCount;
		}

		u32* ret = ReadImage( data, *width, *height,
							(useGlobalColormap ?
							data->ColorMap : localColorMap), colorKey,
							BitSet( buf[8], INTERLACE ),
							false);
		if (!ret) {
			return false;
		}
		else {
			data->status = SonyDFBDecoderStatus_End;
		}
	}
}

static bool
ReadOK( GIFDecoder *decoder, void *data, unsigned int len )
{
	if (decoder->srcEndPoint - decoder->seekPoint < len) {
		return false;
	}
	else {
		memcpy(data,(void*)(decoder->srcData + decoder->seekPoint), len); 
		decoder->seekPoint += len;
		return true;
	}
}

/////////////////////////////////////////////////////////////////////////////////

void *SonyDFB_createGifDecoder(void)
{
	GIFDecoder *decoder = (GIFDecoder*)malloc(sizeof(GIFDecoder));
	if (decoder) {
		decoder->srcData = (unsigned char*)malloc(GIF_DEC_MAX_SRC_SIZE);
		if (!decoder->srcData) {
			free(decoder);
			return NULL;
		}
		decoder->status = SonyDFBDecoderStatus_Initialized;
		return decoder;
	}
	else {
		return NULL;
	}
}

int SonyDFB_releaseGifDecoder(void **thiz)
{
	if (*thiz) {
		GIFDecoder* decoder = (GIFDecoder*)(*thiz);
		if (decoder->srcData) {
			free(decoder->srcData);
		}
		free(*thiz);
		return RET_OK;
	}
	else {
		return RET_NG;
	}
}

int SonyDFB_feedStreamGifDecoder(void *thiz, const unsigned char* pStream, const int streamBytes)
{
	GIFDecoder *decoder;
	if (thiz) {
		decoder = (GIFDecoder*)thiz;
		if (!addSrcData(decoder, pStream, streamBytes)) {
			return RET_NG;
		}
		decoder->seekPoint = 0;
		ReadGIF( decoder, 1, &decoder->image_width, &decoder->image_height,
					&decoder->image_transparency, &decoder->image_colorkey,
					true, false );
		return RET_OK;
	}
	return RET_NG;
}

int SonyDFB_setRenderCallbackGifDecoder(void *thiz, const SonyDFBGifRenderCallback callback, void* userData)
{
	if (thiz) {
		((GIFDecoder*)thiz)->renderCB = callback;
		((GIFDecoder*)thiz)->userData1 = userData;
		return RET_OK;
	}
	return RET_NG;
}

int SonyDFB_setNostifyFuncGifDecoder(void* thiz, SonyDFBGifCallback callback, void* userData)
{
	if (thiz) {
		((GIFDecoder*)thiz)->callback = callback;
		((GIFDecoder*)thiz)->userData2 = userData;
		return RET_OK;
	}
	return RET_NG;
}


int SonyDFB_getStatusGifDecoder(void *thiz)
{
	if (thiz) {
		return ((GIFDecoder*)thiz)->status;
	}
	return RET_NG;
}


int SonyDFB_getInfoGifDecoder(void *thiz, void* pInfoOut)
{
	// not use
	return RET_OK;
}

int SonyDFB_getImageSizeGifDecoder(void *thiz, int *w, int *h)
{
	if (thiz) {
		GIFDecoder* decoder = (GIFDecoder*)thiz;
		*w = decoder->Width;
		*h = decoder->Height;
		return RET_OK;
	}
	else {
		return RET_NG;
	}
}
