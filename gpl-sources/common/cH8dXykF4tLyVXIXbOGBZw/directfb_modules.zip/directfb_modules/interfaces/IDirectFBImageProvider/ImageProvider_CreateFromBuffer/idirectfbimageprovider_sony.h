/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrj�Cl�C <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/


/*
   Copyright 2009-2010 Sony Corporation.

   This is based on IDirectFBImageProvider_CreateFromBuffer.

   ChangeLog:
      2009/10/22 Creating IDirectFBImageProvider_CreateFromBufferSony() on 
                 the basis of IDirectFBImageProvider_CreateFromBuffer() 
                 to call Sony customized IDirectFBImageProvider.
*/


//#include <config.h>

#include <stddef.h>
#include <string.h>

#include <directfb.h>

#include <core/core.h>

#include <direct/interface.h>
#include <direct/mem.h>

#include <media/idirectfbimageprovider.h>
#include <media/idirectfbdatabuffer.h>

#ifndef __idirectfbimageprovider_sony_H__
#define __idirectfbimageprovider_sony_H__

#include "SonyDirectFB.h"

#ifdef __cplusplus
extern "C"
{
#endif
DFBResult
IDirectFBImageProvider_CreateFromBufferSony( IDirectFBDataBuffer     *buffer,
                                         CoreDFB                 *core,
                                         IDirectFBImageProvider **interface );

#ifdef __cplusplus
}
#endif // __cplusplus

#endif
