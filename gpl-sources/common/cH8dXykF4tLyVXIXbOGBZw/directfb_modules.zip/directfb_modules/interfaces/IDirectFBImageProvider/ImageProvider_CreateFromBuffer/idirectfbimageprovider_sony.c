/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrj辰l辰 <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/


/*
   Copyright 2009-2010 Sony Corporation.

   This is based on IDirectFBImageProvider_CreateFromBuffer.

   ChangeLog:
      2009/10/22 Creating IDirectFBImageProvider_CreateFromBufferSony() on 
                 the basis of IDirectFBImageProvider_CreateFromBuffer() 
                 to call Sony customized IDirectFBImageProvider.
	  2010/10/12 add an error handling
*/

// #include <config.h>

#include <stddef.h>
#include <string.h>

#include <directfb.h>

#include <core/core.h>

#include <direct/interface.h>
#include <direct/mem.h>

#include <media/idirectfbimageprovider.h>
#include <media/idirectfbdatabuffer.h>
#include "idirectfbimageprovider_sony.h"

typedef IDirectFBImageProvider IDirectFBSonyImageProvider;

#ifdef __cplusplus
extern "C"
{
#endif
DFBResult
IDirectFBImageProvider_CreateFromBufferSony( IDirectFBDataBuffer     *buffer,
                                         CoreDFB                 *core,
                                         IDirectFBImageProvider **interface )
{
	DFBResult                            ret;
    DirectInterfaceFuncs                *funcs = NULL;
    IDirectFBDataBuffer_data            *buffer_data;
    IDirectFBImageProvider              *imageprovider;
    IDirectFBImageProvider_ProbeContext  ctx;

    /* Get the private information of the data buffer. */
    buffer_data = (IDirectFBDataBuffer_data*) buffer->priv;
	if (!buffer_data){
         return DFB_DEAD;
	}

    /* Clear for safety, especially header data. */
    memset( &ctx, 0, sizeof(ctx) );

    /* Provide a fallback for image providers without data buffer support. */
    ctx.filename = buffer_data->filename;

    /* Wait until 32 bytes are available. */
    ret = buffer->WaitForData( buffer, 32 );
    if (ret)
         return ret;

    /* Read the first 32 bytes. */
    buffer->PeekData( buffer, 32, 0, ctx.header, NULL );

    /* Find a suitable implementation. */
//     ret = DirectGetInterface( &funcs, "IDirectFBImageProvider", NULL, DirectProbeInterface, &ctx );
 	if(ctx.header[0] == 0xFF){
	     ret = DirectGetInterface( &funcs, "IDirectFBSonyImageProvider", "SONYJPEG", DirectProbeInterface, &ctx );
	}else if(ctx.header[0] == 0x89){
	     ret = DirectGetInterface( &funcs, "IDirectFBSonyImageProvider", "SONYPNG", DirectProbeInterface, &ctx );
	}else if(ctx.header[0] == 0x47){
	     ret = DirectGetInterface( &funcs, "IDirectFBSonyImageProvider", "SONYGIF", DirectProbeInterface, &ctx );
	}else{
		//UXG_DBGPRINTF("[DFBW] Not supported format\n");
		ret = DFB_FAILURE;
	}

	if (ret){
          return ret;
	}

    DIRECT_ALLOCATE_INTERFACE( imageprovider, IDirectFBImageProvider );
     
     /* Initialize interface pointers. */
     //IDirectFBImageProvider_Construct( imageprovider );
//	 ret = SonyDirectFBsetImageProvider(imageprovider);
//	 if(ret)
//		 return ret;

     /* Construct the interface. */
	if(funcs){
        ret = funcs->Construct( imageprovider, buffer, core );
	    if (ret){
            return ret;
		}
	}else{
		return DFB_FAILURE;
	}

    *interface = imageprovider;

    return DFB_OK;
}
#ifdef __cplusplus
}
#endif // __cplusplus
