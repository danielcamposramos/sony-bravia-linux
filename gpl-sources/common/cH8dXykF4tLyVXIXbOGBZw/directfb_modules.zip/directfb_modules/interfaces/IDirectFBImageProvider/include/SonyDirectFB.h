/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrj�Cl�C <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/


/*
   Copyright 2009-2010 Sony Corporation.
   
   This is IDirectFBImageProvider implementation based decoder to support devided decoding mode.

   ChangeLog:
      2010/01/30 Defining some data structures for custimize IDirectFBImageProvider
                 to devided decoding mode on Sony products
*/


#ifndef SONY_DIRECT_FB_H
#define SONY_DIRECT_FB_H

#define SONY_DFB_BUFFER_FEED_SIZE 4096
#define SONY_DFB_BUFFER_HEADER_FEED 4

#include <stdio.h>
#include <stdlib.h>
#if (UXG_SYSTEM == UXG_SYS_LINUX || UXG_SYSTEM == UXG_SYS_TARGET)
#include <directfb.h>
#endif

typedef enum {
	SonyDFBDecoderMode_Normal,            //!< Original DirectFB mode
	SonyDFBDecoderMode_Divide,            //!< Dividing mode
	SonyDFBDecoderMode_DivideDirectWrite, //!< Dividing mode. diret write to destination
} SonyDFBDecoderMode;


typedef enum {
	SonyDFBDecoderStatus_Initialized = 0,   //!< when the decoder waits for initiazing or feeding enough data that decoder can start.
	SonyDFBDecoderStatus_Parsed = 2,        //!< when the decoder has finished header parse.
	SonyDFBDecoderStatus_Decoding = 3,      //!< when the decoder sends the decoded data to client.
	SonyDFBDecoderStatus_FrameDecoded = 4,	//!< when the decoder finish frame decoded. anime gif uses this status.
	SonyDFBDecoderStatus_End = 5,			//!< when the decoder becomes end status.
	SonyDFBDecoderStatus_Error = 6,			//!< when the decoder catches a certain error.
	SonyDFBDecoderStatus_Null = 7,			//!< before initiazing 
} SonyDFBDecoderStatus;


typedef struct {
	SonyDFBDecoderMode mode;              //!< flag for decode mode                            (client)
	SonyDFBDecoderStatus status;          //!< The decoder set status code to this field       (decoder)
	unsigned int size;                    //!< Size of the decoded data                        (decoder)
	unsigned int offset;                  //!< offset for indicating the current address       (decoder)
	                                      //!< current address = pDstData + offset
	unsigned int offset_y;                //!< y direction offset                              (decoder)
	void *pDecodedData;                   //!< Pointer of the decoded data                     (decoder)
	void *pSrcData;                       //!< Pointer of the Source data                      (client)
	void *pDstData;                       //!< Pointer of the Destination                      (client)
	void *pSurfaceDesc;					  //!< Pointer of the Surface Description              (client)
	unsigned int pitch;                   //!< Surface data pitch (maybe 8byte align)          (client) 
	unsigned int pixelformat;             //!< Pixelformat                                     (client)
	void *pUserData;                      //!< for future extension
} SonyDFBImageData;

#endif //SONY_DIRECT_FB_H
