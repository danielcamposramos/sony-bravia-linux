/*
   (c) Copyright 2001-2008  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   Written by Denis Oliver Kropp <dok@directfb.org>,
              Andreas Hundt <andi@fischlustig.de>,
              Sven Neumann <neo@directfb.org>,
              Ville Syrj�Cl�C <syrjala@sci.fi> and
              Claudio Ciccani <klan@users.sf.net>.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 51 Franklin Street, Suite 500,
   Boston, MA 02110-1335, USA.
*/


/*
   Copyright 2009-2010 Sony Corporation.
   
   This is IDirectFBImageProvider implementation based decoder to support devided decoding mode.
   
   ChangeLog:
      2010/01/30 Applying IDirectFBImageProvider to devided decoding mode on Sony products
*/

/* 
* Notice:
   This decoder is a sample implementation for modified IDirectFBImageProvider.
   This implementation can decode basic png format(3x8 bits rgb color).
   It is possible to support other png formats by adding some implemantations
   in png_info_callback(), png_row_callback().
*/

#define RET_OK 0
#define RET_NG 1

#include "SonyDirectFB.h"
#include "SonyDFBPngDecoder.h"

typedef struct{
	png_structp		png_ptr;
	png_infop		info_ptr;
	png_infop		end_ptr;
	png_voidp		error_ptr;
	png_uint_32		width;
	png_uint_32		height;
	int				bitDepth;
	int				colorType;
	int				interlaceType;
	SonyDFBDecoderStatus status;		/*< decoder status */
	SonyDFBPngRenderCallback renderCB;	/*< callback function for rendering*/
	SonyDFBImageData* userData1;		/*< user data*/
	SonyDFBPngCallback callback;		/*< callback function for status notify */
	void* userData2;					/*< user data*/
} PNGDecoder;


static void
png_info_callback(png_structp png_ptr, png_infop info_ptr)
{

	PNGDecoder *decoder = (PNGDecoder*)((png_get_progressive_ptr)(png_ptr));
	if (!decoder) {
		return;
	}

	if (png_get_IHDR(png_ptr, info_ptr,&decoder->width, &decoder->height, &decoder->bitDepth, &decoder->colorType, &decoder->interlaceType, NULL, NULL) != 1) {
		return;
	}

	decoder->callback(decoder->userData2, SonyDFBDecoderStatus_Parsed);

	switch (decoder->colorType) {
        	case PNG_COLOR_TYPE_PALETTE:
			// not implement
			break;
		case PNG_COLOR_TYPE_GRAY:
		case PNG_COLOR_TYPE_GRAY_ALPHA:
				png_set_gray_to_rgb( png_ptr );
		default:
				break;
	}

	if (decoder->bitDepth == 16) {
		png_set_strip_16(png_ptr);
	}

	if (!(decoder->colorType & PNG_COLOR_MASK_ALPHA)) {
		png_set_filler(png_ptr, 0xFF, PNG_FILLER_BEFORE);
	}
	png_read_update_info(png_ptr, info_ptr);
}

static void
png_row_callback(png_structp png_ptr, png_bytep new_row, png_uint_32 row_num, int pass_num)
{
	PNGDecoder *decoder = (PNGDecoder*)((png_get_progressive_ptr)(png_ptr));
	unsigned char *image;
	unsigned int i;

	// null check
	if (!decoder || !decoder->renderCB || !decoder->userData1) {
		return;
	}

	decoder->userData1->status = SonyDFBDecoderStatus_Decoding;

	// set the pointer of destination
	image = (unsigned char*)((unsigned char*)(decoder->userData1->pDstData) + row_num * decoder->userData1->pitch);

	if (png_ptr->interlaced != PNG_INTERLACE_ADAM7) { // not support interlace
		if (decoder->colorType != PNG_COLOR_TYPE_PALETTE) { // not support color palette
			if (new_row) {
				// color format conversion(ARGB -> BGRA)
				for (i=0;i<png_ptr->width;i++) {
					*(image) 	= *(new_row+3);     // B
					*(image+1)	= *(new_row+2);     // G
					*(image+2)	= *(new_row+1);     // R
					*(image+3)	= *(new_row);       // A
					image   += 4;
					new_row += 4;
				}
			}
			else {
				return;
			}
		}
	}
}


static void
png_end_callback(png_structp png_ptr, png_infop info_ptr)
{
	PNGDecoder *decoder = (PNGDecoder*)((png_get_progressive_ptr)(png_ptr));

	if (decoder) {
		decoder->callback(decoder->userData2, SonyDFBDecoderStatus_End);
	}
	else {
		decoder->callback(NULL, SonyDFBDecoderStatus_Error);
	}
}

void *SonyDFB_createPngDecoder(void)
{
	PNGDecoder *decoder = (PNGDecoder*)malloc(sizeof(PNGDecoder));

	if (decoder) {
		decoder->png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, decoder->error_ptr, NULL, NULL);
		if (decoder->png_ptr) {
			decoder->info_ptr = png_create_info_struct(decoder->png_ptr);
			decoder->end_ptr = png_create_info_struct(decoder->png_ptr);
			if (decoder->info_ptr && decoder->end_ptr) {
				if (setjmp(png_jmpbuf(decoder->png_ptr))) {
					goto error;
				}
				else {
					png_set_progressive_read_fn(decoder->png_ptr, (png_voidp)(decoder), png_info_callback, png_row_callback, png_end_callback);
					decoder->status = SonyDFBDecoderStatus_Initialized;
					return decoder;
				}
			}
			else {
				goto error;
			}
		}
		else {
			goto error;
		}
	}
	else {
		goto error;
	}

	error:
		if (decoder)
		{
			decoder->status = SonyDFBDecoderStatus_Error;
			if (decoder->png_ptr) {
				png_destroy_read_struct(&(decoder->png_ptr), &(decoder->info_ptr), &(decoder->end_ptr));
			}
		}
		return 0;
}

int SonyDFB_releasePngDecoder(void **thiz)
{
	if (*thiz) {
		free(*thiz);
		return RET_OK;
	}
	else {
		return RET_NG;
	}
}

int SonyDFB_feedStreamPngDecoder(void *thiz, unsigned char* pStream, int streamBytes)
{
	if (thiz) {
		PNGDecoder *decoder = (PNGDecoder*)thiz;
		if (setjmp(png_jmpbuf(decoder->png_ptr))) {
			decoder->status = SonyDFBDecoderStatus_Error;
			if (decoder->png_ptr) {
				png_destroy_read_struct(&(decoder->png_ptr), &(decoder->info_ptr), &(decoder->end_ptr));
			}
			return RET_NG;
		}
		png_process_data(decoder->png_ptr, decoder->info_ptr, (unsigned char *)pStream, streamBytes);
		return RET_OK;
	}
	return RET_NG;
}

int SonyDFB_setRenderCallbackPngDecoder(void *thiz, const SonyDFBPngRenderCallback callback, void* userData)
{
	if (thiz) {
		((PNGDecoder*)thiz)->renderCB = callback;
		((PNGDecoder*)thiz)->userData1 = userData;
		return RET_OK;
	}
	return RET_NG;
}

int SonyDFB_setNostifyFuncPngDecoder(void* thiz, SonyDFBPngCallback callback, void* userData)
{
	if (thiz) {
		((PNGDecoder*)thiz)->callback = callback;
		((PNGDecoder*)thiz)->userData2 = userData;
		return RET_OK;
	}
	return RET_NG;
}


int SonyDFB_getStructPngDecoder(void *thiz, png_structp *ptr)
{
	if (thiz) {
		*ptr = ((PNGDecoder*)thiz)->png_ptr;
		if (ptr) {
			return RET_OK;
		}
	}
	return RET_NG;
}


int SonyDFB_getInfoPngDecoder(void *thiz, png_infop *ptr)
{
	if (thiz) {
		*ptr = ((PNGDecoder*)thiz)->info_ptr;
		if (ptr) {
			return RET_OK;
		}
	}
	return RET_NG;
}

int SonyDFB_getStatusPngDecoder(void *thiz)
{
	if (thiz) {
		return ((PNGDecoder*)thiz)->status;
	}
	else {
		return SonyDFBDecoderStatus_Error;
	}
}
